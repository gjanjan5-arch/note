import { useState, useEffect, useMemo, useRef } from 'react';
import Fuse from 'fuse.js';
import type { InventoryItem, Customer, Transaction, CatalogPayload } from '../types';
import type {
  GlobalSearchResultItem,
  SearchCategory,
  GlobalSearchCounts,
  ProductSearchResult,
  UtangSearchResult,
  ReceiptSearchResult,
  CustomerSearchResult,
  SavedStoreSearchResult,
} from '../types/search';
import { formatPeso, formatDateTime } from '../utils/formatters';
import { translate, type LanguageCode } from '../utils/i18n';

interface UseGlobalSearchOptions {
  query: string;
  category: SearchCategory;
  inventory: InventoryItem[];
  customers: Customer[];
  transactions: Transaction[];
  savedStores?: CatalogPayload[];
  appMode?: 'seller' | 'buyer';
  lang: LanguageCode;
  debounceMs?: number;
  maxResultsPerCategory?: number;
}

const fuseOptions = {
  includeScore: true,
  threshold: 0.4,
  ignoreLocation: true,
};

export function useGlobalSearch({
  query,
  category,
  inventory,
  customers,
  transactions,
  savedStores = [],
  appMode = 'seller',
  lang,
  debounceMs = 200,
  maxResultsPerCategory = 25,
}: UseGlobalSearchOptions) {
  const [debouncedQuery, setDebouncedQuery] = useState(query);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    timerRef.current = window.setTimeout(() => {
      setDebouncedQuery(query);
    }, debounceMs);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [query, debounceMs]);

  const isSearching = query.trim().length > 0 && query.trim() !== debouncedQuery.trim();

  // Memoize Fuse instances
  const inventoryFuse = useMemo(() => new Fuse(inventory, { ...fuseOptions, keys: ['name', 'sku', 'category'] }), [inventory]);
  const customersFuse = useMemo(() => new Fuse(customers, { ...fuseOptions, keys: ['name', 'phone'] }), [customers]);
  const transactionsFuse = useMemo(() => new Fuse(transactions, { ...fuseOptions, keys: ['id', 'customerName', 'type', 'items.itemName'] }), [transactions]);
  const savedStoresFuse = useMemo(() => new Fuse(savedStores, { ...fuseOptions, keys: ['storeName', 'ownerName', 'contactNumber', 'storeAddress', 'items.name'] }), [savedStores]);

  const results = useMemo(() => {
    const q = debouncedQuery.trim();
    const qLower = q.toLowerCase();

    let matchedProducts: ProductSearchResult[] = [];
    let matchedUtang: UtangSearchResult[] = [];
    let matchedReceipts: ReceiptSearchResult[] = [];
    let matchedCustomers: CustomerSearchResult[] = [];
    let matchedSavedStores: SavedStoreSearchResult[] = [];

    // Helper to format Product
    const formatProduct = (item: InventoryItem, idx: number): ProductSearchResult => ({
      id: `prod-${item.id || idx}`,
      type: 'PRODUCT',
      title: item.name,
      subtitle: `${item.category || translate(lang, 'general') || 'General'} • ${formatPeso(item.unitPrice || 0)}`,
      badgeText: `${item.stock ?? 0} ${item.variants && item.variants.length > 0 ? ((item.stock ?? 0) === 1 ? 'pack' : 'packs') : (item.unit || translate(lang, 'unit_pcs') || 'pcs')}`,
      badgeVariant: (item.stock ?? 0) <= (item.minStockAlert || 5) ? 'warning' : 'neutral',
      meta: item.sku ? `SKU: ${item.sku}` : undefined,
      item,
    });

    // Helper to format Utang/Customer
    const formatCustomer = (cust: Customer, idx: number, type: 'UTANG' | 'CUSTOMER'): UtangSearchResult | CustomerSearchResult => ({
      id: `${type.toLowerCase()}-${cust.id || idx}`,
      type: type as any,
      title: cust.name,
      subtitle: cust.phone || translate(lang, 'no_phone') || 'No contact',
      badgeText: cust.currentBalance > 0 ? `${formatPeso(cust.currentBalance)}` : (translate(lang, 'no_balance') || 'Walang utang'),
      badgeVariant: cust.currentBalance > 0 ? 'warning' : 'neutral',
      meta: type === 'UTANG' ? (cust.currentBalance > 0 ? (translate(lang, 'has_unpaid_debt') || 'May utang') : (translate(lang, 'no_balance') || 'Walang utang')) : undefined,
      customer: cust,
    });

    // Helper to calculate relative time (e.g., 5m ago, 2h ago, 1d ago)
    const getRelativeTime = (timestamp: number) => {
      const diffMs = Date.now() - timestamp;
      const diffSecs = Math.floor(diffMs / 1000);
      const diffMins = Math.floor(diffSecs / 60);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffDays > 0) return `${diffDays}d ago`;
      if (diffHours > 0) return `${diffHours}h ago`;
      if (diffMins > 0) return `${diffMins}m ago`;
      return `${diffSecs}s ago`;
    };

    // Helper to format Receipt
    const formatReceipt = (tx: Transaction, idx: number): ReceiptSearchResult => {
      const amount = tx.totalAmount || 0;
      // Pad ID with leading zeros (e.g., 000001)
      const displayId = tx.id != null ? String(tx.id).padStart(6, '0') : String(idx).padStart(6, '0');
      return {
        id: `tx-${tx.id || idx}`,
        type: 'RECEIPT',
        title: tx.customerName ? `${tx.customerName} - ${formatPeso(amount)}` : `${translate(lang, 'receipt_num') || 'Resibo'} #${displayId} - ${formatPeso(amount)}`,
        subtitle: getRelativeTime(tx.timestamp),
        badgeText: tx.type,
        badgeVariant: tx.type === 'PAUTANG_RECORD' ? 'warning' : 'neutral',
        meta: `#${displayId} • ${tx.items?.length || 0} paninda`,
        transaction: tx,
      };
    };

    // Helper to format Saved Store
    const formatStore = (store: CatalogPayload, idx: number, qMatch: string): SavedStoreSearchResult => {
      const matchedItemNames = (store.items || [])
        .filter((it) => it.name.toLowerCase().includes(qMatch))
        .map((it) => it.name)
        .slice(0, 2)
        .join(', ');

      return {
        id: `store-${store.storeName}-${idx}`,
        type: 'SAVED_STORE',
        title: store.storeName,
        subtitle: matchedItemNames ? `May: ${matchedItemNames}` : (store.ownerName || 'Suki Store'),
        badgeText: `${store.items?.length || 0} items`,
        badgeVariant: 'primary',
        meta: store.contactNumber || store.storeAddress || undefined,
        store: store,
      };
    };

    if (appMode === 'seller') {
      // PRODUCTS
      if (category === 'ALL' || category === 'PRODUCTS') {
        if (q.length === 0) {
          matchedProducts = inventory.slice(0, maxResultsPerCategory).map(formatProduct);
        } else if (q.length === 1) {
          matchedProducts = inventory
            .filter(item => (item.name?.toLowerCase().includes(qLower) || item.sku?.toLowerCase().includes(qLower) || item.category?.toLowerCase().includes(qLower)))
            .slice(0, maxResultsPerCategory)
            .map(formatProduct);
        } else {
          matchedProducts = inventoryFuse.search(q).slice(0, maxResultsPerCategory).map(res => formatProduct(res.item, 0));
        }
      }

      // UTANG & CUSTOMERS
      const formatAndFilterCustomers = (type: 'UTANG' | 'CUSTOMER') => {
        if (q.length === 0) {
          return customers.slice(0, maxResultsPerCategory).map((c, i) => formatCustomer(c, i, type));
        } else if (q.length === 1) {
          return customers
            .filter(cust => (cust.name?.toLowerCase().includes(qLower) || cust.phone?.includes(qLower)))
            .slice(0, maxResultsPerCategory)
            .map((c, i) => formatCustomer(c, i, type));
        } else {
          return customersFuse.search(q).slice(0, maxResultsPerCategory).map(res => formatCustomer(res.item, 0, type));
        }
      };

      if (category === 'ALL' || category === 'UTANG') {
        matchedUtang = formatAndFilterCustomers('UTANG') as UtangSearchResult[];
      }
      if (category === 'ALL' || category === 'CUSTOMERS') {
        matchedCustomers = formatAndFilterCustomers('CUSTOMER') as CustomerSearchResult[];
      }

      // RECEIPTS
      if (category === 'ALL' || category === 'RECEIPTS') {
        if (q.length === 0) {
          matchedReceipts = transactions.slice(0, maxResultsPerCategory).map(formatReceipt);
        } else if (q.length === 1) {
          matchedReceipts = transactions
            .filter(tx => (
              String(tx.id).includes(qLower) ||
              tx.customerName?.toLowerCase().includes(qLower) ||
              tx.type?.toLowerCase().includes(qLower) ||
              tx.items?.some(it => it.itemName?.toLowerCase().includes(qLower))
            ))
            .slice(0, maxResultsPerCategory)
            .map(formatReceipt);
        } else {
          matchedReceipts = transactionsFuse.search(q).slice(0, maxResultsPerCategory).map(res => formatReceipt(res.item, 0));
        }
      }
    }

    if (appMode === 'buyer') {
      if (q.length === 0) {
        matchedSavedStores = savedStores.slice(0, maxResultsPerCategory).map((s, i) => formatStore(s, i, ''));
      } else if (q.length === 1) {
        matchedSavedStores = savedStores
          .filter(store => (
            store.storeName?.toLowerCase().includes(qLower) ||
            store.ownerName?.toLowerCase().includes(qLower) ||
            store.contactNumber?.toLowerCase().includes(qLower) ||
            store.storeAddress?.toLowerCase().includes(qLower) ||
            store.items?.some(item => item.name?.toLowerCase().includes(qLower))
          ))
          .slice(0, maxResultsPerCategory)
          .map((s, i) => formatStore(s, i, qLower));
      } else {
        matchedSavedStores = savedStoresFuse.search(q).slice(0, maxResultsPerCategory).map(res => formatStore(res.item, 0, qLower));
      }
    }

    const counts: GlobalSearchCounts = {
      all: matchedProducts.length + matchedUtang.length + matchedReceipts.length + matchedCustomers.length + matchedSavedStores.length,
      products: matchedProducts.length,
      utang: matchedUtang.length,
      receipts: matchedReceipts.length,
      customers: matchedCustomers.length,
      savedStores: matchedSavedStores.length,
    };

    let flatResults: GlobalSearchResultItem[] = [];
    if (category === 'ALL') {
      flatResults = [
        ...matchedProducts,
        ...matchedUtang,
        ...matchedReceipts,
        ...matchedCustomers,
        ...matchedSavedStores,
      ];
    } else if (category === 'PRODUCTS') {
      flatResults = matchedProducts;
    } else if (category === 'UTANG') {
      flatResults = matchedUtang;
    } else if (category === 'RECEIPTS') {
      flatResults = matchedReceipts;
    } else if (category === 'CUSTOMERS') {
      flatResults = matchedCustomers;
    } else if (category === 'SAVED_STORES') {
      flatResults = matchedSavedStores;
    }

    return {
      products: matchedProducts,
      utang: matchedUtang,
      receipts: matchedReceipts,
      customers: matchedCustomers,
      savedStores: matchedSavedStores,
      flatResults,
      counts,
      isSearching,
    };
  }, [debouncedQuery, isSearching, category, inventory, customers, transactions, savedStores, appMode, lang, maxResultsPerCategory, inventoryFuse, customersFuse, transactionsFuse, savedStoresFuse]);

  return results;
}

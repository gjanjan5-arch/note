import React, { useState, useMemo, useRef } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { X, RefreshCw, QrCode, Store, PackageCheck, Download, CreditCard, Sparkles } from 'lucide-react';
import QRCode from 'react-qr-code';
import LZString from 'lz-string';
import { db } from '../db/db';
import type { InventoryItem } from '../types';
import { getStoreProfile, type StoreProfile } from '../utils/storeSettings';
import { type LanguageCode } from '../utils/i18n';

interface StoreQRModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory?: InventoryItem[];
  storeSettings?: StoreProfile;
  lang: LanguageCode;
}

export const StoreQRModal: React.FC<StoreQRModalProps> = ({
  isOpen,
  onClose,
  inventory,
  storeSettings,
  lang,
}) => {
  const dbInventory = useLiveQuery(() => db.inventory.toArray()) || [];
  const activeInventory = inventory || dbInventory;
  const profile: StoreProfile = storeSettings || getStoreProfile();

  const [lastRefreshed, setLastRefreshed] = useState<number>(Date.now());
  const [isExporting, setIsExporting] = useState(false);
  const qrContainerRef = useRef<HTMLDivElement>(null);

  const isTl = lang === 'tl';
  const storeName = profile?.storeName || (isTl ? 'Aking Tindahan' : 'My Store');
  const gcashNumber = profile?.gcashNumber || '';
  const storeAddress = profile?.storeAddress || profile?.location || '';
  const contactNumber = profile?.contactNumber || profile?.phoneNumber || '';
  const purchaseMessage = profile?.purchaseMessage || '';
  const offlineText = profile?.offlineText || '';
  const ownerName = profile?.ownerName || '';

  // Single, high-density sync payload with 100% of items and seller info (zero dropped items)
  const qrData = useMemo(() => {
    const compactItems = activeInventory.map((item) => [
      item.id || item.name,
      item.name,
      Number(item.unitPrice) || 0,
      Number(item.stock) || 0,
      item.category || '',
      item.variants && item.variants.length > 0
        ? item.variants.map((v) => [v.label, Number(v.unitPrice) || 0])
        : undefined,
    ]);

    const syncPayload = {
      v: 4,
      t: 'SC',
      info: [storeName, gcashNumber, storeAddress, contactNumber, purchaseMessage, offlineText, ownerName],
      items: compactItems,
      ts: lastRefreshed,
    };

    return LZString.compressToEncodedURIComponent(JSON.stringify(syncPayload));
  }, [activeInventory, storeName, gcashNumber, storeAddress, contactNumber, purchaseMessage, offlineText, ownerName, lastRefreshed]);

  // Client-side 100% Offline Digital Store Card Canvas Generator
  const handleDownloadCard = async () => {
    try {
      setIsExporting(true);
      const svgElement = qrContainerRef.current?.querySelector('svg');
      if (!svgElement) {
        setIsExporting(false);
        return;
      }

      // 1. Serialize SVG QR to Image
      const svgString = new XMLSerializer().serializeToString(svgElement);
      const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
      const blobURL = URL.createObjectURL(svgBlob);

      const qrImg = new Image();
      await new Promise<void>((resolve, reject) => {
        qrImg.onload = () => resolve();
        qrImg.onerror = (e) => reject(e);
        qrImg.src = blobURL;
      });

      // 2. Offscreen Canvas (High Resolution 900x1350 for sharp printing or gallery view)
      const canvas = document.createElement('canvas');
      canvas.width = 900;
      canvas.height = 1350;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        URL.revokeObjectURL(blobURL);
        setIsExporting(false);
        return;
      }

      // Card Background (Dark Green Theme: #062016 outer, #0B2E21 card)
      ctx.fillStyle = '#062016';
      ctx.fillRect(0, 0, 900, 1350);

      // Inner Card Frame
      ctx.fillStyle = '#0B2E21';
      ctx.beginPath();
      ctx.roundRect(40, 40, 820, 1270, 36);
      ctx.fill();

      // Border Outline
      ctx.strokeStyle = '#10B981';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.roundRect(40, 40, 820, 1270, 36);
      ctx.stroke();

      // Store Title
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '900 44px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(storeName, 450, 130);

      // Subtitle / Address
      ctx.fillStyle = '#10B981';
      ctx.font = 'bold 24px sans-serif';
      const addressText = storeAddress || (isTl ? 'Sari-Sari Store • Tindahan Notes' : 'Community Store • Tindahan Notes');
      ctx.fillText(addressText, 450, 175);

      if (contactNumber) {
        ctx.fillStyle = '#94A3B8';
        ctx.font = '20px sans-serif';
        ctx.fillText(`📞 ${contactNumber}`, 450, 215);
      }

      // Purchase Message / Quote Banner if present
      let qrTop = 270;
      if (purchaseMessage) {
        ctx.fillStyle = 'rgba(16, 185, 129, 0.12)';
        ctx.beginPath();
        ctx.roundRect(80, 240, 740, 70, 16);
        ctx.fill();

        ctx.fillStyle = '#6EE7B7';
        ctx.font = 'italic 20px sans-serif';
        const displayMsg = purchaseMessage.length > 55 ? `${purchaseMessage.slice(0, 52)}...` : purchaseMessage;
        ctx.fillText(`“${displayMsg}”`, 450, 283);
        qrTop = 350;
      }

      // White QR code mounting plate
      const qrBoxSize = 480;
      const qrBoxX = (900 - qrBoxSize) / 2;
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.roundRect(qrBoxX, qrTop, qrBoxSize, qrBoxSize, 28);
      ctx.fill();

      // Draw QR image
      const qrPad = 30;
      ctx.drawImage(qrImg, qrBoxX + qrPad, qrTop + qrPad, qrBoxSize - qrPad * 2, qrBoxSize - qrPad * 2);

      // GCash Badge
      const gcashTop = qrTop + qrBoxSize + 40;
      if (gcashNumber) {
        ctx.fillStyle = '#007DFE';
        ctx.beginPath();
        ctx.roundRect(140, gcashTop, 620, 75, 20);
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.font = '900 28px sans-serif';
        ctx.fillText(`GCash: ${gcashNumber}`, 450, gcashTop + 48);
      }

      // Inventory & Catalog Count Badge
      const infoTop = gcashNumber ? gcashTop + 105 : gcashTop + 30;
      ctx.fillStyle = '#34D399';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText(
        `📦 ${activeInventory.length} ${isTl ? 'Paninda nakatala sa QR' : 'Products cataloged in QR'}`,
        450,
        infoTop
      );

      // Bottom Footer Instruction
      ctx.fillStyle = '#94A3B8';
      ctx.font = '18px sans-serif';
      ctx.fillText(
        isTl ? 'I-scan gamit ang Tinda Buyer Mode para sa mabilisang pagbili' : 'Scan via Tinda Buyer Mode for instant offline shopping',
        450,
        1260
      );

      URL.revokeObjectURL(blobURL);

      // Convert Canvas to PNG Blob & Download
      const dataUrl = canvas.toDataURL('image/png');
      const safeStoreFileName = storeName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
      const link = document.createElement('a');
      link.download = `Store_Card_${safeStoreFileName || 'tindahan'}.png`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('[StoreQRModal] Failed to export offline card image:', err);
    } finally {
      setIsExporting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs select-none overflow-y-auto transition-opacity duration-150">
      <div className="relative w-full max-w-sm rounded-3xl theme-bg-card border theme-border shadow-2xl p-5 sm:p-6 theme-text-app flex flex-col items-center max-h-[92vh] overflow-y-auto custom-modal-scrollbar">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full theme-bg-surface-subtle theme-text-secondary hover:theme-text-app transition-colors cursor-pointer touch-manipulation active:scale-95"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* STANDARD MINIMALIST QR VIEW */}
        <div className="w-full flex flex-col items-center mb-4">
          <div className="flex items-center gap-2 mb-2 text-center">
            <div className="p-2 rounded-xl theme-bg-primary text-white">
              <Store className="w-4 h-4" />
            </div>
            <h3 className="font-black text-base theme-text-app truncate max-w-[220px]">{storeName}</h3>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full theme-bg-surface-subtle border theme-border-subtle text-[11px] font-bold theme-text-secondary mb-3">
            <PackageCheck className="w-3 h-3 theme-text-accent" />
            <span>{activeInventory.length} {isTl ? 'paninda sa QR' : 'items cataloged'}</span>
          </div>

          <div ref={qrContainerRef} className="p-4 bg-white rounded-3xl shadow-inner border-4 theme-border max-w-[220px] w-full aspect-square flex items-center justify-center">
            <QRCode
              value={qrData}
              size={200}
              level="M"
              style={{ height: 'auto', maxWidth: '100%', width: '100%' }}
              viewBox="0 0 256 256"
            />
          </div>
        </div>

        {/* Action Buttons: Save Card Image + Refresh + Close */}
        <div className="w-full space-y-2">
          <button
            type="button"
            disabled={isExporting}
            onClick={handleDownloadCard}
            className="w-full py-2.5 px-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-extrabold text-xs flex items-center justify-center gap-2 transition-all shadow-xs cursor-pointer touch-manipulation active:scale-95 disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>
              {isExporting
                ? (isTl ? 'Ginagawa ang Card...' : 'Generating Card...')
                : (isTl ? 'I-save ang QR Card Image' : 'Save QR Card Image')}
            </span>
          </button>

          <div className="flex gap-2 w-full">
            <button
              type="button"
              onClick={() => setLastRefreshed(Date.now())}
              className="flex-1 py-2 px-3 rounded-2xl theme-bg-surface-subtle hover:theme-bg-surface border theme-border-subtle theme-text-app font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer touch-manipulation active:scale-95"
            >
              <RefreshCw className="w-3.5 h-3.5 theme-text-accent" />
              <span>{isTl ? 'I-refresh' : 'Refresh'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-3 rounded-2xl theme-bg-primary text-white font-black text-xs flex items-center justify-center transition-colors cursor-pointer touch-manipulation active:scale-95 shadow-2xs"
            >
              <span>{isTl ? 'Isara' : 'Done'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import { useState, useEffect, useMemo, useRef } from 'react';
import type { InventoryItem, Customer, Transaction, CatalogPayload } from '../types';
import type {
  GlobalSearchResultItem,
  SearchCategory,
  GlobalSearchCounts,
  ProductSearchResult,
  UtangSearchResult,
  ReceiptSearchResult,
  CustomerSearchResult,
  SavedStoreSearchResult,
} from '../types/search';
import { formatPeso, formatDateTime } from '../utils/formatters';
import { translate, type LanguageCode } from '../utils/i18n';

interface UseGlobalSearchOptions {
  query: string;
  category: SearchCategory;
  inventory: InventoryItem[];
  customers: Customer[];
  transactions: Transaction[];
  savedStores?: CatalogPayload[];
  appMode?: 'seller' | 'buyer';
  lang: LanguageCode;
  debounceMs?: number;
  maxResultsPerCategory?: number;
}

export function useGlobalSearch({
  query,
  category,
  inventory,
  customers,
  transactions,
  savedStores = [],
  appMode = 'seller',
  lang,
  debounceMs = 200,
  maxResultsPerCategory = 25,
}: UseGlobalSearchOptions) {
  const [debouncedQuery, setDebouncedQuery] = useState(query);
  const timerRef = useRef<number | null>(null);

  // 200ms debounce to save CPU/battery and avoid redundant search allocations
  useEffect(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    timerRef.current = window.setTimeout(() => {
      setDebouncedQuery(query);
    }, debounceMs);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [query, debounceMs]);

  const results = useMemo(() => {
    const q = debouncedQuery.trim().toLowerCase();
    const isSearching = q.length > 0;

    const matchedProducts: ProductSearchResult[] = [];
    const matchedUtang: UtangSearchResult[] = [];
    const matchedReceipts: ReceiptSearchResult[] = [];
    const matchedCustomers: CustomerSearchResult[] = [];
    const matchedSavedStores: SavedStoreSearchResult[] = [];

    // STRICT ISOLATION: When user is in Seller Mode, only search Seller collections
    if (appMode === 'seller' && isSearching) {
      // 1. PRODUCTS (Inventory)
      if (category === 'ALL' || category === 'PRODUCTS') {
        let pCount = 0;
        for (let i = 0; i < inventory.length; i++) {
          if (pCount >= maxResultsPerCategory) break;
          const item = inventory[i];
          if (!item) continue;

          const nameMatch = item.name && item.name.toLowerCase().includes(q);
          const skuMatch = item.sku && item.sku.toLowerCase().includes(q);
          const catMatch = item.category && item.category.toLowerCase().includes(q);

          if (nameMatch || skuMatch || catMatch) {
            matchedProducts.push({
              id: `prod-${item.id || i}`,
              type: 'PRODUCT',
              title: item.name,
              subtitle: `${item.category || translate(lang, 'general') || 'General'} • ${formatPeso(item.unitPrice || 0)}`,
              badgeText: `${item.stock ?? 0} ${item.variants && item.variants.length > 0 ? ((item.stock ?? 0) === 1 ? 'pack' : 'packs') : (item.unit || translate(lang, 'unit_pcs') || 'pcs')}`,
              badgeVariant: (item.stock ?? 0) <= (item.minStockAlert || 5) ? 'warning' : 'neutral',
              meta: item.sku ? `SKU: ${item.sku}` : undefined,
              item,
            });
            pCount++;
          }
        }
      }

      // 2. UTANG (Debts)
      if (category === 'ALL' || category === 'UTANG') {
        let uCount = 0;
        for (let i = 0; i < customers.length; i++) {
          if (uCount >= maxResultsPerCategory) break;
          const cust = customers[i];
          if (!cust) continue;

          const nameMatch = cust.name && cust.name.toLowerCase().includes(q);
          const phoneMatch = cust.phone && cust.phone.includes(q);

          if (nameMatch || phoneMatch) {
            matchedUtang.push({
              id: `utang-${cust.id || i}`,
              type: 'UTANG',
              title: cust.name,
              subtitle: cust.phone || translate(lang, 'no_phone') || 'No contact',
              badgeText: `${formatPeso(cust.currentBalance || 0)}`,
              badgeVariant: (cust.currentBalance || 0) > 0 ? 'warning' : 'neutral',
              meta: (cust.currentBalance || 0) > 0 ? (translate(lang, 'has_unpaid_debt') || 'May utang') : (translate(lang, 'no_balance') || 'Walang utang'),
              customer: cust,
            });
            uCount++;
          }
        }
      }

      // 3. RECEIPTS (Transactions)
      if (category === 'ALL' || category === 'RECEIPTS') {
        let rCount = 0;
        for (let i = 0; i < transactions.length; i++) {
          if (rCount >= maxResultsPerCategory) break;
          const tx = transactions[i];
          if (!tx) continue;

          const idMatch = tx.id != null && String(tx.id).includes(q);
          const custMatch = tx.customerName && tx.customerName.toLowerCase().includes(q);
          const typeMatch = tx.type && tx.type.toLowerCase().includes(q);
          const itemMatch =
            tx.items &&
            tx.items.some(
              (it) => it.itemName && it.itemName.toLowerCase().includes(q)
            );

          if (idMatch || custMatch || typeMatch || itemMatch) {
            const amount = tx.totalAmount || 0;
            const displayId = tx.id != null ? String(tx.id).slice(-6) : `${i}`;
            matchedReceipts.push({
              id: `tx-${tx.id || i}`,
              type: 'RECEIPT',
              title: tx.customerName ? `${tx.customerName} - ${formatPeso(amount)}` : `${translate(lang, 'receipt_num') || 'Resibo'} #${displayId} - ${formatPeso(amount)}`,
              subtitle: formatDateTime(tx.timestamp),
              badgeText: tx.type,
              badgeVariant: tx.type === 'PAUTANG_RECORD' ? 'warning' : 'neutral',
              meta: `${tx.items?.length || 0} paninda`,
              transaction: tx,
            });
            rCount++;
          }
        }
      }

      // 4. CUSTOMERS
      if (category === 'ALL' || category === 'CUSTOMERS') {
        let cCount = 0;
        for (let i = 0; i < customers.length; i++) {
          if (cCount >= maxResultsPerCategory) break;
          const cust = customers[i];
          if (!cust) continue;

          const nameMatch = cust.name && cust.name.toLowerCase().includes(q);
          const phoneMatch = cust.phone && cust.phone.includes(q);

          if (nameMatch || phoneMatch) {
            matchedCustomers.push({
              id: `cust-${cust.id || i}`,
              type: 'CUSTOMER',
              title: cust.name,
              subtitle: cust.phone || translate(lang, 'no_phone') || 'No contact',
              badgeText: cust.currentBalance > 0 ? `${formatPeso(cust.currentBalance)} utang` : (translate(lang, 'no_balance') || 'Walang utang'),
              badgeVariant: cust.currentBalance > 0 ? 'warning' : 'neutral',
              customer: cust,
            });
            cCount++;
          }
        }
      }
    }

    // STRICT ISOLATION: When user is in Buyer Mode, only search Buyer collections (Suki Stores & items)
    if (appMode === 'buyer' && isSearching) {
      let sCount = 0;
      for (let i = 0; i < savedStores.length; i++) {
        if (sCount >= maxResultsPerCategory) break;
        const store = savedStores[i];
        if (!store) continue;

        const nameMatch = store.storeName && store.storeName.toLowerCase().includes(q);
        const ownerMatch = store.ownerName && store.ownerName.toLowerCase().includes(q);
        const contactMatch = store.contactNumber && store.contactNumber.toLowerCase().includes(q);
        const addressMatch = store.storeAddress && store.storeAddress.toLowerCase().includes(q);
        const productMatch = store.items && store.items.some((item) => item.name && item.name.toLowerCase().includes(q));

        if (nameMatch || ownerMatch || contactMatch || addressMatch || productMatch) {
          const matchedItemNames = productMatch
            ? store.items
                .filter((it) => it.name.toLowerCase().includes(q))
                .map((it) => it.name)
                .slice(0, 2)
                .join(', ')
            : '';

          matchedSavedStores.push({
            id: `store-${store.storeName}-${i}`,
            type: 'SAVED_STORE',
            title: store.storeName,
            subtitle: matchedItemNames ? `May: ${matchedItemNames}` : (store.ownerName || 'Suki Store'),
            badgeText: `${store.items?.length || 0} items`,
            badgeVariant: 'primary',
            meta: store.contactNumber || store.storeAddress || undefined,
            store: store,
          });
          sCount++;
        }
      }
    }

    const counts: GlobalSearchCounts = {
      all: matchedProducts.length + matchedUtang.length + matchedReceipts.length + matchedCustomers.length + matchedSavedStores.length,
      products: matchedProducts.length,
      utang: matchedUtang.length,
      receipts: matchedReceipts.length,
      customers: matchedCustomers.length,
      savedStores: matchedSavedStores.length,
    };

    let flatResults: GlobalSearchResultItem[] = [];
    if (category === 'ALL') {
      flatResults = [
        ...matchedProducts,
        ...matchedUtang,
        ...matchedReceipts,
        ...matchedCustomers,
        ...matchedSavedStores,
      ];
    } else if (category === 'PRODUCTS') {
      flatResults = matchedProducts;
    } else if (category === 'UTANG') {
      flatResults = matchedUtang;
    } else if (category === 'RECEIPTS') {
      flatResults = matchedReceipts;
    } else if (category === 'CUSTOMERS') {
      flatResults = matchedCustomers;
    } else if (category === 'SAVED_STORES') {
      flatResults = matchedSavedStores;
    }

    return {
      products: matchedProducts,
      utang: matchedUtang,
      receipts: matchedReceipts,
      customers: matchedCustomers,
      savedStores: matchedSavedStores,
      flatResults,
      counts,
      isSearching,
    };
  }, [debouncedQuery, category, inventory, customers, transactions, savedStores, appMode, lang, maxResultsPerCategory]);

  return results;
}

import React, { useState, useRef } from 'react';
import { RefreshCw, ArrowDown } from 'lucide-react';
import { translate, type LanguageCode } from '../utils/i18n';

interface PullToRefreshProps {
  onRefresh: () => Promise<void> | void;
  children: React.ReactNode;
  lang: LanguageCode;
}

export const PullToRefresh: React.FC<PullToRefreshProps> = ({ onRefresh, children, lang }) => {
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const startYRef = useRef(0);
  const startXRef = useRef(0);
  const isDraggingRef = useRef(false);
  const hasMovedRef = useRef(false);
  const threshold = 70;

  const handleTouchStart = (e: React.TouchEvent) => {
    // Only engage pull-to-refresh when strictly at the top of the scroll container
    const scrollY = window.scrollY || document.documentElement.scrollTop || 0;
    if (scrollY > 2) {
      isDraggingRef.current = false;
      hasMovedRef.current = false;
      return;
    }
    const touch = e.touches[0];
    if (!touch) return;

    startYRef.current = touch.clientY;
    startXRef.current = touch.clientX;
    isDraggingRef.current = true;
    hasMovedRef.current = false;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDraggingRef.current || isRefreshing) return;
    const scrollY = window.scrollY || document.documentElement.scrollTop || 0;
    if (scrollY > 2) {
      isDraggingRef.current = false;
      setPullDistance(0);
      return;
    }

    const touch = e.touches[0];
    if (!touch) return;

    const deltaY = touch.clientY - startYRef.current;
    const deltaX = Math.abs(touch.clientX - startXRef.current);

    // If moving horizontally or scrolling up, ignore
    if (deltaX > Math.abs(deltaY) || deltaY <= 0) {
      return;
    }

    if (deltaY > 10) {
      hasMovedRef.current = true;
      // Damped rubber-band calculation
      const damped = Math.min(100, Math.pow(deltaY - 10, 0.85));
      setPullDistance(damped);
    } else {
      if (pullDistance !== 0) setPullDistance(0);
    }
  };

  const handleTouchEnd = async () => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;

    if (hasMovedRef.current && pullDistance >= threshold && !isRefreshing) {
      console.log('[PullToRefresh] Threshold reached, triggering onRefresh()');
      setIsRefreshing(true);
      setPullDistance(threshold);
      try {
        await Promise.resolve(onRefresh());
      } catch (err) {
        console.warn('[PullToRefresh] Refresh error:', err);
      } finally {
        setTimeout(() => {
          setIsRefreshing(false);
          setPullDistance(0);
          hasMovedRef.current = false;
        }, 500);
      }
    } else {
      setPullDistance(0);
      hasMovedRef.current = false;
    }
  };

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchEnd}
      className="relative"
    >
      {/* Pull Indicator */}
      <div
        className="overflow-hidden flex items-center justify-center transition-all duration-200 pointer-events-none"
        style={{
          height: `${pullDistance}px`,
          opacity: pullDistance > 10 ? 1 : 0,
        }}
      >
        <div className="flex items-center gap-2 text-xs font-bold theme-text-accent py-2">
          {isRefreshing ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-[var(--color-primary)]" />
              <span>{translate(lang, 'refreshing')}</span>
            </>
          ) : pullDistance >= threshold ? (
            <>
              <RefreshCw className="w-4 h-4 text-[var(--color-primary)] rotate-180 transition-transform" />
              <span>{translate(lang, 'release_to_refresh')}</span>
            </>
          ) : (
            <>
              <ArrowDown className="w-4 h-4 text-[var(--color-primary)] animate-bounce" />
              <span>{translate(lang, 'pull_to_refresh')}</span>
            </>
          )}
        </div>
      </div>

      {children}
    </div>
  );
};


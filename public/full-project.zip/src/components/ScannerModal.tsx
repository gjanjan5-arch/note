import React, { useEffect, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Camera,
  Flashlight,
  RefreshCw,
  Scan,
  AlertCircle,
  Plus,
  Package,
  Search,
  Sparkles,
  Barcode,
  Type,
  CheckCircle2,
  Settings,
  Bug,
  Moon,
  Power,
  Zap,
  QrCode,
  Upload,
} from 'lucide-react';
import { db } from '../db/db';
import type { InventoryItem } from '../types';
import { translate, type LanguageCode } from '../utils/i18n';
import { ItemRecognizedModal, type CartItemEntry } from './ItemRecognizedModal';
import { playScanBeep } from '../utils/audioBeep';
import { formatPeso } from '../utils/formatters';
import {
  ensureCameraPermission,
  openCameraSettings,
  prepareGoogleBarcodeScannerModule,
  prepareGoogleTextRecognitionModule,
  type MlKitModuleStatus,
} from '../utils/scannerPermission';
import { BarcodeScanner, BarcodeFormat } from '@capacitor-mlkit/barcode-scanning';
import { TextRecognition } from '@capacitor-mlkit/text-recognition';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import LZString from 'lz-string';
import jsQR from 'jsqr';
import type { BuyerOrderPayload } from './BuyerOrderModal';

const getScannerTitle = (scanType: 'all' | 'qr_only' | string | undefined, lang: LanguageCode) => {
  if (scanType === 'qr_only') {
    switch (lang) {
      case 'ja':
        return '店舗カタログQRをスキャン';
      case 'zh':
        return '扫描店铺目录二维码';
      case 'ko':
        return '매장 카탈로그 QR 스캔';
      case 'en':
        return 'Scan Store Catalog QR';
      case 'tl':
      default:
        return 'I-scan ang Store Catalog QR';
    }
  }
  return translate(lang, 'scanner_title') || 'Product Scanner';
};

const getScannerReticleText = (
  scanType: 'all' | 'qr_only' | string | undefined,
  scanMode: 'barcode' | 'text',
  lang: LanguageCode
) => {
  if (scanType === 'qr_only') {
    switch (lang) {
      case 'ja':
        return '店舗QRコードを中央に配置';
      case 'zh':
        return '将店铺二维码对准中央';
      case 'ko':
        return '매장 QR 코드를 중앙에 맞추세요';
      case 'en':
        return 'Center Store QR code here';
      case 'tl':
      default:
        return 'Itutok ang Store QR code dito';
    }
  }
  if (scanMode === 'text') {
    return lang === 'tl' ? 'Inihanay ang teksto o presyo dito' : 'Align product name or price here';
  }
  return lang === 'tl' ? 'Itutok ang barcode dito' : 'Center barcode here';
};

interface ScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAddItem: (prefill: { name?: string; sku?: string; itemType?: 'STANDARD' | 'PACK_VARIETY' }) => void;
  onOpenAddModal?: (prefill: { name?: string; sku?: string; itemType?: 'STANDARD' | 'PACK_VARIETY' }) => void;
  onTransactionSuccess?: (message: string) => void;
  onScanSuccess?: (detectedText: string) => void;
  onScannedBuyerOrder?: (order: BuyerOrderPayload) => void;
  scanType?: 'all' | 'qr_only';
  lang: LanguageCode;
}

// Tesseract whitelist character set
export const TESSERACT_CHAR_WHITELIST =
  'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789₱.,-/% ';

// Normalizes OCR recognized text, cleans spaced digits/prices, and strips unreadable noise
function normalizeOcrText(rawText: string): string {
  if (!rawText) return '';
  // 1. Remove spaces inside numbers and decimals (e.g. "2 5 . 0 0" -> "25.00", "1 5 0" -> "150")
  let cleaned = rawText.replace(/(\d)\s+(\d)/g, '$1$2');
  cleaned = cleaned.replace(/(\d)\s*[.,]\s*(\d)/g, '$1.$2');
  // 2. Fix spaced Philippine peso currency strings (e.g. "₱ 25.00" -> "₱25.00", "PHP 50" -> "₱50")
  cleaned = cleaned.replace(/(?:₱|PHP|Php|P)\s*(\d+(?:\.\d{1,2})?)/gi, '₱$1');
  // 3. Enforce Tesseract character whitelist
  cleaned = cleaned.replace(/[^A-Za-z0-9₱.,\-/% \s]/g, ' ');
  // 4. Collapse consecutive whitespace
  cleaned = cleaned.replace(/\s+/g, ' ').trim();
  return cleaned;
}

// Stricter OCR line validation to eliminate noise and gibberish
function isValidOcrLine(line: string): boolean {
  if (!line || line.trim().length === 0) return false;
  const trimmed = line.trim();

  // 1. Maximum length: 35 characters
  if (trimmed.length > 35) return false;

  // 2. Reject more than 2 consecutive identical characters (e.g., "aaa", "111")
  if (/(.)\1\1/.test(trimmed)) return false;

  // 3. Must contain at least one vowel (a, e, i, o, u)
  if (!/[aeiou]/i.test(trimmed)) return false;

  // 4. Single-word lines must be at least 4 characters long
  const words = trimmed.split(/\s+/);
  if (words.length === 1 && words[0].length < 4) return false;

  // 5. Must not have more special characters than letters
  const letterCount = (trimmed.match(/[a-zA-Z]/g) || []).length;
  const specCount = (trimmed.match(/[^a-zA-Z0-9\s]/g) || []).length;
  if (specCount > letterCount) return false;

  return true;
}

// Fuzzy OCR character normalization to handle common camera character misreadings
function normalizeOcrFuzzy(str: string): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .replace(/[0o]/g, '0')
    .replace(/[1il]/g, '1')
    .replace(/[5s]/g, '5')
    .replace(/[8b]/g, '8')
    .replace(/[^a-z0-9]/g, '');
}

// Levenshtein similarity ratio between two normalized strings (0.0 to 1.0)
function getSimilarityRatio(str1: string, str2: string): number {
  if (!str1 || !str2) return 0;
  if (str1 === str2) return 1;
  const len1 = str1.length;
  const len2 = str2.length;
  const maxLen = Math.max(len1, len2);
  if (maxLen === 0) return 1;

  const matrix: number[][] = [];
  for (let i = 0; i <= len1; i++) matrix[i] = [i];
  for (let j = 0; j <= len2; j++) matrix[0][j] = j;

  for (let i = 1; i <= len1; i++) {
    for (let j = 1; j <= len2; j++) {
      const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost
      );
    }
  }

  const distance = matrix[len1][len2];
  return 1 - distance / maxLen;
}

// Check temporal consistency across last 3 frames (at least 2 matches required)
function isTemporallyConsistent(candidate: string, history: string[][]): boolean {
  if (!candidate || history.length < 2) return false;
  const normCand = normalizeOcrFuzzy(candidate);
  const candLower = candidate.toLowerCase();

  let matchFrameCount = 0;
  for (const frameLines of history) {
    const matchedInFrame = frameLines.some((line) => {
      const lineLower = line.toLowerCase();
      const normLine = normalizeOcrFuzzy(line);
      if (lineLower.includes(candLower) || candLower.includes(lineLower)) {
        return true;
      }
      if (normCand.length >= 3 && normLine.length >= 3) {
        if (getSimilarityRatio(normCand, normLine) >= 0.82) return true;
      }
      return false;
    });
    if (matchedInFrame) matchFrameCount++;
  }
  return matchFrameCount >= 2;
}

// Filter and rank top 3 recommended product name candidates
function filterAndRankRecommendedNames(extractedLines: string[]): string[] {
  if (!extractedLines || extractedLines.length === 0) return [];

  const noiseKeywords = [
    'ingredient',
    'nutrition',
    'manufactur',
    'expirat',
    'expiry',
    'batch',
    'customer',
    'keep in',
    'store in',
    'serving',
    'net wt',
    'distribut',
    'product of',
    'address',
    'tel no',
    'email',
    'www.',
    'http',
    'copyright',
    'made in',
    'best before',
    'lot no',
    'batch no',
    'mfg',
    'exp',
    'bb',
    'use by',
    'www',
    '.com',
    '.ph',
    'facebook',
    'instagram',
    'scan',
    'barcode',
    'allergen',
    'contains',
    'calories',
    'protein',
    'fat',
    'carb',
    'sugar',
    'serving size',
    'per 100',
    'nutrition facts',
  ];

  const validCandidates: string[] = [];

  for (const rawLine of extractedLines) {
    const line = rawLine.trim();
    if (!line || !isValidOcrLine(line)) continue;

    const lower = line.toLowerCase();

    // 1. Packaging noise filter
    if (noiseKeywords.some((kw) => lower.includes(kw))) {
      continue;
    }

    // 2. Letter / word length filter: must contain letters/words with length >= 3
    const words = line.split(/\s+/);
    const hasValidLetterWord = words.some((w) => w.replace(/[^a-zA-Z]/g, '').length >= 3);
    const hasValidDigitGroup = /\d{2,}/.test(line);

    if (!hasValidLetterWord && !hasValidDigitGroup) {
      continue;
    }

    // 3. Weight / Measurement filter (grams, kg, ml, L): must be >= 0.1g / 0.1ml / 0.1kg / 0.1L
    const weightMatch = line.match(/(\d+(?:\.\d+)?)\s*(g|kg|ml|l)\b/i);
    if (weightMatch) {
      const val = parseFloat(weightMatch[1]);
      if (isNaN(val) || val < 0.1) {
        continue; // Skip 0g or invalid measurement
      }
    }

    // 4. Price filter (₱, P, Php): must be >= ₱0.10
    const priceMatch = line.match(/(?:₱|PHP|Php|P)\s*(\d+(?:\.\d+)?)/i);
    if (priceMatch) {
      const val = parseFloat(priceMatch[1]);
      if (isNaN(val) || val < 0.1) {
        continue; // Skip ₱0 or ₱0.00
      }
    }

    // Check line total character count (at least 3 characters)
    if (line.length >= 3 && !validCandidates.includes(line)) {
      validCandidates.push(line);
    }
  }

  // Deduplicate and return top 3
  return validCandidates.slice(0, 3);
}

// Barcode Checksum Validation Helpers
function validateEAN13(code: string): boolean {
  if (!/^\d{13}$/.test(code)) return false;
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    const digit = parseInt(code[i], 10);
    sum += i % 2 === 0 ? digit : digit * 3;
  }
  const checkDigit = parseInt(code[12], 10);
  return (sum + checkDigit) % 10 === 0;
}

function validateEAN8(code: string): boolean {
  if (!/^\d{8}$/.test(code)) return false;
  let sum = 0;
  for (let i = 0; i < 7; i++) {
    const digit = parseInt(code[i], 10);
    sum += i % 2 === 0 ? digit * 3 : digit;
  }
  const checkDigit = parseInt(code[7], 10);
  return (sum + checkDigit) % 10 === 0;
}

function validateUPCA(code: string): boolean {
  if (!/^\d{12}$/.test(code)) return false;
  let sum = 0;
  for (let i = 0; i < 11; i++) {
    const digit = parseInt(code[i], 10);
    sum += i % 2 === 0 ? digit * 3 : digit;
  }
  const checkDigit = parseInt(code[11], 10);
  return (sum + checkDigit) % 10 === 0;
}

function validateBarcode(code: string): boolean {
  if (!code) return false;
  if (code.length === 13) return validateEAN13(code);
  if (code.length === 8) return validateEAN8(code);
  if (code.length === 12) return validateUPCA(code);
  return true; // CODE_128, QR, CODE_39, UPC_E, etc.
}

export const ScannerModal: React.FC<ScannerModalProps> = ({
  isOpen,
  onClose,
  onOpenAddItem,
  onTransactionSuccess,
  onScanSuccess,
  onScannedBuyerOrder,
  scanType = 'all',
  lang,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanIntervalRef = useRef<any>(null);
  const isProcessingOcrRef = useRef<boolean>(false);
  const barcodeDetectorRef = useRef<any>(null);
  const isMountedRef = useRef<boolean>(true);
  const isOpenRef = useRef<boolean>(isOpen);
  isOpenRef.current = isOpen;

  // Dual-mode state: 'barcode' vs 'text' (OCR)
  const [scanMode, setScanMode] = useState<'barcode' | 'text'>('barcode');
  const [isAiVisionLoading, setIsAiVisionLoading] = useState<boolean>(false);

  // Diagnostic HUD Overlay State for ML Kit Debugging
  const [showHud, setShowHud] = useState<boolean>(true);
  const [moduleStatus, setModuleStatus] = useState<MlKitModuleStatus | string>('BUNDLED/OK');
  const [frameTick, setFrameTick] = useState<number>(0);
  const [videoCanvasDims, setVideoCanvasDims] = useState<string>('0x0 -> 0x0');
  const [base64PayloadSize, setBase64PayloadSize] = useState<string>('0 chars');
  const [rawMlKitText, setRawMlKitText] = useState<string>('');
  const [lastOcrError, setLastOcrError] = useState<string>('None');

  // Checksum & Barcode Validation HUD Counters
  const [validScanCount, setValidScanCount] = useState<number>(0);
  const [rejectedScanCount, setRejectedScanCount] = useState<number>(0);
  const [lastRejectedBarcode, setLastRejectedBarcode] = useState<string>('');
  const [lastRejectedReason, setLastRejectedReason] = useState<string>('');
  const startNativeScanRef = useRef<(() => Promise<void>) | null>(null);

  // 2-Pass Hold-Steady Countdown State for OCR
  const [scanPhase, setScanPhase] = useState<'IDLE' | 'COUNTDOWN' | 'CONFIRMED'>('IDLE');
  const [countdown, setCountdown] = useState<number>(3);
  const [candidateText, setCandidateText] = useState<string | null>(null);
  const [recommendedNames, setRecommendedNames] = useState<string[]>([]);
  const candidateItemRef = useRef<InventoryItem | null>(null);
  const ocrHistoryRef = useRef<string[][]>([]);

  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [isPermanentlyDenied, setIsPermanentlyDenied] = useState<boolean>(false);
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const [isTorchOn, setIsTorchOn] = useState<boolean>(false);
  const userTorchPreferenceRef = useRef<boolean>(false);
  const [isScanning, setIsScanning] = useState<boolean>(true);
  const [isSleeping, setIsSleeping] = useState<boolean>(false);
  const [statusText, setStatusText] = useState<string>('Initializing camera...');

  // 60-Second Inactivity Sleep Timer Ref
  const inactivityTimerRef = useRef<any>(null);

  // Recognition outcome states
  const [recognizedItem, setRecognizedItem] = useState<InventoryItem | null>(null);
  const [detectedCode, setDetectedCode] = useState<string>('');
  const [detectedText, setDetectedText] = useState<string>('');
  const [isUnrecognizedFallback, setIsUnrecognizedFallback] = useState<boolean>(false);
  const [manualSearchInput, setManualSearchInput] = useState<string>('');

  // Multi-Item Scanned Cart State for rapid batch selling
  const [cartItems, setCartItems] = useState<CartItemEntry[]>([]);

  // QR Photo Upload Fallback (Minimal RAM, zero camera battery consumption)
  const qrFileInputRef = useRef<HTMLInputElement | null>(null);

  const handleQrPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setStatusText(
        lang === 'tl'
          ? 'Binabasa ang larawan ng QR...'
          : lang === 'ja'
          ? 'QR画像を解析中...'
          : lang === 'zh'
          ? '正在解析二维码图片...'
          : lang === 'ko'
          ? 'QR 이미지 분석 중...'
          : 'Analyzing QR image...'
      );

      const img = new Image();
      const objectUrl = URL.createObjectURL(file);

      img.onload = async () => {
        URL.revokeObjectURL(objectUrl);
        const tempCanvas = document.createElement('canvas');
        const tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });
        if (!tempCtx) return;

        // Downscale photos (e.g. 12MP-48MP camera photos) to max 1200px to avoid memory spikes
        const maxDim = 1200;
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        tempCanvas.width = Math.round(img.width * scale);
        tempCanvas.height = Math.round(img.height * scale);
        tempCtx.drawImage(img, 0, 0, tempCanvas.width, tempCanvas.height);

        let detected: string | null = null;

        // Try BarcodeDetector first (Native C++ zero-copy)
        if (typeof window !== 'undefined' && 'BarcodeDetector' in window) {
          try {
            const detector = new (window as any).BarcodeDetector({ formats: ['qr_code'] });
            const barcodes = await detector.detect(tempCanvas);
            if (barcodes && barcodes.length > 0 && barcodes[0].rawValue) {
              detected = barcodes[0].rawValue.trim();
            }
          } catch (_) {}
        }

        // Fallback to jsQR
        if (!detected) {
          try {
            const imgData = tempCtx.getImageData(0, 0, tempCanvas.width, tempCanvas.height);
            const qrCode = jsQR(imgData.data, imgData.width, imgData.height, {
              inversionAttempts: 'attemptBoth',
            });
            if (qrCode && qrCode.data) {
              detected = qrCode.data.trim();
            }
          } catch (err) {
            console.warn('[ScannerModal] QR photo jsQR error:', err);
          }
        }

        // Immediately release canvas buffer to keep RAM usage minimal
        tempCanvas.width = 1;
        tempCanvas.height = 1;

        if (detected) {
          resetInactivityTimer();
          await handleScannedBarcode(detected);
        } else {
          setStatusText(
            lang === 'tl'
              ? 'Walang nakitang QR code sa larawan. Subukan muli.'
              : lang === 'ja'
              ? '画像内にQRコードが見つかりませんでした。'
              : lang === 'zh'
              ? '未在图片中检测到二维码，请重试。'
              : lang === 'ko'
              ? '이미지에서 QR 코드를 찾을 수 없습니다. 다시 시도해 주세요.'
              : 'No QR code detected in the image. Please try again.'
          );
        }
      };

      img.onerror = () => {
        URL.revokeObjectURL(objectUrl);
        setStatusText(lang === 'tl' ? 'Hindi ma-load ang larawan.' : 'Failed to load image.');
      };

      img.src = objectUrl;
    } catch (err) {
      console.error('[ScannerModal] QR photo upload catch:', err);
    } finally {
      if (e.target) {
        e.target.value = '';
      }
    }
  };

  // Vibration feedback
  const triggerHapticFeedback = () => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([40, 60, 40]);
      } catch (_) {}
    }
  };

  // Reset inactivity sleep timer (25 seconds automatic timeout to preserve battery and prevent heating)
  const resetInactivityTimer = useCallback(() => {
    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
      inactivityTimerRef.current = null;
    }
    // Only schedule sleep timer if modal is open and not already sleeping or recognized
    inactivityTimerRef.current = setTimeout(() => {
      setIsSleeping(true);
      // HARDWARE BATTERY SAVER: Turn off torch and stop camera hardware tracks completely on sleep
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      setIsTorchOn(false);
    }, 25000);
  }, []);

  // Reset 2-Pass OCR Hold-Steady State Machine
  const resetOcrState = useCallback(() => {
    setScanPhase('IDLE');
    setCountdown(3);
    setCandidateText(null);
    setRecommendedNames([]);
    candidateItemRef.current = null;
    ocrHistoryRef.current = [];
  }, []);

  // Apply physical hardware torch setting
  const applyPhysicalTorch = useCallback(async (turnOn: boolean) => {
    if (!streamRef.current) return;
    try {
      const track = streamRef.current.getVideoTracks()[0];
      if (track) {
        const capabilities: any = track.getCapabilities ? track.getCapabilities() : {};
        if (capabilities.torch) {
          await (track as any).applyConstraints({
            advanced: [{ torch: turnOn }],
          });
          setIsTorchOn(turnOn);
        }
      }
    } catch (e) {
      console.warn('[ScannerModal] applyPhysicalTorch failed:', e);
    }
  }, []);

  // Common Barcode Lookup in Dexie Database
  const handleScannedBarcode = useCallback(async (barcodeVal: string) => {
    const cleanCode = barcodeVal.trim();
    if (!cleanCode) return;

    // 0. Dedicated QR-only Mode: Pass scanned payload directly to onScanSuccess with zero barcode overhead
    if (scanType === 'qr_only') {
      setIsScanning(false);
      applyPhysicalTorch(false);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      playScanBeep('success');
      triggerHapticFeedback();
      onScanSuccess?.(cleanCode);
      return;
    }

    // Check if code is a compressed or JSON Buyer Order / Store Catalog payload
    try {
      let decompressed = LZString.decompressFromEncodedURIComponent(cleanCode);
      if (!decompressed) decompressed = LZString.decompressFromBase64(cleanCode);
      if (!decompressed) decompressed = cleanCode;

      if (decompressed.startsWith('{') && decompressed.endsWith('}')) {
        const parsed = JSON.parse(decompressed);

        // 1. BUYER ORDER CHECK (MUST BE FIRST to prevent storeName collision with Store Catalog)
        if (
          parsed &&
          (parsed.type === 'BUYER_ORDER' || parsed.t === 'BO') &&
          (Array.isArray(parsed.items) || Array.isArray(parsed.i))
        ) {
          // Check expiration (30 minutes)
          if (parsed.ts && Date.now() - parsed.ts > 30 * 60 * 1000) {
            setIsScanning(false);
            playScanBeep('error');
            setStatusText(
              lang === 'tl'
                ? 'Expired na ang Buyer Order QR (30-min limit).'
                : 'Buyer Order QR has expired (30-min limit).'
            );
            setTimeout(() => setIsScanning(true), 2500);
            return;
          }

          // Check if order already processed
          const processed: string[] = JSON.parse(localStorage.getItem('processed_buyer_orders') || '[]');
          if (processed.includes(parsed.id)) {
            setIsScanning(false);
            playScanBeep('error');
            setStatusText(
              lang === 'tl'
                ? 'Nai-process na ang Buyer Order QR na ito!'
                : 'This Buyer Order QR has already been processed!'
            );
            setTimeout(() => setIsScanning(true), 2500);
            return;
          }

          // Valid Buyer Order -> trigger handler
          setIsScanning(false);
          playScanBeep('success');
          triggerHapticFeedback();
          applyPhysicalTorch(false);
          if (streamRef.current) {
            streamRef.current.getTracks().forEach((track) => track.stop());
            streamRef.current = null;
          }
          if (onScannedBuyerOrder) {
            onScannedBuyerOrder(parsed);
          } else {
            setStatusText(
              lang === 'tl'
                ? `Order mula kay ${parsed.buyerName || 'Buyer'} (${parsed.items.length} paninda)`
                : `Order from ${parsed.buyerName || 'Buyer'} (${parsed.items.length} items)`
            );
          }
          return;
        }

        // 2. STORE CATALOG QR CHECK (scanned in general mode or qr_only mode)
        if (
          parsed &&
          parsed.type !== 'BUYER_ORDER' &&
          (parsed.type === 'STORE_CATALOG' ||
            parsed.storeName ||
            parsed.t === 'SC' ||
            parsed.s ||
            Array.isArray(parsed.i))
        ) {
          setIsScanning(false);
          applyPhysicalTorch(false);
          if (streamRef.current) {
            streamRef.current.getTracks().forEach((track) => track.stop());
            streamRef.current = null;
          }
          playScanBeep('success');
          triggerHapticFeedback();
          onScanSuccess?.(cleanCode);
          return;
        }
      }
    } catch (_) {
      // Not a JSON/Buyer QR, proceed to barcode validation
    }

    // Checksum & format validation check
    if (!validateBarcode(cleanCode)) {
      setIsScanning(false);
      setRejectedScanCount((prev) => prev + 1);
      setLastRejectedBarcode(cleanCode);
      setLastRejectedReason(
        lang === 'tl'
          ? 'Mali ang checksum o pormat ng barcode'
          : 'Invalid barcode checksum or format'
      );
      playScanBeep('error');
      setStatusText(
        lang === 'tl'
          ? 'Mali ang nabasang barcode. Mag-scan ulit.'
          : 'Barcode misread. Please scan again.'
      );
      setTimeout(() => {
        setIsScanning(true);
        if (Capacitor.isNativePlatform() && scanMode === 'barcode') {
          startNativeScanRef.current?.();
        }
      }, 1500);
      return;
    }

    setValidScanCount((prev) => prev + 1);
    setDetectedCode(cleanCode);
    triggerHapticFeedback();

    const matchedBySku = await db.inventory
      .where('sku')
      .equalsIgnoreCase(cleanCode)
      .first();

    if (matchedBySku) {
      setIsScanning(false);
      setRecognizedItem(matchedBySku);
      // Temporarily dim/turn off torch and stop camera stream while reviewing product recognized modal
      applyPhysicalTorch(false);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      playScanBeep('success');
      setStatusText(lang === 'tl' ? 'Natukoy ang paninda!' : 'Item recognized by barcode!');
      onScanSuccess?.(matchedBySku.name);
    } else {
      // Barcode detected but not found in db: Show unrecognized fallback with prefilled SKU
      setIsScanning(false);
      setIsUnrecognizedFallback(true);
      applyPhysicalTorch(false);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      playScanBeep('error');
      setStatusText(
        lang === 'tl'
          ? 'Hindi pa nakatala ang barcode na ito. Idagdag sa paninda?'
          : 'Barcode not found in inventory. Add item?'
      );
      onScanSuccess?.(cleanCode);
    }
  }, [applyPhysicalTorch, lang, onScanSuccess]);

  // Common Text/OCR Lookup in Dexie Database
  const handleScannedText = useCallback(async (textVal: string, matchedItem?: InventoryItem) => {
    const cleanText = textVal.trim();
    if (!cleanText) return;

    setDetectedText(cleanText);
    triggerHapticFeedback();

    if (matchedItem) {
      setIsScanning(false);
      setRecognizedItem(matchedItem);
      applyPhysicalTorch(false);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      playScanBeep('success');
      setStatusText(lang === 'tl' ? 'Natukoy ang paninda sa teksto!' : 'Item recognized by text!');
      onScanSuccess?.(matchedItem.name);
    } else {
      // Unrecognized text -> fallback card
      setIsScanning(false);
      setIsUnrecognizedFallback(true);
      applyPhysicalTorch(false);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      playScanBeep('error');
      setStatusText(
        lang === 'tl'
          ? `Nabasa ang teksto: "${cleanText}". Idagdag sa paninda?`
          : `Recognized text: "${cleanText}". Add item to inventory?`
      );
      onScanSuccess?.(cleanText);
    }
  }, [applyPhysicalTorch, lang, onScanSuccess]);

  // AI Vision Lens for Stylized Packaging & 3D / Bubble Fonts
  const handleAiVisionLens = useCallback(async () => {
    if (isAiVisionLoading) return;
    setIsAiVisionLoading(true);
    setStatusText(
      lang === 'tl'
        ? '✨ AI Vision Lens: Sinusuri ang stylized packaging...'
        : '✨ AI Vision Lens: Analyzing stylized packaging...'
    );

    try {
      let base64Image = '';
      if (videoRef.current) {
        const canvas = document.createElement('canvas');
        canvas.width = videoRef.current.videoWidth || 640;
        canvas.height = videoRef.current.videoHeight || 480;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
          base64Image = canvas.toDataURL('image/jpeg', 0.85);
        }
      }

      if (!base64Image) {
        throw new Error('Unable to capture camera frame');
      }

      const allInventory = await db.inventory.toArray();
      const inventoryList = allInventory.map((i) => ({
        name: i.name,
        sku: i.sku || '',
        price: i.unitPrice,
      }));

      const response = await fetch('/api/gemini/recognize-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base64Image, inventoryList }),
      });

      const data = await response.json();

      if (data && data.productName) {
        const recognizedTitle = data.productName;
        const lower = recognizedTitle.toLowerCase();

        // Check if item exists in inventory
        const matched = allInventory.find(
          (inv) =>
            inv.name.toLowerCase() === lower ||
            (data.matchedSku && inv.sku && inv.sku.toLowerCase() === data.matchedSku.toLowerCase()) ||
            lower.includes(inv.name.toLowerCase()) ||
            inv.name.toLowerCase().includes(lower)
        );

        if (matched) {
          setIsScanning(false);
          setRecognizedItem(matched);
          applyPhysicalTorch(false);
          if (streamRef.current) {
            streamRef.current.getTracks().forEach((track) => track.stop());
            streamRef.current = null;
          }
          playScanBeep('success');
          setStatusText(
            lang === 'tl'
              ? `✨ Natukoy ng AI Vision: "${matched.name}"`
              : `✨ Recognized by AI Vision: "${matched.name}"`
          );
          onScanSuccess?.(matched.name);
        } else {
          setIsScanning(false);
          setIsUnrecognizedFallback(true);
          setDetectedText(recognizedTitle);
          applyPhysicalTorch(false);
          if (streamRef.current) {
            streamRef.current.getTracks().forEach((track) => track.stop());
            streamRef.current = null;
          }
          playScanBeep('error');
          setStatusText(
            lang === 'tl'
              ? `✨ Nabasa ng AI Vision: "${recognizedTitle}". Idagdag sa paninda?`
              : `✨ Extracted by AI Vision: "${recognizedTitle}". Add item to inventory?`
          );
          onScanSuccess?.(recognizedTitle);
        }
      } else {
        throw new Error(data?.error || 'Could not recognize product title');
      }
    } catch (err: any) {
      console.error('[ScannerModal] AI Vision Lens error:', err);
      playScanBeep('error');
      setStatusText(
        lang === 'tl'
          ? 'Hindi mabasa ang packaging. Subukang itapat nang maayos.'
          : 'Could not read packaging. Center item clearly and retry.'
      );
    } finally {
      setIsAiVisionLoading(false);
    }
  }, [applyPhysicalTorch, isAiVisionLoading, lang, onScanSuccess]);

  // Live Camera Stream initialization (used for Web, OCR mode, and in-app viewfinder fallback)
  const startCameraStream = useCallback(async () => {
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
        // Hardware sensor release buffer (crucial for Xiaomi/Redmi HyperOS and multi-lens cameras)
        await new Promise((resolve) => setTimeout(resolve, 150));
      }

      let stream: MediaStream | null = null;

      // Tier 1: Try ideal balanced resolution (1280x720 for dense QR or 960x540 for barcodes) to prevent phone heating
      try {
        const constraints: MediaStreamConstraints = {
          video: {
            facingMode: { ideal: cameraFacing },
            width: { ideal: scanType === 'qr_only' ? 1280 : 960 },
            height: { ideal: scanType === 'qr_only' ? 720 : 540 },
          },
          audio: false,
        };
        stream = await navigator.mediaDevices.getUserMedia(constraints);
      } catch (constraintErr1) {
        console.warn('[ScannerModal] Tier 1 constraints failed, trying facingMode only:', constraintErr1);
        try {
          // Tier 2: Try basic facing mode
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: cameraFacing },
            audio: false,
          });
        } catch (constraintErr2) {
          console.warn('[ScannerModal] Tier 2 facingMode failed, falling back to any camera:', constraintErr2);
          // Tier 3: Universal fallback
          stream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: false,
          });
        }
      }

      if (!stream) {
        throw new Error('Failed to acquire media stream');
      }

      // Check if modal was closed or component unmounted while awaiting camera hardware
      if (!isOpenRef.current || !isMountedRef.current) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        videoRef.current.muted = true;
        try {
          await videoRef.current.play();
        } catch (playErr) {
          console.warn('[ScannerModal] Video play catch:', playErr);
        }
      }

      setIsScanning(true);
      if (scanMode === 'text') {
        setStatusText(
          lang === 'tl'
            ? 'Inihanay ang teksto o presyo sa frame...'
            : 'Align text or price inside the frame...'
        );
      } else {
        setStatusText(
          lang === 'tl'
            ? 'Gamit ang built-in scanner...'
            : 'Using built-in scanner...'
        );
      }
    } catch (streamErr: any) {
      console.warn('[ScannerModal] MediaStream capture error:', streamErr);
      const isDenied =
        streamErr?.name === 'NotAllowedError' ||
        streamErr?.name === 'PermissionDeniedError' ||
        (typeof streamErr?.message === 'string' &&
          (streamErr.message.toLowerCase().includes('permission') || streamErr.message.toLowerCase().includes('denied')));
      const isNotFound = streamErr?.name === 'NotFoundError' || streamErr?.name === 'DevicesNotFoundError';

      if (isDenied) {
        setHasCameraPermission(false);
        setIsPermanentlyDenied(true);
        setStatusText(
          lang === 'tl'
            ? 'Pahintulot sa camera ay tinanggihan. I-allow sa settings.'
            : 'Camera permission was denied. Please allow camera in settings.'
        );
      } else if (isNotFound) {
        setHasCameraPermission(false);
        setStatusText(
          lang === 'tl'
            ? 'Walang nakitang camera sa device na ito.'
            : 'No camera hardware found on this device.'
        );
      } else {
        setStatusText(
          lang === 'tl'
            ? 'Hindi mabuksan ang camera. Subukang muli.'
            : 'Unable to start camera. Please try again.'
        );
      }
    }
  }, [cameraFacing, lang, scanMode]);

  // Native Android / iOS Option A: BarcodeScanner.scan() (Google ready-to-use scanner with fallback)
  const startNativeScan = useCallback(async () => {
    startNativeScanRef.current = startNativeScan;
    try {
      if (typeof BarcodeScanner === 'undefined') {
        console.warn('[ScannerModal] BarcodeScanner object is undefined. Falling back to built-in camera.');
        setStatusText(
          lang === 'tl'
            ? 'Gamit ang built-in scanner...'
            : 'Using built-in scanner...'
        );
        await startCameraStream();
        return;
      }

      // Check / install Google Barcode Scanner ML Kit module on Android
      try {
        await prepareGoogleBarcodeScannerModule();
      } catch (modErr) {
        console.warn('[ScannerModal] Google Barcode module check skipped/notice:', modErr);
      }

      // Active status for Google Play Services scanner
      setStatusText(
        lang === 'tl'
          ? 'Gamit ang device scanner...'
          : 'Using device scanner...'
      );
      setIsScanning(true);

      try {
        const formats =
          scanType === 'qr_only'
            ? [BarcodeFormat.QrCode]
            : [
                BarcodeFormat.Ean13,
                BarcodeFormat.Ean8,
                BarcodeFormat.UpcA,
                BarcodeFormat.UpcE,
                BarcodeFormat.Code128,
                BarcodeFormat.Code39,
                BarcodeFormat.QrCode,
              ];

        const scanResult = await BarcodeScanner.scan({ formats });

        if (scanResult && scanResult.barcodes && scanResult.barcodes.length > 0) {
          const detected = scanResult.barcodes[0].rawValue?.trim();
          if (detected) {
            await handleScannedBarcode(detected);
          } else {
            setIsScanning(false);
            setStatusText(lang === 'tl' ? 'Walang nabasang code.' : 'No code detected.');
          }
        } else {
          setIsScanning(false);
          setStatusText(
            lang === 'tl'
              ? 'Na-dismiss ang scanner. Pindutin ang I-scan Ulit para subukan.'
              : 'Scanner dismissed. Tap Re-scan to try again.'
          );
        }
      } catch (innerScanErr: any) {
        const innerMsg = (innerScanErr?.message || String(innerScanErr || '')).toLowerCase();
        if (
          innerMsg.includes('not supported') ||
          innerMsg.includes('not available') ||
          innerMsg.includes('module not found') ||
          innerMsg.includes('unavailable') ||
          innerMsg.includes('unimplemented') ||
          innerMsg.includes('not implemented')
        ) {
          console.warn('[ScannerModal] Google BarcodeScanner not available on device, falling back to HTML5 stream:', innerScanErr);
          setStatusText(
            lang === 'tl'
              ? 'Gamit ang built-in scanner...'
              : 'Using built-in scanner...'
          );
          await startCameraStream();
        } else {
          throw innerScanErr;
        }
      }
    } catch (scanErr: any) {
      console.warn('[ScannerModal] Native BarcodeScanner.scan() notice or error:', scanErr);
      const errMsg = (scanErr?.message || String(scanErr || '')).toLowerCase();
      setIsScanning(false);

      if (errMsg.includes('cancel') || errMsg.includes('dismiss') || errMsg.includes('closed')) {
        setStatusText(
          lang === 'tl'
            ? 'Na-dismiss ang scanner. Pindutin ang I-scan Ulit para subukan.'
            : 'Scanner dismissed. Tap Re-scan to try again.'
        );
      } else if (errMsg.includes('permission') || errMsg.includes('denied')) {
        setHasCameraPermission(false);
        setIsPermanentlyDenied(true);
        setStatusText(
          lang === 'tl'
            ? 'Pahintulot sa camera ay tinanggihan. I-allow sa settings.'
            : 'Camera permission was denied. Please allow camera in settings.'
        );
      } else if (
        errMsg.includes('not supported') ||
        errMsg.includes('not available') ||
        errMsg.includes('module not found') ||
        errMsg.includes('unavailable') ||
        errMsg.includes('unimplemented')
      ) {
        setStatusText(
          lang === 'tl'
            ? 'Gamit ang built-in scanner...'
            : 'Using built-in scanner...'
        );
        await startCameraStream();
      } else {
        setStatusText(
          lang === 'tl'
            ? 'Hindi mabuksan ang camera. Subukang muli.'
            : 'Unable to start camera. Please try again.'
        );
      }
    }
  }, [handleScannedBarcode, lang, startCameraStream]);

  // Main Camera & Scanner Entrypoint
  const startCamera = useCallback(async () => {
    try {
      const isNative = Capacitor.isNativePlatform();
      const currentPlatform = Capacitor.getPlatform();

      setStatusText(
        lang === 'tl'
          ? 'Inihahanda ang scanner...'
          : 'Preparing scanner...'
      );

      // Stop previous browser video tracks if any
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }

      // 1. Android Native Barcode Mode: Uses Google Play Services BarcodeScanner.scan()
      if (isNative && currentPlatform === 'android' && scanMode === 'barcode') {
        setHasCameraPermission(true);
        setIsPermanentlyDenied(false);
        await startNativeScan();
        return;
      }

      // 2. iOS or other native platform permission flow
      if (isNative) {
        const permResult = await ensureCameraPermission();

        if (!permResult.granted) {
          setHasCameraPermission(false);
          setIsPermanentlyDenied(permResult.permanentlyDenied);
          setStatusText(
            permResult.permanentlyDenied
              ? (lang === 'tl' ? 'Pahintulot sa camera ay naka-off sa Settings.' : 'Camera permission is disabled in App Settings.')
              : (lang === 'tl' ? 'Kailangan ang pahintulot sa camera para makapag-scan.' : 'Camera permission is required for scanning.')
          );
          return;
        }

        setHasCameraPermission(true);
        setIsPermanentlyDenied(false);

        if (scanMode === 'barcode') {
          await startNativeScan();
          return;
        } else {
          // Text Recognition Mode on native: Start video feed for OCR frame capture
          await startCameraStream();
          return;
        }
      }

      // 3. Web / Laptop Browser Preview Fallback
      const permResult = await ensureCameraPermission();
      if (!permResult.granted) {
        setHasCameraPermission(false);
        setIsPermanentlyDenied(permResult.permanentlyDenied);
        setStatusText(
          lang === 'tl'
            ? 'Kailangan ang pahintulot sa camera sa browser.'
            : 'Browser camera permission required.'
        );
        return;
      }

      setHasCameraPermission(true);
      setIsPermanentlyDenied(false);
      await startCameraStream();
    } catch (err: any) {
      console.warn('[ScannerModal] Camera initialization error:', err);
      const isDenied =
        err?.name === 'NotAllowedError' ||
        err?.name === 'PermissionDeniedError' ||
        (typeof err?.message === 'string' &&
          (err.message.toLowerCase().includes('permission') || err.message.toLowerCase().includes('denied')));

      if (isDenied) {
        setHasCameraPermission(false);
        setIsPermanentlyDenied(true);
      } else {
        setStatusText(
          lang === 'tl'
            ? 'Hindi mabuksan ang camera. Subukang muli.'
            : 'Unable to start camera. Please try again.'
        );
      }
    }
  }, [lang, scanMode, startCameraStream, startNativeScan]);

  // Wake scanner from sleep mode and re-start camera hardware
  const wakeScanner = useCallback(() => {
    triggerHapticFeedback();
    setIsSleeping(false);
    resetInactivityTimer();
    startCamera();
    if (userTorchPreferenceRef.current) {
      applyPhysicalTorch(true);
    }
  }, [applyPhysicalTorch, resetInactivityTimer, startCamera]);

  // Stop camera when closing
  const stopCamera = useCallback(() => {
    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
      inactivityTimerRef.current = null;
    }
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current);
      scanIntervalRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    // Free canvas GPU/RAM backing buffer
    if (canvasRef.current) {
      canvasRef.current.width = 0;
      canvasRef.current.height = 0;
    }
  }, []);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    if (isOpen) {
      setIsSleeping(false);
      setIsUnrecognizedFallback(false);
      setRecognizedItem(null);
      setDetectedCode('');
      setDetectedText('');
      resetOcrState();
      resetInactivityTimer();
      startCamera();
    } else {
      setIsSleeping(false);
      resetOcrState();
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isOpen, resetInactivityTimer, resetOcrState, startCamera, stopCamera]);

  // Handle Mode Switch (Barcode vs Text OCR)
  const handleSwitchMode = (newMode: 'barcode' | 'text') => {
    resetInactivityTimer();
    if (isSleeping) setIsSleeping(false);
    if (scanMode === newMode) return;
    setScanMode(newMode);
    setIsUnrecognizedFallback(false);
    setRecognizedItem(null);
    setDetectedCode('');
    setDetectedText('');
    resetOcrState();
    setIsScanning(true);

    if (newMode === 'text') {
      setStatusText(
        lang === 'tl'
          ? 'Inihanay ang teksto o presyo sa frame...'
          : 'Align text or price inside the frame...'
      );
      try {
        prepareGoogleTextRecognitionModule((status) => {
          setModuleStatus(status === 'ERROR' ? 'BUNDLED/OK' : status);
        }).catch(() => {
          setModuleStatus('BUNDLED/OK');
        });
      } catch (_) {
        setModuleStatus('BUNDLED/OK');
      }
      // Ensure camera stream is running for text OCR
      if (!streamRef.current) {
        startCameraStream();
      }
    } else {
      setStatusText(
        lang === 'tl'
          ? 'Inihahanda ang barcode scanner...'
          : 'Preparing barcode scanner...'
      );
      if (Capacitor.isNativePlatform()) {
        startNativeScan();
      } else if (!streamRef.current) {
        startCameraStream();
      }
    }
  };

  // Toggle Torch / Flashlight (User manual intent)
  const handleToggleTorch = async () => {
    resetInactivityTimer();
    if (isSleeping) setIsSleeping(false);
    const nextTorch = !isTorchOn;
    userTorchPreferenceRef.current = nextTorch;
    await applyPhysicalTorch(nextTorch);
  };

  // Flip Camera Front / Back
  const handleFlipCamera = () => {
    resetInactivityTimer();
    if (isSleeping) setIsSleeping(false);
    setCameraFacing((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  // 2. Core Frame Processing (Barcode vs Text OCR)
  const processFrame = useCallback(async () => {
    if (
      !videoRef.current ||
      !canvasRef.current ||
      !isScanning ||
      isSleeping ||
      recognizedItem ||
      isUnrecognizedFallback ||
      isProcessingOcrRef.current
    ) {
      return;
    }

    const video = videoRef.current;
    // Platform & Canvas Safety: Ensure video has valid frame data before drawing
    if (video.readyState < 2 || video.videoWidth <= 0 || video.videoHeight <= 0) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    // DEDICATED QR ONLY MODE (Ultra fast, battery-friendly, direct 2D QR decoding)
    if (scanType === 'qr_only') {
      let foundQr: string | null = null;

      const vWidth = video.videoWidth;
      const vHeight = video.videoHeight;
      // High-resolution full frame without cropping (matches photo upload pipeline to capture dense Store Catalog QRs)
      const maxDim = 1000;
      const scale = Math.min(1, maxDim / Math.max(vWidth, vHeight));
      const drawWidth = Math.round(vWidth * scale);
      const drawHeight = Math.round(vHeight * scale);

      // Only resize canvas if dimensions changed to eliminate GC churn and keep RAM footprint tiny (~2MB)
      if (canvas.width !== drawWidth || canvas.height !== drawHeight) {
        canvas.width = drawWidth;
        canvas.height = drawHeight;
      }
      ctx.drawImage(video, 0, 0, drawWidth, drawHeight);

      // 1. Native C++ BarcodeDetector on canvas (Direct sRGB buffer, instant ~3ms detection for dense QRs)
      if (typeof window !== 'undefined' && 'BarcodeDetector' in window) {
        try {
          if (!barcodeDetectorRef.current) {
            barcodeDetectorRef.current = new (window as any).BarcodeDetector({
              formats: ['qr_code'],
            });
          }
          const barcodes = await barcodeDetectorRef.current.detect(canvas);
          if (barcodes && barcodes.length > 0 && barcodes[0].rawValue) {
            foundQr = barcodes[0].rawValue.trim();
          }
        } catch (_) {}
      }

      // 2. High-performance fallback: jsQR with attemptBoth on the full uncropped frame
      if (!foundQr) {
        try {
          const imgData = ctx.getImageData(0, 0, drawWidth, drawHeight);
          const code = jsQR(imgData.data, imgData.width, imgData.height, {
            inversionAttempts: 'attemptBoth',
          });
          if (code && code.data) {
            foundQr = code.data.trim();
          }
        } catch (err) {
          console.warn('[ScannerModal] jsQR decode notice:', err);
        }
      }

      if (foundQr) {
        resetInactivityTimer();
        await handleScannedBarcode(foundQr);
        return;
      }
      return;
    }

    // MODE 1: BARCODE SCANNING (Ultra-responsive, zero GC churn, battery optimized)
    if (scanMode === 'barcode') {
      let foundBarcode: string | null = null;

      // 1. Direct hardware-accelerated decode from video element (Zero canvas copy, 0 extra RAM)
      if (typeof window !== 'undefined' && 'BarcodeDetector' in window) {
        try {
          if (!barcodeDetectorRef.current) {
            barcodeDetectorRef.current = new (window as any).BarcodeDetector({
              formats: ['qr_code', 'ean_13', 'ean_8', 'code_128', 'code_39', 'upc_a', 'upc_e'],
            });
          }
          const barcodes = await barcodeDetectorRef.current.detect(video);
          if (barcodes && barcodes.length > 0 && barcodes[0].rawValue) {
            foundBarcode = barcodes[0].rawValue.trim();
          }
        } catch (_) {}
      }

      // 2. High-performance software fallback: Upright canvas with jsQR and ZXing support
      if (!foundBarcode) {
        const vWidth = video.videoWidth;
        const vHeight = video.videoHeight;
        const maxDim = 800; // Balanced resolution to preserve RAM and avoid thermal throttling
        const scale = Math.min(maxDim / vWidth, maxDim / vHeight, 1);
        const drawWidth = Math.round(vWidth * scale);
        const drawHeight = Math.round(vHeight * scale);

        // Only resize canvas if dimensions actually changed
        if (canvas.width !== drawWidth || canvas.height !== drawHeight) {
          canvas.width = drawWidth;
          canvas.height = drawHeight;
        }

        ctx.drawImage(video, 0, 0, drawWidth, drawHeight);

        // Hardware decode on canvas if direct video detection returned empty
        if (typeof window !== 'undefined' && 'BarcodeDetector' in window && barcodeDetectorRef.current) {
          try {
            const canvasBarcodes = await barcodeDetectorRef.current.detect(canvas);
            if (canvasBarcodes && canvasBarcodes.length > 0 && canvasBarcodes[0].rawValue) {
              foundBarcode = canvasBarcodes[0].rawValue.trim();
            }
          } catch (_) {}
        }

        // Quick QR decode attempt on canvas
        if (!foundBarcode) {
          try {
            const imgData = ctx.getImageData(0, 0, drawWidth, drawHeight);
            const qrCode = jsQR(imgData.data, imgData.width, imgData.height, {
              inversionAttempts: 'dontInvert',
            });
            if (qrCode && qrCode.data) {
              foundBarcode = qrCode.data.trim();
            }
          } catch (_) {}
        }
      }

      if (foundBarcode) {
        resetInactivityTimer();
        await handleScannedBarcode(foundBarcode);
        return;
      }
      return;
    }

    // Downscale off-screen canvas max dimension to 1024px while strictly preserving aspect ratio
    const vWidth = video.videoWidth;
    const vHeight = video.videoHeight;
    const maxDim = 1024;
    const scale = Math.min(maxDim / vWidth, maxDim / vHeight, 1);
    const drawWidth = Math.round(vWidth * scale);
    const drawHeight = Math.round(vHeight * scale);

    if (canvas.width !== drawWidth || canvas.height !== drawHeight) {
      canvas.width = drawWidth;
      canvas.height = drawHeight;
    }
    ctx.drawImage(video, 0, 0, drawWidth, drawHeight);

    // MODE 2: TEXT RECOGNITION (OCR / Label / Price / Item name)
    if (scanMode === 'text') {
      isProcessingOcrRef.current = true;
      setFrameTick((t) => t + 1);
      try {
        // WEB VS NATIVE EXECUTION GUARD
        if (!Capacitor.isNativePlatform()) {
          // Web / Brave browser simulation mode: skip native plugin call to avoid exceptions
          if (scanPhase === 'IDLE') {
            setStatusText(
              lang === 'tl'
                ? 'OCR simulation mode active (Nasa browser)'
                : 'OCR simulation mode active'
            );
          }
          isProcessingOcrRef.current = false;
          return;
        }

        // GOOGLE PLAY SERVICES OCR MODULE CHECK (Android Native) - Non-blocking try/catch
        if (Capacitor.getPlatform() === 'android') {
          try {
            await prepareGoogleTextRecognitionModule((status) => {
              setModuleStatus(status === 'ERROR' ? 'BUNDLED/OK' : status);
            });
          } catch (_) {
            setModuleStatus('BUNDLED/OK');
          }
        }

        // Canvas Grayscale + Contrast Optimization for clean ML Kit Text Recognition
        try {
          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const d = imgData.data;
          const contrast = 1.35; // 35% contrast boost
          const factor = (259 * (contrast * 255 + 255)) / (255 * (259 - contrast * 255));

          for (let i = 0; i < d.length; i += 4) {
            // Perceptual luminance calculation (ITU-R BT.601)
            const gray = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
            const adjusted = factor * (gray - 128) + 128;
            const clamped = adjusted < 0 ? 0 : adjusted > 255 ? 255 : adjusted;
            d[i] = clamped;
            d[i + 1] = clamped;
            d[i + 2] = clamped;
          }
          ctx.putImageData(imgData, 0, 0);
        } catch (imgEnhanceErr) {
          console.warn('[ScannerModal] Canvas preprocessing notice:', imgEnhanceErr);
        }

        const rawBase64 = canvas.toDataURL('image/jpeg', 0.85);
        const cleanBase64 = rawBase64.replace(/^data:image\/(png|jpeg|jpg);base64,/, '');

        setBase64PayloadSize(
          `${cleanBase64.length.toLocaleString()} chars (~${Math.round(
            (cleanBase64.length * 0.75) / 1024
          )}KB)`
        );

        if (cleanBase64.length <= 500) {
          setLastOcrError('Base64 payload under 500 chars limit (Skipped)');
          isProcessingOcrRef.current = false;
          return;
        }

        let ocrResultObj: any = null;

        // Execute Capacitor ML Kit Text Recognition with Native Android Safety
        try {
          if (TextRecognition) {
            // Save temporary image to native filesystem cache to provide valid file:/// URI
            let fileUri: string | null = null;
            try {
              const tempSavedFile = await Filesystem.writeFile({
                path: 'ocr_temp.jpg',
                data: cleanBase64,
                directory: Directory.Cache,
              });
              fileUri = tempSavedFile.uri;
            } catch (fsErr) {
              console.warn('[ScannerModal] Filesystem cache write notice:', fsErr);
            }

            if (typeof (TextRecognition as any).processImage === 'function') {
              if (fileUri) {
                ocrResultObj = await (TextRecognition as any).processImage({
                  path: fileUri,
                });
              } else {
                ocrResultObj = await (TextRecognition as any).processImage({
                  path: rawBase64,
                  base64Data: cleanBase64,
                });
              }
            } else if (typeof (TextRecognition as any).readText === 'function') {
              ocrResultObj = await (TextRecognition as any).readText({
                path: fileUri || rawBase64,
                base64Data: cleanBase64,
              });
            }
          }
        } catch (mlKitErr: any) {
          const errDiag = mlKitErr?.message || String(mlKitErr || '');
          setLastOcrError(errDiag);
          console.warn('[ScannerModal] TextRecognition ML Kit notice:', mlKitErr);
          if (Capacitor.isNativePlatform()) {
            setStatusText(
              lang === 'tl'
                ? `Native OCR notice: ${errDiag.slice(0, 30)}`
                : `Native OCR notice: ${errDiag.slice(0, 30)}`
            );
          }
        }

        const detectedRawStr =
          ocrResultObj?.text ||
          (Array.isArray(ocrResultObj?.blocks)
            ? ocrResultObj.blocks.map((b: any) => b.text || '').join(' ')
            : '');
        setRawMlKitText(detectedRawStr || '(No text detected)');
        if (ocrResultObj) {
          setModuleStatus((prev) => (prev === 'ERROR' ? 'BUNDLED/OK' : prev));
        }

        // Reset inactivity timer if text was detected by ML Kit (even if not matched to an item)
        if (detectedRawStr && detectedRawStr.trim().length > 0) {
          resetInactivityTimer();
        }

        // Structured Block, Line, and Token Parsing
        const extractedLines: string[] = [];
        const extractedTokens: string[] = [];

        if (ocrResultObj?.blocks && Array.isArray(ocrResultObj.blocks) && ocrResultObj.blocks.length > 0) {
          for (const block of ocrResultObj.blocks) {
            if (block.lines && Array.isArray(block.lines) && block.lines.length > 0) {
              for (const line of block.lines) {
                const normalizedLine = normalizeOcrText(line.text || '');
                if (isValidOcrLine(normalizedLine)) {
                  extractedLines.push(normalizedLine);
                  normalizedLine.split(/\s+/).forEach((tok) => {
                    const cleanTok = tok.trim().toLowerCase();
                    if (cleanTok.length >= 2) extractedTokens.push(cleanTok);
                  });
                }
              }
            } else if (block.text) {
              const normalizedBlock = normalizeOcrText(block.text);
              if (isValidOcrLine(normalizedBlock)) {
                extractedLines.push(normalizedBlock);
                normalizedBlock.split(/\s+/).forEach((tok) => {
                  const cleanTok = tok.trim().toLowerCase();
                  if (cleanTok.length >= 2) extractedTokens.push(cleanTok);
                });
              }
            }
          }
        }

        // Top-level raw text fallback if structured blocks were empty
        if (extractedLines.length === 0 && ocrResultObj?.text) {
          const normalizedRaw = normalizeOcrText(ocrResultObj.text);
          normalizedRaw.split('\n').forEach((l) => {
            const trimmed = l.trim();
            if (isValidOcrLine(trimmed)) {
              extractedLines.push(trimmed);
              trimmed.split(/\s+/).forEach((tok) => {
                const cleanTok = tok.trim().toLowerCase();
                if (cleanTok.length >= 2) extractedTokens.push(cleanTok);
              });
            }
          });
        }

        // Maintain 3-frame history buffer for temporal consistency
        if (extractedLines.length > 0) {
          ocrHistoryRef.current.push(extractedLines);
          if (ocrHistoryRef.current.length > 3) {
            ocrHistoryRef.current.shift();
          }
        }

        // Candidate Detection & Matching with Fuzzy OCR & Typo Resilience
        let foundCandidateText: string | null = null;
        let foundMatchedItem: InventoryItem | undefined = undefined;

        if (extractedLines.length > 0) {
          const allItems = await db.inventory.toArray();

          // Priority 1: Match whole line against inventory item name (exact or fuzzy OCR)
          if (allItems.length > 0) {
            for (const item of allItems) {
              const itemNameLower = item.name.toLowerCase();
              const itemNameFuzzy = normalizeOcrFuzzy(item.name);

              const lineMatch = extractedLines.some((line) => {
                const lineLower = line.toLowerCase();
                const lineFuzzy = normalizeOcrFuzzy(line);

                // Exact substring
                if (lineLower.includes(itemNameLower) || itemNameLower.includes(lineLower)) {
                  return true;
                }

                // Fuzzy character swap match or Levenshtein similarity >= 0.85
                if (itemNameFuzzy.length >= 3 && lineFuzzy.length >= 3) {
                  if (lineFuzzy.includes(itemNameFuzzy) || itemNameFuzzy.includes(lineFuzzy)) {
                    return true;
                  }
                  if (getSimilarityRatio(itemNameFuzzy, lineFuzzy) >= 0.85) {
                    return true;
                  }
                }
                return false;
              });

              if (lineMatch) {
                foundMatchedItem = item;
                foundCandidateText = item.name;
                break;
              }
            }
          }

          // Priority 2: Multi-token match across words
          if (!foundMatchedItem && allItems.length > 0 && extractedTokens.length > 0) {
            for (const item of allItems) {
              const itemTokens = item.name.toLowerCase().split(/\s+/).filter((t) => t.length >= 2);
              if (itemTokens.length === 0) continue;

              const matchedCount = itemTokens.filter((token) => {
                const fuzzyTok = normalizeOcrFuzzy(token);
                return extractedTokens.some((word) => {
                  const fuzzyWord = normalizeOcrFuzzy(word);
                  return (
                    word.includes(token) ||
                    token.includes(word) ||
                    (fuzzyTok.length >= 3 && fuzzyWord.length >= 3 && getSimilarityRatio(fuzzyTok, fuzzyWord) >= 0.82)
                  );
                });
              }).length;

              // Require at least 2 matching tokens for multi-word inventory names
              const minRequired = itemTokens.length > 1 ? Math.max(2, Math.ceil(itemTokens.length * 0.6)) : 1;
              if (matchedCount >= minRequired) {
                foundMatchedItem = item;
                foundCandidateText = item.name;
                break;
              }
            }
          }

          // Priority 3: Extract top 3 recommended product names if no inventory item matched
          if (!foundMatchedItem) {
            const topRecommended = filterAndRankRecommendedNames(extractedLines);
            setRecommendedNames(topRecommended);
            if (topRecommended.length > 0) {
              foundCandidateText = topRecommended[0];
            }
          } else {
            setRecommendedNames([]);
          }

          // TEMPORAL CONSISTENCY CHECK: Reject one-off frame candidates unless present in at least 2 of last 3 frames
          if (foundCandidateText && !isTemporallyConsistent(foundCandidateText, ocrHistoryRef.current)) {
            foundCandidateText = null;
            foundMatchedItem = undefined;
          }
        }

        // 2-PASS OCR STATE MACHINE & INSTANT CUT-THROUGH HANDLING
        if (foundMatchedItem) {
          // INSTANT CUT-THROUGH (0s delay): Item exists in store inventory -> Trigger modal immediately!
          setCandidateText(foundMatchedItem.name);
          candidateItemRef.current = foundMatchedItem;
          setScanPhase('CONFIRMED');
          setStatusText(
            lang === 'tl' ? 'Natukoy ang paninda sa bodega!' : 'Item recognized in inventory!'
          );
          handleScannedText(foundMatchedItem.name, foundMatchedItem);
          isProcessingOcrRef.current = false;
          return;
        }

        if (foundCandidateText) {
          // UNCATALOGUED ITEM (First time scanning): Cut countdown cleanly & show recommended name chips.
          // Do NOT pop up modal automatically until user selects a name chip.
          setCandidateText(foundCandidateText);
          candidateItemRef.current = null;
          setScanPhase('CONFIRMED');
          setStatusText(
            lang === 'tl'
              ? 'Pumili sa mga mungkahing pangalan sa ibaba:'
              : 'Select a product name from recommendations below:'
          );
        } else {
          // RESET SAFEGUARD: Camera moved away / no text in frame
          if (scanPhase === 'COUNTDOWN' || scanPhase === 'CONFIRMED') {
            resetOcrState();
            setStatusText(
              lang === 'tl'
                ? 'Inihanay ang teksto o presyo sa frame...'
                : 'Align text or price inside the frame...'
            );
          } else if (scanPhase === 'IDLE') {
            setStatusText(
              lang === 'tl'
                ? 'Inihanay ang teksto o presyo sa frame...'
                : 'Align text or price inside the frame...'
            );
          }
        }
      } catch (ocrCatchErr: any) {
        console.warn('[ScannerModal] OCR processing frame error:', ocrCatchErr);
        // CRITICAL: Maintain active stream and do NOT set permission to false
        if (scanPhase === 'COUNTDOWN') {
          resetOcrState();
        }
        setStatusText(
          lang === 'tl'
            ? 'Inihanay ang teksto o presyo sa frame...'
            : 'Align text or price inside the frame...'
        );
      } finally {
        isProcessingOcrRef.current = false;
      }
    }
  }, [
    handleScannedBarcode,
    isScanning,
    isSleeping,
    isUnrecognizedFallback,
    lang,
    recognizedItem,
    resetInactivityTimer,
    resetOcrState,
    scanMode,
    scanPhase,
  ]);

  // Two-Pass Countdown Interval Controller
  useEffect(() => {
    let timer: any = null;
    if (
      scanMode === 'text' &&
      scanPhase === 'COUNTDOWN' &&
      isScanning &&
      !isSleeping &&
      !recognizedItem &&
      !isUnrecognizedFallback
    ) {
      if (countdown > 0) {
        setStatusText(
          lang === 'tl'
            ? `Ipanatag ang camera... ${countdown}s`
            : `Hold camera steady... ${countdown}s`
        );
        timer = setInterval(() => {
          setCountdown((prev) => (prev > 1 ? prev - 1 : 0));
        }, 1000);
      } else if (countdown === 0 && candidateText && scanPhase === 'COUNTDOWN') {
        setScanPhase('CONFIRMED');
        if (candidateItemRef.current) {
          handleScannedText(candidateText, candidateItemRef.current);
        } else {
          setStatusText(
            lang === 'tl'
              ? 'Pumili sa mga mungkahing pangalan sa ibaba:'
              : 'Select a product name from recommendations below:'
          );
        }
      }
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [
    scanMode,
    scanPhase,
    countdown,
    candidateText,
    isScanning,
    isSleeping,
    recognizedItem,
    isUnrecognizedFallback,
    lang,
    handleScannedText,
  ]);

  // Page Visibility Listener: Minimize/Lock Screen Hardware Power Down
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        // App minimized or tab switched: immediately stop camera tracks and turn off torch to conserve battery
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((track) => track.stop());
          streamRef.current = null;
        }
        setIsTorchOn(false);
      } else if (isOpen && isScanning && !isSleeping && !recognizedItem && !isUnrecognizedFallback) {
        // App restored: re-open camera feed if scanner was active
        startCamera();
        if (userTorchPreferenceRef.current) {
          applyPhysicalTorch(true);
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isOpen, isScanning, isSleeping, recognizedItem, isUnrecognizedFallback, startCamera, applyPhysicalTorch]);

  // Run scanning loop (paused when sleeping or hidden)
  useEffect(() => {
    if (isOpen && isScanning && !isSleeping && hasCameraPermission) {
      // 200ms for QR-only mode (ultra-responsive with low CPU footprint); 350ms for dual mode
      const loopInterval = scanType === 'qr_only' ? 200 : 350;
      scanIntervalRef.current = setInterval(() => {
        processFrame();
      }, loopInterval);
    } else {
      if (scanIntervalRef.current) {
        clearInterval(scanIntervalRef.current);
        scanIntervalRef.current = null;
      }
    }
    return () => {
      if (scanIntervalRef.current) {
        clearInterval(scanIntervalRef.current);
        scanIntervalRef.current = null;
      }
    };
  }, [isOpen, isScanning, isSleeping, hasCameraPermission, processFrame, scanType]);

  // Restart Scan
  const handleRestartScan = () => {
    resetInactivityTimer();
    setIsSleeping(false);
    setRecognizedItem(null);
    setDetectedCode('');
    setDetectedText('');
    setIsUnrecognizedFallback(false);
    resetOcrState();
    setIsScanning(true);

    // Restore torch if user had enabled it before scan, otherwise stay off
    if (userTorchPreferenceRef.current) {
      applyPhysicalTorch(true);
    } else {
      applyPhysicalTorch(false);
    }

    if (scanMode === 'text') {
      setStatusText(
        lang === 'tl'
          ? 'Inihanay ang teksto o presyo sa frame...'
          : 'Align text or price inside the frame...'
      );
      if (!streamRef.current) {
        startCameraStream();
      }
    } else {
      setStatusText(
        lang === 'tl'
          ? 'Nagsa-scan ng barcode...'
          : 'Scanning barcode...'
      );
      if (Capacitor.isNativePlatform()) {
        startNativeScan();
      } else if (!streamRef.current) {
        startCameraStream();
      }
    }
  };

  // Trigger Add Item Modal
  const handleAddUnrecognizedItem = () => {
    resetInactivityTimer();
    onClose();
    onOpenAddItem({
      sku: detectedCode || undefined,
      name: detectedText || undefined,
    });
  };

  // Manual search fallback in scanner
  const handleManualSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    resetInactivityTimer();
    if (isSleeping) setIsSleeping(false);
    if (!manualSearchInput.trim()) return;

    if (scanType === 'qr_only') {
      setIsScanning(false);
      applyPhysicalTorch(false);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
      playScanBeep('success');
      triggerHapticFeedback();
      onScanSuccess?.(manualSearchInput.trim());
      return;
    }

    const term = manualSearchInput.trim().toLowerCase();
    const found = await db.inventory
      .filter((item) =>
        item.name.toLowerCase().includes(term) ||
        (item.sku && item.sku.toLowerCase().includes(term))
      )
      .first();

    if (found) {
      setIsScanning(false);
      setRecognizedItem(found);
      onScanSuccess?.(found.name);
    } else {
      setIsUnrecognizedFallback(true);
      setDetectedText(manualSearchInput.trim());
      onScanSuccess?.(manualSearchInput.trim());
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black flex flex-col justify-between overflow-hidden animate-in fade-in select-none">
        {/* TOP CAMERA CONTROLS BAR */}
        <div className="safe-pt-header px-4 py-3 bg-gradient-to-b from-black/80 via-black/40 to-transparent z-20 flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                <Camera className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-white font-black text-sm tracking-wide">
                  {getScannerTitle(scanType, lang)}
                </h2>
                <p className="text-[11px] text-white/70 font-medium truncate max-w-[180px] sm:max-w-[240px]">
                  {statusText}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Flashlight button */}
              <button
                type="button"
                onClick={handleToggleTorch}
                className={`w-9 h-9 rounded-2xl flex items-center justify-center transition-colors cursor-pointer ${
                  isTorchOn ? 'bg-amber-400 text-slate-900 shadow-md' : 'bg-white/15 text-white hover:bg-white/25'
                }`}
                aria-label="Toggle Torch"
                title="Toggle Torch"
              >
                <Flashlight className="w-4 h-4" />
              </button>

              {/* Flip Camera button */}
              <button
                type="button"
                onClick={handleFlipCamera}
                className="w-9 h-9 rounded-2xl bg-white/15 text-white hover:bg-white/25 flex items-center justify-center transition-colors cursor-pointer"
                aria-label="Flip Camera"
                title="Flip Camera"
              >
                <RefreshCw className="w-4 h-4" />
              </button>

              {/* Close button */}
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-2xl bg-white/20 text-white hover:bg-white/30 flex items-center justify-center transition-colors cursor-pointer active:scale-95"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* DUAL-MODE SWITCHER (BARCODE VS. TEXT OCR) OR QR DEDICATED BADGE */}
          {scanType === 'qr_only' ? (
            <div className="flex items-center justify-center">
              <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-black/60 backdrop-blur-md rounded-2xl border border-amber-500/30 shadow-lg text-xs font-black text-amber-400">
                <QrCode className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {lang === 'tl'
                    ? 'Store Catalog QR Mode'
                    : lang === 'ja'
                    ? '店舗カタログQRモード'
                    : lang === 'zh'
                    ? '店铺目录二维码模式'
                    : lang === 'ko'
                    ? '매장 카탈로그 QR 모드'
                    : 'Store Catalog QR Mode'}
                </span>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center">
              <div className="inline-flex p-1 bg-black/60 backdrop-blur-md rounded-2xl border border-white/15 shadow-lg">
                <button
                  type="button"
                  onClick={() => handleSwitchMode('barcode')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    scanMode === 'barcode'
                      ? 'bg-amber-500 text-slate-950 shadow-md'
                      : 'text-white/70 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Barcode className="w-3.5 h-3.5" />
                  <span>{lang === 'tl' ? 'Barcode / QR' : 'Barcode / QR'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleSwitchMode('text')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    scanMode === 'text'
                      ? 'bg-amber-500 text-slate-950 shadow-md'
                      : 'text-white/70 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{lang === 'tl' ? 'Teksto / Label (OCR)' : 'Text / Label (OCR)'}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* FULL SCREEN CAMERA VIEWPORT */}
        <div
          onDoubleClick={wakeScanner}
          className="relative flex-1 flex items-center justify-center overflow-hidden cursor-pointer"
        >
          {/* SLEEP MODE DIMMED OVERLAY */}
          <AnimatePresence>
            {isSleeping && (
              <motion.div
                key="camera-sleep-overlay"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="absolute inset-0 z-40 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center select-none"
              >
                <motion.div
                  animate={{ scale: [1, 1.08, 1], opacity: [0.8, 1, 0.8] }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
                  className="w-16 h-16 rounded-3xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mb-4 shadow-xl"
                >
                  <Moon className="w-8 h-8" />
                </motion.div>
                <h3 className="text-white font-black text-lg sm:text-xl tracking-tight mb-1.5">
                  {lang === 'tl' ? 'Natutulog ang Camera' : 'Camera sleeping...'}
                </h3>
                <p className="text-stone-300 text-xs sm:text-sm font-medium max-w-xs mb-5">
                  {lang === 'tl'
                    ? 'Naka-pause ang scanning upang makatipid sa baterya. I-double tap kahit saan upang magising.'
                    : 'Double tap anywhere on the screen to wake'}
                </p>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    wakeScanner();
                  }}
                  className="px-5 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs sm:text-sm shadow-lg active:scale-95 transition-transform flex items-center gap-2 cursor-pointer"
                >
                  <Power className="w-4 h-4" />
                  <span>{lang === 'tl' ? 'Gisingin ang Camera' : 'Wake Camera'}</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* LIVE DIAGNOSTIC HUD OVERLAY FOR NATIVE APK OCR DEBUGGING */}
          {showHud ? (
            <div className="absolute top-2 left-2 right-2 z-[99999] pointer-events-auto bg-black/85 backdrop-blur-md border border-amber-500/40 rounded-2xl p-2.5 shadow-2xl text-[10px] font-mono text-amber-300 space-y-1 max-h-52 overflow-y-auto">
              <div className="flex items-center justify-between border-b border-amber-500/30 pb-1 mb-1">
                <span className="font-bold text-amber-400 flex items-center gap-1 text-[11px]">
                  <Bug className="w-3.5 h-3.5" /> DIAGNOSTIC HUD (OCR DEBUG)
                </span>
                <button
                  type="button"
                  onClick={() => setShowHud(false)}
                  className="px-1.5 py-0.5 bg-amber-500/20 hover:bg-amber-500/40 rounded text-[9px] text-amber-200 uppercase font-black cursor-pointer"
                >
                  Hide
                </button>
              </div>
              <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 text-[10px]">
                <div>
                  <span className="text-stone-400">Platform:</span>{' '}
                  <span className="font-bold text-white">
                    {Capacitor.isNativePlatform() ? `Native (${Capacitor.getPlatform()})` : 'Web / Browser'}
                  </span>
                </div>
                <div>
                  <span className="text-stone-400">ML Kit Module:</span>{' '}
                  <span
                    className={`font-bold ${
                      moduleStatus === 'READY' || moduleStatus === 'BUNDLED/OK'
                        ? 'text-emerald-400'
                        : moduleStatus === 'INSTALLING'
                        ? 'text-amber-400 animate-pulse'
                        : moduleStatus === 'ERROR'
                        ? 'text-rose-400'
                        : 'text-stone-300'
                    }`}
                  >
                    {moduleStatus}
                  </span>
                </div>
                <div>
                  <span className="text-stone-400">Frame Tick:</span>{' '}
                  <span className="font-bold text-sky-300">#{frameTick}</span>
                </div>
                <div>
                  <span className="text-stone-400">Phase & Timer:</span>{' '}
                  <span className="font-bold text-amber-300">
                    {scanPhase} {scanPhase === 'COUNTDOWN' ? `(${countdown}s)` : ''}
                  </span>
                </div>
                <div>
                  <span className="text-stone-400">Dims:</span>{' '}
                  <span className="font-bold text-stone-200">{videoCanvasDims}</span>
                </div>
                <div>
                  <span className="text-stone-400">Base64 Payload:</span>{' '}
                  <span className="font-bold text-purple-300">{base64PayloadSize}</span>
                </div>
                <div>
                  <span className="text-stone-400">Valid Scans:</span>{' '}
                  <span className="font-bold text-emerald-400">{validScanCount}</span>
                </div>
                <div>
                  <span className="text-stone-400">Rejected Scans:</span>{' '}
                  <span className="font-bold text-rose-400">{rejectedScanCount}</span>
                </div>
              </div>
              <div className="border-t border-white/10 pt-1 mt-1">
                <div className="text-stone-400">Raw ML Kit Detected Text:</div>
                <div className="bg-black/90 p-1 rounded border border-white/10 text-emerald-300 text-[9.5px] truncate select-all font-mono">
                  {rawMlKitText || '(Waiting for text in frame...)'}
                </div>
              </div>
              {lastRejectedBarcode && (
                <div className="border-t border-rose-500/20 pt-1 mt-1 text-[9.5px]">
                  <span className="text-rose-400 font-bold">Last Rejected:</span>{' '}
                  <span className="text-white font-mono">{lastRejectedBarcode}</span>
                  {lastRejectedReason && (
                    <div className="text-rose-300/80 text-[9px]">{lastRejectedReason}</div>
                  )}
                </div>
              )}
              {lastOcrError !== 'None' && (
                <div className="text-rose-400 font-bold truncate">
                  Last Error: {lastOcrError}
                </div>
              )}
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setShowHud(true)}
              className="absolute top-2 right-2 z-[99999] pointer-events-auto px-2.5 py-1 bg-black/80 backdrop-blur-md border border-amber-500/40 rounded-full text-[10px] font-mono font-bold text-amber-300 shadow-lg flex items-center gap-1 cursor-pointer"
            >
              <Bug className="w-3.5 h-3.5 text-amber-400" /> HUD DEBUG
            </button>
          )}

          {/* Live Video Feed */}
          <video
            ref={videoRef}
            playsInline
            muted
            autoPlay
            className="absolute inset-0 w-full h-full object-cover"
          />

          {/* Hidden Canvas for Frame Processing */}
          <canvas ref={canvasRef} className="hidden" />

          {/* CAMERA RETICLE / TARGETING CROSSHAIR */}
          {isScanning && (
            <div
              className={`relative z-10 ${
                scanMode === 'text' ? 'w-80 h-52 sm:w-96 sm:h-60' : 'w-72 h-72 sm:w-80 sm:h-80'
              } border-2 border-dashed border-white/60 rounded-3xl flex flex-col items-center justify-between p-4 shadow-2xl transition-all duration-300`}
            >
              {/* Corner reticles */}
              <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-amber-400 rounded-tl-xl -mt-1 -ml-1" />
              <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-amber-400 rounded-tr-xl -mt-1 -mr-1" />
              <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-amber-400 rounded-bl-xl -mb-1 -ml-1" />
              <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-amber-400 rounded-br-xl -mb-1 -mr-1" />

              {/* Animated Laser Scanning Line */}
              <motion.div
                key="laser-scan-line"
                animate={{ y: scanMode === 'text' ? [0, 160, 0] : [0, 240, 0] }}
                transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
                className="w-full h-0.5 bg-gradient-to-r from-transparent via-amber-400 to-transparent shadow-[0_0_8px_#fbbf24]"
              />

              {/* Hold-Steady Countdown Visual Overlay */}
              {scanMode === 'text' && scanPhase === 'COUNTDOWN' && (
                <motion.div
                  key="ocr-countdown-overlay"
                  initial={{ scale: 0.85, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="absolute inset-2 flex flex-col items-center justify-center bg-black/60 backdrop-blur-xs rounded-2xl z-20 pointer-events-none p-2 space-y-1.5"
                >
                  <div className="w-12 h-12 rounded-full bg-amber-500 text-slate-950 font-black text-xl flex items-center justify-center shadow-lg border-2 border-amber-300 animate-pulse">
                    {countdown}s
                  </div>
                  <span className="text-white text-xs font-black text-center px-2">
                    {lang === 'tl' ? 'Ipanatag ang camera...' : 'Hold camera steady...'}
                  </span>
                  {candidateText && (
                    <span className="text-amber-300 text-[11px] font-bold truncate max-w-[220px] bg-black/70 px-2 py-0.5 rounded-md border border-white/10">
                      "{candidateText}"
                    </span>
                  )}
                </motion.div>
              )}

              <div className="bg-black/60 backdrop-blur-xs px-3 py-1.5 rounded-full text-[11px] font-black text-white/90 border border-white/10 flex items-center gap-1.5 shadow-md">
                {scanType === 'qr_only' ? (
                  <QrCode className="w-3.5 h-3.5 text-amber-400" />
                ) : scanMode === 'text' ? (
                  <Type className="w-3.5 h-3.5 text-amber-400" />
                ) : (
                  <Scan className="w-3.5 h-3.5 text-amber-400" />
                )}
                <span>{getScannerReticleText(scanType, scanMode, lang)}</span>
              </div>
            </div>
          )}

          {/* AI VISION LENS BUTTON (FOR STYLIZED / 3D / BUBBLE PACKAGING TEXT) */}
          {scanMode === 'text' && isScanning && !isSleeping && !recognizedItem && !isUnrecognizedFallback && (
            <div className="absolute bottom-24 left-4 right-4 z-30 flex justify-center pointer-events-auto">
              <button
                type="button"
                disabled={isAiVisionLoading}
                onClick={handleAiVisionLens}
                className="px-5 py-2.5 sm:py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 font-black text-xs sm:text-sm shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-2 border border-amber-300/60 cursor-pointer touch-manipulation"
              >
                <Sparkles className={`w-4 h-4 text-slate-950 ${isAiVisionLoading ? 'animate-spin' : 'animate-bounce'}`} />
                <span>
                  {isAiVisionLoading
                    ? (lang === 'tl' ? 'Sinusuri ng AI Vision...' : 'Analyzing with AI Vision...')
                    : (lang === 'tl' ? '✨ AI Vision Lens (Stylized Packaging)' : '✨ AI Vision Lens (Stylized Packaging)')}
                </span>
              </button>
            </div>
          )}

          {/* TOP 3 RECOMMENDED PRODUCT NAME CHIPS (Uncatalogued / No Store Match) */}
          {scanMode === 'text' && isScanning && recommendedNames.length > 0 && !recognizedItem && !isUnrecognizedFallback && (
            <div className="absolute bottom-16 left-4 right-4 z-30 flex flex-col items-center gap-1.5 pointer-events-auto">
              <div className="text-[11px] font-black text-amber-300 bg-black/80 backdrop-blur-md px-3 py-1 rounded-full border border-amber-500/40 shadow-lg flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {lang === 'tl'
                    ? 'Mga Mungkahing Pangalan (Pindutin upang piliin):'
                    : 'Recommended Product Names (Tap to pick):'}
                </span>
              </div>
              <div className="flex flex-wrap justify-center gap-2 max-w-md">
                {recommendedNames.map((recName, idx) => (
                  <button
                    key={`rec-chip-${idx}-${recName}`}
                    type="button"
                    onClick={() => {
                      triggerHapticFeedback();
                      playScanBeep('success');
                      setDetectedText(recName);
                      handleScannedText(recName, undefined);
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-amber-500/25 hover:bg-amber-500/45 text-amber-200 hover:text-white border border-amber-400/50 font-bold text-xs shadow-xl backdrop-blur-md active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-amber-400" />
                    <span>"{recName}"</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Camera Permission Denied or Unavailable Banner */}
          {hasCameraPermission === false && (
            <div className="relative z-20 max-w-xs mx-auto p-5 rounded-3xl bg-neutral-900/95 border border-white/20 text-center space-y-3 shadow-2xl backdrop-blur-md">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/30">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-white font-black text-sm">
                  {isPermanentlyDenied
                    ? (lang === 'tl' ? 'Naka-off ang Camera sa Settings' : 'Camera Disabled in Settings')
                    : (lang === 'tl' ? 'Kailangan ang Pahintulot sa Camera' : 'Camera Permission Required')}
                </h3>
                <p className="text-xs text-white/70 leading-relaxed">
                  {isPermanentlyDenied
                    ? (lang === 'tl'
                        ? 'Hindi mabuksan ang camera dahil naka-block ang pahintulot. Pindutin ang Buksan ang Settings upang payagan ang camera.'
                        : 'Camera access is disabled. Tap Open Settings below to allow camera permission for Tindahan Notes.')
                    : (lang === 'tl'
                        ? 'Pindutin ang button sa ibaba upang i-trigger ang camera prompt para makapag-scan ng barcode at teksto nang offline.'
                        : 'Tap the button below to prompt camera permission for scanning barcodes and product labels offline.')}
                </p>
              </div>

              {isPermanentlyDenied ? (
                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={openCameraSettings}
                    className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-black text-xs shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Settings className="w-4 h-4" />
                    <span>{lang === 'tl' ? 'Buksan ang Settings' : 'Open Settings'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={startCamera}
                    className="w-full py-2 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white/90 font-bold text-xs active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>{lang === 'tl' ? 'I-refresh ang Pahintulot' : 'Re-check Permission'}</span>
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={startCamera}
                  className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-black text-xs shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  <span>{lang === 'tl' ? 'Payagan ang Camera' : 'Allow Camera Access'}</span>
                </button>
              )}
            </div>
          )}

          {/* STEP 3: FALLBACK CARD (ITEM NOT RECOGNIZED) */}
          <AnimatePresence>
            {isUnrecognizedFallback && (
              <motion.div
                key="unrecognized-fallback-card"
                initial={{ opacity: 0, y: 30, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 30, scale: 0.95 }}
                className="absolute bottom-6 left-4 right-4 z-30 max-w-sm mx-auto p-5 rounded-3xl bg-stone-900/95 border border-stone-700 backdrop-blur-md shadow-2xl space-y-3"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Package className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-white font-black text-sm">
                      {translate(lang, 'scanner_status_not_found') || 'Item not recognized. Add it to inventory?'}
                    </h3>
                    <p className="text-xs text-stone-400 mt-0.5">
                      {detectedCode
                        ? `Detected SKU: ${detectedCode}`
                        : (detectedText ? `Detected text: "${detectedText}"` : (lang === 'tl' ? 'Wala pang kaparehong paninda.' : 'No matching product found.'))}
                    </p>
                  </div>
                </div>

                <div className="space-y-1.5 pt-1">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        if (onOpenAddItem) {
                          onOpenAddItem({
                            name: detectedText || '',
                            sku: detectedCode || '',
                            itemType: 'PACK_VARIETY',
                          });
                        } else {
                          handleAddUnrecognizedItem();
                        }
                      }}
                      className="py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5" />
                      <span>{lang === 'tl' ? '+ Pack & Variety' : '+ Pack & Variety'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (onOpenAddItem) {
                          onOpenAddItem({
                            name: detectedText || '',
                            sku: detectedCode || '',
                            itemType: 'STANDARD',
                          });
                        } else {
                          handleAddUnrecognizedItem();
                        }
                      }}
                      className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-black text-xs border border-slate-700 active:scale-95 transition-all flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Package className="w-3.5 h-3.5 text-sky-400" />
                      <span>{lang === 'tl' ? '+ Standard' : '+ Standard Item'}</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={handleRestartScan}
                    className="w-full py-2 px-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 font-bold text-xs border border-stone-700/80 transition-colors cursor-pointer text-center"
                  >
                    {translate(lang, 'scanner_btn_retry') || 'Scan Again'}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ACTIVE SCANNED MULTI-ITEM CART TRAY (Shows when 1 or more items are queued) */}
        {cartItems.length > 0 && (
          <div className="px-4 pt-2 z-20">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 border border-amber-500/50 backdrop-blur-md flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-2 min-w-0 pr-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black text-xs shrink-0 shadow-md">
                  {cartItems.length}
                </div>
                <div className="truncate">
                  <span className="text-white font-black text-xs block truncate">
                    {lang === 'tl' ? `${cartItems.length} paninda sa cart` : `${cartItems.length} items in cart`}
                  </span>
                  <span className="text-amber-300 font-mono font-bold text-[11px]">
                    {formatPeso(cartItems.reduce((sum, it) => sum + it.totalPrice, 0))}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setCartItems([])}
                  className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-rose-500/20 text-stone-300 hover:text-rose-300 text-[11px] font-bold transition-colors cursor-pointer"
                >
                  {lang === 'tl' ? 'Linisin' : 'Clear'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    // Open modal for the first item in cart to review/checkout
                    if (cartItems.length > 0) {
                      const first = cartItems[0];
                      setCartItems((prev) => prev.slice(1));
                      setRecognizedItem(first.item);
                    }
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black shadow-md active:scale-95 transition-transform cursor-pointer"
                >
                  {lang === 'tl' ? 'I-checkout' : 'Checkout'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* BOTTOM CONTROLS: "SCAN ANOTHER ITEM / RE-SCAN" & SCROLLABLE MANUAL TYPE FALLBACK */}
        <div className="safe-pb-modal px-4 py-3 bg-gradient-to-t from-black/95 via-black/85 to-transparent z-20 space-y-2.5">
          {/* 1. Primary Button */}
          {scanType === 'qr_only' ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleRestartScan}
                className="flex-1 py-3 px-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs sm:text-sm shadow-xl active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer select-none"
              >
                <Camera className="w-4 h-4 text-slate-950 shrink-0" />
                <span className="truncate">
                  {lang === 'tl'
                    ? 'I-scan Ulit'
                    : lang === 'ja'
                    ? '再スキャン'
                    : lang === 'zh'
                    ? '重新扫描'
                    : lang === 'ko'
                    ? '다시 스캔'
                    : 'Re-scan'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => qrFileInputRef.current?.click()}
                className="flex-1 py-3 px-3 rounded-2xl bg-white/20 hover:bg-white/30 text-white font-black text-xs sm:text-sm border border-white/30 shadow-xl active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer select-none"
              >
                <Upload className="w-4 h-4 text-white shrink-0" />
                <span className="truncate">
                  {lang === 'tl'
                    ? 'Upload QR Larawan'
                    : lang === 'ja'
                    ? '画像から読込'
                    : lang === 'zh'
                    ? '上传图片'
                    : lang === 'ko'
                    ? '사진 업로드'
                    : 'Upload Photo'}
                </span>
              </button>
              <input
                ref={qrFileInputRef}
                type="file"
                accept="image/*"
                onChange={handleQrPhotoUpload}
                className="hidden"
              />
            </div>
          ) : (
            <button
              type="button"
              onClick={handleRestartScan}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs sm:text-sm shadow-xl active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer select-none"
            >
              <Camera className="w-4 h-4 text-slate-950" />
              <span>
                {lang === 'tl'
                  ? 'I-scan ang Susunod na Paninda'
                  : 'Scan Another Item'}
              </span>
            </button>
          )}

          {/* 2. Secondary Option: Scrollable Manual Type Area so text is never squeezed */}
          <div className="pt-0.5">
            <form onSubmit={handleManualSearch} className="w-full flex items-center gap-2">
              <div className="relative flex-1 min-w-0 overflow-x-auto custom-modal-scrollbar">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/50 pointer-events-none" />
                <input
                  type="text"
                  placeholder={
                    scanType === 'qr_only'
                      ? (lang === 'tl'
                          ? 'I-paste ang Store QR data code...'
                          : lang === 'ja'
                          ? '店舗QRコードデータを貼り付け...'
                          : lang === 'zh'
                          ? '粘贴店铺二维码数据...'
                          : lang === 'ko'
                          ? '매장 QR 코드 데이터 붙여넣기...'
                          : 'Paste Store QR data code...')
                      : (lang === 'tl'
                          ? 'O i-type ang pangalan o SKU...'
                          : 'Or type product name/SKU manually...')
                  }
                  value={manualSearchInput}
                  onChange={(e) => setManualSearchInput(e.target.value)}
                  className="w-full bg-white/15 hover:bg-white/20 text-white placeholder:text-white/50 border border-white/25 rounded-2xl py-2.5 pl-9 pr-3 text-xs sm:text-sm font-bold focus:outline-none focus:border-amber-400 focus:bg-white/25 backdrop-blur-md transition-all min-w-[180px]"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2.5 rounded-2xl bg-white/20 hover:bg-white/30 text-white font-black text-xs sm:text-sm border border-white/30 shadow-md active:scale-95 transition-transform cursor-pointer shrink-0"
              >
                {scanType === 'qr_only'
                  ? (lang === 'tl'
                      ? 'I-load'
                      : lang === 'ja'
                      ? '読込'
                      : lang === 'zh'
                      ? '加载'
                      : lang === 'ko'
                      ? '불러오기'
                      : 'Load')
                  : (lang === 'tl' ? 'Hanapin' : 'Find')}
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* ITEM RECOGNIZED ACTION MODAL (SELL / CREDIT FLOW) */}
      <ItemRecognizedModal
        isOpen={Boolean(recognizedItem)}
        item={recognizedItem}
        scannedCode={detectedCode}
        cartItems={cartItems}
        onAddAnother={(entry) => {
          setCartItems((prev) => [...prev, entry]);
          setRecognizedItem(null);
          setDetectedCode('');
          setDetectedText('');
          setIsUnrecognizedFallback(false);
          handleRestartScan();
        }}
        onRemoveCartItem={(idx) => {
          setCartItems((prev) => prev.filter((_, i) => i !== idx));
        }}
        onClose={() => {
          setRecognizedItem(null);
          handleRestartScan();
        }}
        onSuccess={(msg) => {
          setCartItems([]);
          setRecognizedItem(null);
          if (onTransactionSuccess) {
            onTransactionSuccess(msg);
          }
          onClose();
        }}
        lang={lang}
      />

    </>
  );
};


import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Mic,
  MicOff,
  Volume2,
  ShieldCheck,
  Check,
  ShoppingBag,
  StickyNote,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  Settings,
  RefreshCw,
} from 'lucide-react';
import { db } from '../db/db';
import type { Transaction, Note } from '../types';
import { formatPeso, getLocalDateStr } from '../utils/formatters';
import { translate, type LanguageCode } from '../utils/i18n';
import { playScanBeep } from '../utils/audioBeep';
import {
  ensureMicrophonePermission,
  openMicrophoneSettings,
  getMicrophonePermissionStrings,
} from '../utils/microphonePermission';

interface VoiceLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved: () => void;
  lang: LanguageCode;
}

// Word-to-number mapping for Tagalog and English retail speech
const NUMBER_WORDS: Record<string, number> = {
  isa: 1,
  dalawa: 2,
  tatlo: 3,
  apat: 4,
  lima: 5,
  anim: 6,
  pito: 7,
  walo: 8,
  siyam: 9,
  sampu: 10,
  labing: 10,
  bente: 20,
  beinte: 20,
  baynte: 20,
  trenta: 30,
  kwarenta: 40,
  kuwarenta: 40,
  singkwenta: 50,
  singkuwenta: 50,
  animnapu: 60,
  pitumpu: 70,
  walumpu: 80,
  siyamnapu: 90,
  daan: 100,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  twenty: 20,
  thirty: 30,
  forty: 40,
  fifty: 50,
  sixty: 60,
  seventy: 70,
  eighty: 80,
  ninety: 90,
  hundred: 100,
};

export const VoiceLogModal: React.FC<VoiceLogModalProps> = ({
  isOpen,
  onClose,
  onSaved,
  lang,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [spokenText, setSpokenText] = useState('');
  const [parsedAmount, setParsedAmount] = useState<number>(0);
  const [parsedItem, setParsedItem] = useState<string>('');
  const [parsedQty, setParsedQty] = useState<number>(1);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [hasMicPermission, setHasMicPermission] = useState<boolean>(true);
  const [isPermanentlyDenied, setIsPermanentlyDenied] = useState<boolean>(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const permStrings = getMicrophonePermissionStrings(lang);

  const recognitionRef = useRef<any>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const isStartingRef = useRef<boolean>(false);
  const isMountedRef = useRef<boolean>(true);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  // Determine speech language code
  const speechLangCode = () => {
    switch (lang) {
      case 'tl':
        return 'tl-PH';
      case 'ja':
        return 'ja-JP';
      case 'zh':
        return 'zh-CN';
      case 'ko':
        return 'ko-KR';
      case 'en':
      default:
        return 'en-PH'; // Optimized for Philippine retail english/taglish
    }
  };

  // Parse spoken text for quantity, items, and total amount
  const parseVoiceText = (raw: string) => {
    if (!raw.trim()) {
      setParsedAmount(0);
      setParsedItem('');
      setParsedQty(1);
      return;
    }

    const clean = raw.toLowerCase();
    const words = clean.split(/\s+/);

    // Look for numbers or peso symbols
    let foundAmount = 0;
    let foundQty = 1;
    let itemTokens: string[] = [];

    // Extract numbers like "20 pesos", "₱50", "30"
    const moneyRegex = /(?:₱|p|pesos?|peso)?\s*(\d+(?:\.\d{1,2})?)\s*(?:pesos?|peso)?/i;
    const match = clean.match(moneyRegex);
    if (match && match[1]) {
      foundAmount = parseFloat(match[1]);
    }

    // Iterate words for Tagalog/English number words
    for (let i = 0; i < words.length; i++) {
      const w = words[i].replace(/[.,]/g, '');
      if (NUMBER_WORDS[w]) {
        if (foundAmount === 0 && (words[i + 1] === 'pesos' || words[i + 1] === 'peso')) {
          foundAmount = NUMBER_WORDS[w];
        } else if (i === 0 || words[i - 1] === 'benta' || words[i - 1] === 'sale') {
          foundQty = NUMBER_WORDS[w];
        }
      } else if (!['benta', 'sale', 'pesos', 'peso', 'ng', 'na', 'ang', 'sa', 'at'].includes(w)) {
        itemTokens.push(w);
      }
    }

    // Default item name if empty
    let itemName = itemTokens.join(' ').replace(/\d+/g, '').trim();
    if (!itemName) {
      itemName = 'Paninda';
    }

    setParsedItem(itemName.charAt(0).toUpperCase() + itemName.slice(1));
    setParsedQty(foundQty || 1);
    setParsedAmount(foundAmount || 0);
  };

  // Start Hardware Noise-Cancelled Audio & Speech Recognition
  const startRecording = async () => {
    if (isStartingRef.current) return;
    isStartingRef.current = true;

    setErrorMessage(null);
    setSpokenText('');

    // Stop any existing stream before re-initialization
    stopRecording();

    // 0. Explicit OS runtime permission check adapted from ScannerModal architecture
    const permResult = await ensureMicrophonePermission();
    if (!isMountedRef.current || !isOpen) {
      isStartingRef.current = false;
      return;
    }

    if (!permResult.granted) {
      setHasMicPermission(false);
      setIsPermanentlyDenied(permResult.permanentlyDenied);
      setErrorMessage(
        permResult.permanentlyDenied
          ? permStrings.deniedMsg
          : permStrings.promptMsg
      );
      setIsRecording(false);
      isStartingRef.current = false;
      return;
    }

    setHasMicPermission(true);
    setIsPermanentlyDenied(false);

    // 1. Initialize Microphone with single getUserMedia call to trigger OS/browser permission prompt
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
        });

        // Abort if unmounted or modal closed while awaiting permission
        if (!isMountedRef.current || !isOpen) {
          stream.getTracks().forEach((t) => t.stop());
          isStartingRef.current = false;
          return;
        }

        mediaStreamRef.current = stream;

        // Setup low-battery audio visualizer analyzer
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          audioContextRef.current = ctx;
          const src = ctx.createMediaStreamSource(stream);
          const analyser = ctx.createAnalyser();
          analyser.fftSize = 32; // Low FFT size for minimal battery & CPU usage
          src.connect(analyser);
          analyserRef.current = analyser;

          const dataArray = new Uint8Array(analyser.frequencyBinCount);
          let lastCheckTime = 0;
          const checkVolume = (time: number) => {
            if (!analyserRef.current) return;
            // Throttle volume updates (~20fps) to save battery
            if (time - lastCheckTime > 50) {
              lastCheckTime = time;
              analyserRef.current.getByteFrequencyData(dataArray);
              let sum = 0;
              for (let i = 0; i < dataArray.length; i++) {
                sum += dataArray[i];
              }
              const avg = sum / dataArray.length;
              setAudioLevel(Math.min(100, Math.round((avg / 128) * 100)));
            }
            animFrameRef.current = requestAnimationFrame(checkVolume);
          };
          animFrameRef.current = requestAnimationFrame(checkVolume);
        }
      }
    } catch (err: any) {
      console.warn('[Voice] Hardware audio stream init skipped or failed:', err);
      const isNotAllowed =
        err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError';
      if (isNotAllowed) {
        setHasMicPermission(false);
        setIsPermanentlyDenied(true);
        setErrorMessage(permStrings.deniedMsg);
        setIsRecording(false);
        isStartingRef.current = false;
        return;
      }
    }

    // Check again before launching recognition
    if (!isMountedRef.current || !isOpen) {
      isStartingRef.current = false;
      return;
    }

    // 2. Initialize Web Speech Recognition
    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      setErrorMessage(translate(lang, 'voice_not_supported'));
      setIsRecording(false);
      isStartingRef.current = false;
      return;
    }

    try {
      const recognition = new SpeechRecognitionClass();
      recognition.lang = speechLangCode();
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onstart = () => {
        setIsRecording(true);
        isStartingRef.current = false;
      };

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = 0; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript + ' ';
        }
        setSpokenText(transcript.trim());
        parseVoiceText(transcript.trim());
      };

      recognition.onerror = (event: any) => {
        console.warn('[Voice] Speech error:', event.error);
        if (event.error === 'not-allowed') {
          setErrorMessage(
            lang === 'tl'
              ? 'Hindi pinayagan ang permiso sa mikropono. I-tap ang button upang payagan.'
              : 'Microphone access denied. Tap button below to allow permission.'
          );
        }
        isStartingRef.current = false;
      };

      recognition.onend = () => {
        setIsRecording(false);
        isStartingRef.current = false;
      };

      try {
        recognition.start();
      } catch (startErr) {
        console.warn('[Voice] Speech recognition already running or invalid state:', startErr);
      }
      recognitionRef.current = recognition;
    } catch (e) {
      console.warn('[Voice] Failed to start recognition:', e);
      setIsRecording(false);
      isStartingRef.current = false;
    }
  };

  const stopRecording = () => {
    isStartingRef.current = false;
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // ignore
      }
      recognitionRef.current = null;
    }

    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }

    if (mediaStreamRef.current) {
      try {
        mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      } catch (e) {}
      mediaStreamRef.current = null;
    }

    if (analyserRef.current) {
      try {
        analyserRef.current.disconnect();
      } catch (e) {}
      analyserRef.current = null;
    }

    if (audioContextRef.current) {
      try {
        if (audioContextRef.current.state !== 'closed') {
          audioContextRef.current.close().catch(() => {});
        }
      } catch (e) {}
      audioContextRef.current = null;
    }

    setIsRecording(false);
    setAudioLevel(0);
  };

  useEffect(() => {
    if (!isOpen) {
      stopRecording();
    }
    return () => {
      stopRecording();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSaveAsSale = async () => {
    if (parsedAmount <= 0 && !spokenText) return;
    setIsSaving(true);
    try {
      const now = Date.now();
      const dateStr = getLocalDateStr();
      const finalItem = parsedItem || 'Benta';
      const amount = parsedAmount || 20;

      const newTx: Transaction = {
        timestamp: now,
        dateStr,
        type: 'SALE',
        customerName: null,
        items: [
          {
            itemName: finalItem,
            quantity: parsedQty,
            unitPrice: amount / parsedQty,
            totalPrice: amount,
          },
        ],
        totalAmount: amount,
        rawNote: `Boses na Benta: ${parsedQty}x ${finalItem} = ${formatPeso(amount)} ("${spokenText}")`,
        syncStatus: 'LOCAL',
      };

      await db.transactions.add(newTx);
      playScanBeep('success');
      setSuccessToast(translate(lang, 'voice_saved_sale_success'));
      setTimeout(() => {
        onSaved();
        onClose();
      }, 700);
    } catch (err) {
      console.error('[Voice] Failed to save sale:', err);
      setIsSaving(false);
    }
  };

  const handleSaveAsNote = async () => {
    if (!spokenText.trim()) return;
    setIsSaving(true);
    try {
      const now = Date.now();
      const newNote: Note = {
        text: spokenText.trim(),
        createdAt: now,
        updatedAt: now,
        autoDelete: false,
        expiresAt: null,
      };

      await db.notes.add(newNote);
      playScanBeep('success');
      setSuccessToast(translate(lang, 'voice_saved_note_success'));
      setTimeout(() => {
        onSaved();
        onClose();
      }, 700);
    } catch (err) {
      console.error('[Voice] Failed to save note:', err);
      setIsSaving(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs touch-manipulation">
        <motion.div
          initial={{ scale: 0.94, opacity: 0, y: 16 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.94, opacity: 0, y: 16 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className="w-full max-w-lg theme-bg-card rounded-3xl border theme-border shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 sm:p-5 border-b theme-border bg-linear-to-r from-blue-500/10 to-indigo-500/10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-blue-500 text-white flex items-center justify-center shadow-md shrink-0">
                <Mic className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-base sm:text-lg theme-text-app leading-tight">
                  {translate(lang, 'voice_heading')}
                </h3>
                <p className="text-[11px] sm:text-xs theme-text-secondary mt-0.5">
                  {translate(lang, 'tool_voice_record_desc')}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl theme-hover-bg theme-text-secondary hover:theme-text-app cursor-pointer transition-colors"
              aria-label={translate(lang, 'btn_close')}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Noise Cancellation Badge */}
          <div className="px-4 py-2 bg-blue-500/10 border-b border-blue-500/20 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-blue-600 dark:text-blue-400 font-bold">
              <ShieldCheck className="w-4 h-4 text-blue-500" />
              <span>{translate(lang, 'voice_noise_filter_on')}</span>
            </div>
            <span className="text-[10px] theme-text-secondary font-mono uppercase">
              {speechLangCode()}
            </span>
          </div>

          {/* Body Content */}
          <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
            {successToast ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="py-12 flex flex-col items-center justify-center text-center space-y-3"
              >
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h4 className="text-lg font-black theme-text-app">{successToast}</h4>
              </motion.div>
            ) : (
              <>
                {/* Visual Mic Button & Pulse Wave */}
                <div className="flex flex-col items-center justify-center py-4 space-y-3">
                  <div className="relative flex items-center justify-center">
                    {/* Animated Pulsing Ring */}
                    {isRecording && (
                      <motion.div
                        animate={{
                          scale: [1, 1.25 + audioLevel * 0.005, 1],
                          opacity: [0.6, 0.2, 0.6],
                        }}
                        transition={{ repeat: Infinity, duration: 1.2, ease: 'easeInOut' }}
                        className="absolute w-24 h-24 rounded-full bg-blue-500/25"
                      />
                    )}
                    <button
                      type="button"
                      onClick={isRecording ? stopRecording : startRecording}
                      className={`relative z-10 w-20 h-20 rounded-full flex items-center justify-center shadow-xl cursor-pointer active:scale-95 transition-all ${
                        isRecording
                          ? 'bg-blue-600 text-white shadow-blue-500/40'
                          : 'theme-bg-surface-subtle theme-text-secondary hover:theme-text-app border theme-border'
                      }`}
                    >
                      {isRecording ? (
                        <Mic className="w-8 h-8 animate-pulse" />
                      ) : (
                        <MicOff className="w-8 h-8 opacity-60" />
                      )}
                    </button>
                  </div>

                  <p className="text-xs font-black theme-text-app">
                    {isRecording
                      ? translate(lang, 'voice_listening')
                      : translate(lang, 'voice_tap_to_speak')}
                  </p>
                  <p className="text-[11px] theme-text-secondary text-center max-w-xs leading-relaxed">
                    {translate(lang, 'voice_instruction')}
                  </p>
                </div>

                {/* Permission / Error Banner */}
                {errorMessage && (
                  <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-800 dark:text-amber-200 flex flex-col gap-2.5">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400 mt-0.5" />
                      <span className="leading-snug font-medium">{errorMessage}</span>
                    </div>
                    {isPermanentlyDenied ? (
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={openMicrophoneSettings}
                          className="flex-1 py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-black text-[11px] shadow-sm active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Settings className="w-3.5 h-3.5" />
                          <span>{permStrings.openSettingsBtn}</span>
                        </button>
                        <button
                          type="button"
                          onClick={startRecording}
                          className="py-2 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-800 dark:text-amber-200 font-bold text-[11px] active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>{permStrings.recheckBtn}</span>
                        </button>
                      </div>
                    ) : (
                      <div className="flex justify-end pt-1">
                        <button
                          type="button"
                          onClick={startRecording}
                          className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-black text-[11px] shadow-sm active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <Mic className="w-3.5 h-3.5" />
                          <span>{permStrings.allowBtn}</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Spoken Text Box & Edit Area */}
                <div>
                  <label className="text-xs font-black theme-text-app block mb-1.5">
                    {translate(lang, 'voice_recognized_text')}
                  </label>
                  <textarea
                    rows={2}
                    value={spokenText}
                    onChange={(e) => {
                      setSpokenText(e.target.value);
                      parseVoiceText(e.target.value);
                    }}
                    placeholder={translate(lang, 'voice_instruction')}
                    className="w-full p-3 rounded-2xl text-xs sm:text-sm theme-input-box resize-none font-medium"
                  />
                </div>

                {/* Parsed Preview Card */}
                {spokenText.trim() && (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3.5 rounded-2xl theme-bg-surface-subtle border theme-border space-y-2"
                  >
                    <div className="flex items-center gap-1.5 text-xs font-black theme-text-app">
                      <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                      <span>Auto-Detected Breakdown</span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-1 text-xs">
                      <div className="p-2 rounded-xl theme-bg-card border theme-border">
                        <span className="text-[10px] theme-text-secondary block font-bold">Item</span>
                        <span className="font-black theme-text-app truncate block">
                          {parsedItem || 'Paninda'}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl theme-bg-card border theme-border">
                        <span className="text-[10px] theme-text-secondary block font-bold">Dami</span>
                        <span className="font-black theme-text-app block">{parsedQty}x</span>
                      </div>
                      <div className="p-2 rounded-xl theme-bg-card border theme-border">
                        <span className="text-[10px] theme-text-secondary block font-bold">Presyo</span>
                        <span className="font-black text-blue-600 dark:text-blue-400 block">
                          {formatPeso(parsedAmount)}
                        </span>
                      </div>
                    </div>
                  </motion.div>
                )}
              </>
            )}
          </div>

          {/* Action CTAs */}
          {!successToast && (
            <div className="p-4 sm:p-5 border-t theme-border flex flex-col sm:flex-row items-center gap-2.5">
              <button
                type="button"
                disabled={!spokenText.trim() || isSaving}
                onClick={handleSaveAsNote}
                className="w-full sm:flex-1 py-3 px-4 rounded-2xl theme-bg-surface-subtle theme-text-app text-xs font-black hover:theme-bg-surface cursor-pointer active:scale-95 transition-transform flex items-center justify-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <StickyNote className="w-4 h-4 text-amber-500" />
                <span>{translate(lang, 'voice_save_as_note')}</span>
              </button>

              <button
                type="button"
                disabled={!spokenText.trim() || isSaving}
                onClick={handleSaveAsSale}
                className="w-full sm:flex-1 py-3 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs font-black shadow-lg shadow-blue-500/25 flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{translate(lang, 'voice_save_as_sale')}</span>
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

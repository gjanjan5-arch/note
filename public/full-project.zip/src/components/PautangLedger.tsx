import React, { useState } from 'react';
import { UserPlus, Send, History, Check, Phone, Copy, Sparkles, Pencil, Trash2, X, Receipt } from 'lucide-react';
import type { Customer, Transaction, TransactionType } from '../types';
import { db, updateTransactionEntry, recalculateCustomerBalance } from '../db/db';
import { formatPeso, formatDateTime, generatePautangReminderMsg, getLocalDateStr, formatDisplayNote, formatDisplayItemName } from '../utils/formatters';
import { translate, type LanguageCode } from '../utils/i18n';

interface PautangLedgerProps {
  customers: Customer[];
  transactions: Transaction[];
  lang: LanguageCode;
  onRefresh: () => void;
}

export const PautangLedger: React.FC<PautangLedgerProps> = ({
  customers,
  transactions,
  lang,
  onRefresh,
}) => {
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  // Modals
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [newCustomerNotes, setNewCustomerNotes] = useState('');

  // Edit Customer Profile
  const [isEditCustomerOpen, setIsEditCustomerOpen] = useState(false);
  const [editCustomerName, setEditCustomerName] = useState('');
  const [editCustomerPhone, setEditCustomerPhone] = useState('');
  const [editCustomerNotes, setEditCustomerNotes] = useState('');

  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentHandledBy, setPaymentHandledBy] = useState('');

  const [isAddCreditModalOpen, setIsAddCreditModalOpen] = useState(false);
  const [creditAmount, setCreditAmount] = useState('');
  const [creditNotes, setCreditNotes] = useState('');
  const [creditHandledBy, setCreditHandledBy] = useState('');

  // Edit Transaction Modal
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [editTxAmount, setEditTxAmount] = useState('');
  const [editTxType, setEditTxType] = useState<TransactionType>('PAUTANG_RECORD');
  const [editTxNote, setEditTxNote] = useState('');
  const [editTxHandledBy, setEditTxHandledBy] = useState('');

  const [isReminderModalOpen, setIsReminderModalOpen] = useState(false);
  const [copiedSuccess, setCopiedSuccess] = useState(false);

  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [viewingDetailTx, setViewingDetailTx] = useState<Transaction | null>(null);

  const totalCollectibles = (customers || []).reduce((sum, c) => sum + (c.currentBalance || 0), 0);

  const filteredCustomers = customers || [];

  // Handle Add Customer
  const handleAddCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newCustomerName.trim();
    if (!trimmed) return;

    try {
      // Guard against duplicate name collision on indexeddb
      const existing = await db.customers.where('name').equalsIgnoreCase(trimmed).first();
      if (existing) {
        alert(
          lang === 'tl'
            ? `Mayroon nang suki na may pangalang "${trimmed}".`
            : `A customer named "${trimmed}" already exists.`
        );
        return;
      }

      const cleanPhone = newCustomerPhone.replace(/\D/g, '').slice(0, 11);

      await db.customers.add({
        name: trimmed,
        phone: cleanPhone || undefined,
        currentBalance: 0,
        lastTransactionAt: Date.now(),
        notes: newCustomerNotes.trim() || undefined,
      });

      setNewCustomerName('');
      setNewCustomerPhone('');
      setNewCustomerNotes('');
      setIsAddCustomerOpen(false);
      onRefresh();
    } catch (err) {
      console.error('[PautangLedger] Error adding customer:', err);
      alert(lang === 'tl' ? 'Nagkaroon ng error sa pag-save ng suki.' : 'Error saving customer.');
    }
  };

  // Handle Open Edit Customer Profile
  const handleOpenEditCustomer = (customer: Customer, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedCustomer(customer);
    setEditCustomerName(customer.name);
    setEditCustomerPhone(customer.phone || '');
    setEditCustomerNotes(customer.notes || '');
    setIsEditCustomerOpen(true);
  };

  // Handle Save Edit Customer Profile
  const handleSaveEditCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer || !selectedCustomer.id) return;
    const trimmedName = editCustomerName.trim();
    if (!trimmedName) {
      alert(lang === 'tl' ? 'Mangyaring maglagay ng pangalan.' : 'Please enter a name.');
      return;
    }

    try {
      const oldName = selectedCustomer.name;
      const cleanPhone = editCustomerPhone.replace(/\D/g, '').slice(0, 11);

      // Check if new name exists on another customer
      if (trimmedName.toLowerCase() !== oldName.toLowerCase()) {
        const duplicate = customers.find(
          (c) => c.id !== selectedCustomer.id && c.name.toLowerCase() === trimmedName.toLowerCase()
        );
        if (duplicate) {
          alert(
            lang === 'tl'
              ? `Mayroon nang ibang suki na may pangalang "${trimmedName}".`
              : `A customer named "${trimmedName}" already exists.`
          );
          return;
        }
      }

      await db.customers.update(selectedCustomer.id, {
        name: trimmedName,
        phone: cleanPhone || undefined,
        notes: editCustomerNotes.trim() || undefined,
      });

      // If name changed, synchronize transactions as well
      if (trimmedName.toLowerCase() !== oldName.toLowerCase()) {
        const associatedTxs = await db.transactions
          .filter((tx) => (tx.customerName || '').toLowerCase() === oldName.toLowerCase())
          .toArray();
        for (const tx of associatedTxs) {
          if (tx.id) {
            await db.transactions.update(tx.id, { customerName: trimmedName });
          }
        }
      }

      setIsEditCustomerOpen(false);
      onRefresh();
    } catch (err) {
      console.error('[PautangLedger] Error editing customer:', err);
      alert(lang === 'tl' ? 'Nagkaroon ng error sa pag-update ng profile.' : 'Error updating customer profile.');
    }
  };

  // Handle Receive Payment
  const handleReceivePayment = async () => {
    if (!selectedCustomer || !selectedCustomer.id) return;
    if (paymentAmount.trim() === '' || isNaN(Number(paymentAmount))) {
      alert(lang === 'tl' ? 'Mangyaring maglagay ng wastong halaga ng bayad.' : 'Please enter a valid payment amount.');
      return;
    }
    const amount = Number(paymentAmount);
    if (amount <= 0) {
      alert(lang === 'tl' ? 'Ang halaga ng bayad ay dapat higit sa 0.' : 'Payment amount must be greater than 0.');
      return;
    }

    try {
      const todayStr = getLocalDateStr();
      const payerNote = paymentHandledBy.trim();

      // Add transaction
      await db.transactions.add({
        timestamp: Date.now(),
        dateStr: todayStr,
        type: 'PAUTANG_PAYMENT',
        customerName: selectedCustomer.name,
        handledBy: payerNote || undefined,
        items: [{ itemName: lang === 'tl' ? 'Bayad' : 'Payment', quantity: 1, totalPrice: amount }],
        totalAmount: amount,
        rawNote: lang === 'tl'
          ? `bayad ${selectedCustomer.name} ${payerNote ? `(bayad ni ${payerNote}) ` : ''}${amount}`
          : `payment ${selectedCustomer.name} ${payerNote ? `(paid by ${payerNote}) ` : ''}${amount}`,
        notes: payerNote ? (lang === 'tl' ? `Nagbayad: ${payerNote}` : `Paid by: ${payerNote}`) : undefined,
        syncStatus: 'LOCAL',
      });

      // Recalculate customer balance directly from transactions
      await recalculateCustomerBalance(selectedCustomer.name);

      setPaymentAmount('');
      setPaymentHandledBy('');
      setIsPaymentModalOpen(false);
      setSelectedCustomer(null);
      onRefresh();
    } catch (err) {
      console.error('[PautangLedger] Error recording payment:', err);
      alert(lang === 'tl' ? 'Nagkaroon ng error sa pag-record ng bayad.' : 'Error recording payment.');
    }
  };

  // Handle Add New Credit (Pautang)
  const handleAddCredit = async () => {
    if (!selectedCustomer || !selectedCustomer.id) return;
    if (creditAmount.trim() === '' || isNaN(Number(creditAmount))) {
      alert(lang === 'tl' ? 'Mangyaring maglagay ng wastong halaga ng pautang.' : 'Please enter a valid credit amount.');
      return;
    }
    const amount = Number(creditAmount);
    if (amount <= 0) {
      alert(lang === 'tl' ? 'Ang halaga ng pautang ay dapat higit sa 0.' : 'Credit amount must be greater than 0.');
      return;
    }

    try {
      const todayStr = getLocalDateStr();
      const takerNote = creditHandledBy.trim();
      const descNote = creditNotes.trim();

      await db.transactions.add({
        timestamp: Date.now(),
        dateStr: todayStr,
        type: 'PAUTANG_RECORD',
        customerName: selectedCustomer.name,
        handledBy: takerNote || undefined,
        items: [{ itemName: descNote || (lang === 'tl' ? 'Pautang' : 'Credit Purchase'), quantity: 1, totalPrice: amount }],
        totalAmount: amount,
        rawNote: lang === 'tl'
          ? `pautang ${selectedCustomer.name} ${takerNote ? `(kinuha ni ${takerNote}) ` : ''}${descNote ? descNote + ' ' : ''}${amount}`
          : `credit ${selectedCustomer.name} ${takerNote ? `(taken by ${takerNote}) ` : ''}${descNote ? descNote + ' ' : ''}${amount}`,
        notes: takerNote ? (lang === 'tl' ? `Kinuha ni: ${takerNote}` : `Taken by: ${takerNote}`) : undefined,
        syncStatus: 'LOCAL',
      });

      // Recalculate customer balance
      await recalculateCustomerBalance(selectedCustomer.name);

      setCreditAmount('');
      setCreditNotes('');
      setCreditHandledBy('');
      setIsAddCreditModalOpen(false);
      setSelectedCustomer(null);
      onRefresh();
    } catch (err) {
      console.error('[PautangLedger] Error adding credit:', err);
      alert(lang === 'tl' ? 'Nagkaroon ng error sa pag-record ng pautang.' : 'Error recording credit.');
    }
  };

  // Handle Open Edit Transaction Modal
  const handleOpenEditTx = (tx: Transaction) => {
    setEditingTx(tx);
    setEditTxAmount(tx.totalAmount.toString());
    setEditTxType(tx.type);
    setEditTxNote(
      tx.items && tx.items.length > 0
        ? tx.items.map((i) => i.itemName).join(', ')
        : tx.rawNote || ''
    );
    setEditTxHandledBy(tx.handledBy || '');
  };

  // Handle Save Edited Transaction
  const handleSaveEditTx = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTx || !editingTx.id) return;
    const amount = Number(editTxAmount);
    if (isNaN(amount) || amount <= 0) {
      alert(lang === 'tl' ? 'Mangyaring maglagay ng wastong halaga.' : 'Please enter a valid amount.');
      return;
    }

    try {
      const handled = editTxHandledBy.trim();
      const desc = editTxNote.trim();
      const custName = editingTx.customerName || selectedCustomer?.name || '';

      await updateTransactionEntry(editingTx.id, {
        totalAmount: amount,
        type: editTxType,
        handledBy: handled || undefined,
        items: [{ itemName: desc || (editTxType === 'PAUTANG_RECORD' ? (lang === 'tl' ? 'Pautang' : 'Credit Purchase') : (lang === 'tl' ? 'Bayad' : 'Payment')), quantity: 1, totalPrice: amount }],
        rawNote: lang === 'tl'
          ? `${editTxType === 'PAUTANG_RECORD' ? 'pautang' : 'bayad'} ${custName} ${handled ? `(${handled}) ` : ''}${desc ? desc + ' ' : ''}${amount}`
          : `${editTxType === 'PAUTANG_RECORD' ? 'credit' : 'payment'} ${custName} ${handled ? `(${handled}) ` : ''}${desc ? desc + ' ' : ''}${amount}`,
        notes: handled ? (editTxType === 'PAUTANG_RECORD' ? (lang === 'tl' ? `Kinuha ni: ${handled}` : `Taken by: ${handled}`) : (lang === 'tl' ? `Nagbayad: ${handled}` : `Paid by: ${handled}`)) : undefined,
      });

      if (custName) {
        await recalculateCustomerBalance(custName);
      }

      setEditingTx(null);
      onRefresh();
    } catch (err) {
      console.error('[PautangLedger] Error updating transaction:', err);
      alert(lang === 'tl' ? 'Nagkaroon ng error sa pag-update ng tala.' : 'Error updating transaction.');
    }
  };

  // Handle Delete Single Transaction from Customer History
  const handleDeleteTx = async (txId?: number) => {
    if (!txId) return;
    const confirmMsg =
      lang === 'tl'
        ? 'Sigurado ka bang nais mong tanggalin ang transaksyong ito? Awtomatikong mai-a-adjust ang balance.'
        : 'Are you sure you want to delete this transaction? The customer balance will be automatically recalculated.';
    if (!window.confirm(confirmMsg)) return;

    try {
      const tx = await db.transactions.get(txId);
      const custName = tx?.customerName || selectedCustomer?.name;
      await db.transactions.delete(txId);

      if (custName) {
        await recalculateCustomerBalance(custName);
      }

      if (editingTx?.id === txId) {
        setEditingTx(null);
      }
      onRefresh();
    } catch (err) {
      console.error('[PautangLedger] Error deleting transaction:', err);
      alert(lang === 'tl' ? 'Nagkaroon ng error sa pag-delete.' : 'Error deleting transaction.');
    }
  };

  const reminderText = selectedCustomer
    ? generatePautangReminderMsg('Tindahan Notes', selectedCustomer.name, selectedCustomer.currentBalance, lang)
    : '';

  const copyReminder = () => {
    navigator.clipboard.writeText(reminderText);
    setCopiedSuccess(true);
    setTimeout(() => setCopiedSuccess(false), 2000);
  };

  return (
    <div id="pautang-ledger-container" className="space-y-4">
      {/* Summary Banner & Action Button */}
      <div
        id="pautang-controls-section"
        className="theme-card p-4 sm:p-5 rounded-3xl shadow-2xs border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition-colors duration-200"
      >
        <div>
          <span className="text-xs font-bold theme-text-secondary block">
            {translate(lang, 'pautang_total_collectibles')}
          </span>
          <span className="text-2xl sm:text-3xl font-black theme-text-accent">
            {formatPeso(totalCollectibles)}
          </span>
          <p className="text-xs theme-text-secondary mt-0.5">
            {lang === 'tl'
              ? `${customers.filter((c) => c.currentBalance > 0).length} suki ang may pautang`
              : `${customers.filter((c) => c.currentBalance > 0).length} customer(s) with credit balance`}
          </p>
        </div>

        <button
          id="btn-add-customer"
          onClick={() => setIsAddCustomerOpen(true)}
          className="flex items-center gap-1.5 theme-bg-primary text-white px-4 py-2.5 rounded-2xl text-xs font-black transition-all shadow-2xs active:scale-95 shrink-0"
        >
          <UserPlus className="w-4 h-4 text-white/90" />
          <span>+ {translate(lang, 'btn_add_suki')}</span>
        </button>
      </div>

      {/* Customer List Feed */}
      <div className="theme-card p-3.5 sm:p-4 rounded-3xl shadow-2xs border transition-colors duration-200">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredCustomers.length === 0 ? (
            <div className="col-span-full py-8 text-center theme-text-secondary text-xs font-semibold">
              {translate(lang, 'no_suki_found')}
            </div>
          ) : (
            filteredCustomers.map((cust) => {
              const hasDebt = cust.currentBalance > 0;
              return (
                <div
                  key={cust.id}
                  className={`p-3.5 rounded-3xl border transition-all flex flex-col justify-between gap-2.5 ${
                    hasDebt
                      ? 'bg-amber-500/10 border-amber-500/30 hover:border-amber-500/50'
                      : 'theme-bg-surface-subtle border theme-border-subtle hover:border-[var(--color-primary)]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-extrabold theme-text-app text-base">{cust.name}</h4>
                        <button
                          type="button"
                          onClick={(e) => handleOpenEditCustomer(cust, e)}
                          className="w-5 h-5 rounded-md bg-white/10 hover:bg-white/20 theme-text-secondary hover:theme-text-app flex items-center justify-center cursor-pointer transition-colors"
                          title={lang === 'tl' ? 'I-edit ang Profile' : 'Edit Profile'}
                        >
                          <Pencil className="w-2.5 h-2.5" />
                        </button>
                        {cust.phone && (
                          <span className="text-[10px] theme-text-secondary font-medium flex items-center gap-0.5 theme-bg-surface-subtle px-1.5 py-0.5 rounded border theme-border-subtle font-mono">
                            <Phone className="w-2.5 h-2.5" />
                            {cust.phone}
                          </span>
                        )}
                      </div>
                      {cust.notes && <p className="text-xs theme-text-secondary mt-0.5">{cust.notes}</p>}
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] uppercase font-extrabold theme-text-secondary block">Balance</span>
                      <span
                        className={`text-lg font-black ${
                          hasDebt ? 'text-amber-400' : 'theme-text-accent'
                        }`}
                      >
                        {formatPeso(cust.currentBalance)}
                      </span>
                    </div>
                  </div>

                  {/* Customer Quick Actions */}
                  <div className="flex items-center gap-1.5 pt-2 border-t theme-border-subtle flex-wrap">
                    <button
                      onClick={() => {
                        setSelectedCustomer(cust);
                        setPaymentAmount(cust.currentBalance.toString());
                        setIsPaymentModalOpen(true);
                      }}
                      className="flex-1 min-w-[70px] theme-bg-primary text-white text-xs font-bold py-1.5 px-2 rounded-xl transition-all text-center shadow-2xs active:scale-95"
                    >
                      {translate(lang, 'btn_pay')}
                    </button>

                    <button
                      onClick={() => {
                        setSelectedCustomer(cust);
                        setIsAddCreditModalOpen(true);
                      }}
                      className="flex-1 min-w-[70px] theme-bg-surface-subtle hover:bg-white/10 theme-text-accent border theme-border-subtle text-xs font-bold py-1.5 px-2 rounded-xl transition-all text-center active:scale-95"
                    >
                      + {translate(lang, 'nav_pautang')}
                    </button>

                    {hasDebt && (
                      <button
                        onClick={() => {
                          setSelectedCustomer(cust);
                          setIsReminderModalOpen(true);
                        }}
                        className="theme-bg-surface-subtle hover:bg-white/10 theme-text-app text-xs font-bold py-1.5 px-2.5 rounded-xl transition-all flex items-center gap-1 border theme-border-subtle"
                        title={lang === 'tl' ? 'SMS / Messenger Paalala' : 'SMS / Messenger Reminder'}
                      >
                        <Send className="w-3 h-3 text-amber-400" />
                        <span>{lang === 'tl' ? 'Paalala' : 'Reminder'}</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        console.log('[PautangLedger] Opening customer history for:', cust.name);
                        setSelectedCustomer(cust);
                        setIsHistoryModalOpen(true);
                      }}
                      className="theme-bg-surface-subtle hover:bg-white/10 theme-text-secondary text-xs font-bold p-1.5 rounded-xl transition-all border theme-border-subtle cursor-pointer active:scale-95"
                      title={lang === 'tl' ? 'Kasaysayan ng Transaksyon' : 'Transaction History'}
                      aria-label={`View transaction history for ${cust.name}`}
                    >
                      <History className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Modal: Add New Suki Customer */}
      {isAddCustomerOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="theme-card rounded-3xl max-w-md w-full p-5 shadow-2xl border animate-in fade-in zoom-in-95">
            <h3 className="font-extrabold theme-text-app text-base mb-3">+ {translate(lang, 'btn_add_suki')}</h3>

            <form onSubmit={handleAddCustomer} className="space-y-3 text-xs sm:text-sm">
              <div>
                <label className="block font-bold theme-text-app mb-1">{translate(lang, 'customer_name')} *</label>
                <input
                  type="text"
                  required
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  placeholder={lang === 'tl' ? 'Hal. Aling Nena, Kapitan Cardo' : 'E.g. Aling Nena, Captain Cardo'}
                  className="w-full theme-input border rounded-xl p-2.5 font-medium theme-text-app focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold theme-text-app mb-1">{lang === 'tl' ? 'Cellphone Number (Max 11 digits)' : 'Phone Number (Max 11 digits)'}</label>
                <div className="relative">
                  <input
                    type="tel"
                    maxLength={11}
                    value={newCustomerPhone}
                    onChange={(e) => {
                      const digits = e.target.value.replace(/\D/g, '').slice(0, 11);
                      setNewCustomerPhone(digits);
                    }}
                    placeholder={lang === 'tl' ? 'Hal. 09171234567' : 'E.g. 09171234567'}
                    className="w-full theme-input border rounded-xl p-2.5 font-medium theme-text-app focus:outline-none pr-12 font-mono"
                  />
                  <span className="absolute right-2.5 top-3 text-[10px] theme-text-secondary font-mono">
                    {newCustomerPhone.length}/11
                  </span>
                </div>
              </div>

              <div>
                <label className="block font-bold theme-text-app mb-1">{lang === 'tl' ? 'Tala / Notes (Optional)' : 'Notes (Optional)'}</label>
                <input
                  type="text"
                  value={newCustomerNotes}
                  onChange={(e) => setNewCustomerNotes(e.target.value)}
                  placeholder={lang === 'tl' ? 'Hal. Tricycle driver, Kapitbahay' : 'E.g. Neighbor, Regular buyer'}
                  className="w-full theme-input border rounded-xl p-2.5 font-medium theme-text-app focus:outline-none"
                />
              </div>

              <div className="mt-4 flex items-center justify-end gap-2 pt-2 border-t theme-border-subtle">
                <button
                  type="button"
                  onClick={() => setIsAddCustomerOpen(false)}
                  className="px-4 py-2 rounded-xl theme-text-secondary hover:bg-white/10 font-bold"
                >
                  {translate(lang, 'btn_cancel')}
                </button>
                <button
                  type="submit"
                  className="theme-bg-primary text-white px-5 py-2 rounded-xl font-bold transition-all shadow-2xs active:scale-95"
                >
                  {translate(lang, 'btn_save_confirm')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Receive Payment */}
      {isPaymentModalOpen && selectedCustomer && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="theme-card rounded-3xl max-w-md w-full p-5 shadow-2xl border">
            <h3 className="font-extrabold theme-text-app text-base mb-1">
              {lang === 'tl' ? `Mag-record ng Bayad ni ${selectedCustomer.name}` : `Record Payment from ${selectedCustomer.name}`}
            </h3>
            <p className="text-xs theme-text-secondary mb-3">
              {lang === 'tl' ? 'Kasalukuyang Utang:' : 'Current Balance:'} <strong className="text-amber-400">{formatPeso(selectedCustomer.currentBalance)}</strong>
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold theme-text-app mb-1">{lang === 'tl' ? 'Halaga ng Bayad (₱) *' : 'Payment Amount (₱) *'}</label>
                <input
                  type="number"
                  min="1"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full theme-input border rounded-xl p-2.5 text-lg font-black theme-text-app focus:outline-none"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentAmount(selectedCustomer.currentBalance.toString())}
                  className="text-xs font-bold theme-bg-surface-subtle theme-text-accent px-2.5 py-1 rounded-lg border theme-border-subtle hover:bg-white/10"
                >
                  {lang === 'tl' ? `Buong Bayad (${formatPeso(selectedCustomer.currentBalance)})` : `Full Payment (${formatPeso(selectedCustomer.currentBalance)})`}
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold theme-text-app mb-1">
                  {lang === 'tl' ? 'Sino ang nagbayad? (Optional)' : 'Who handed the payment? (Optional)'}
                </label>
                <input
                  type="text"
                  value={paymentHandledBy}
                  onChange={(e) => setPaymentHandledBy(e.target.value)}
                  placeholder={lang === 'tl' ? `Iwanang blangko kung si ${selectedCustomer.name} mismo (o ilagay hal. Pedro, Anak)` : `Leave blank if ${selectedCustomer.name} self (or enter e.g. Son, Spouse)`}
                  className="w-full theme-input border rounded-xl p-2.5 text-xs font-medium theme-text-app focus:outline-none"
                />
                <span className="text-[10px] theme-text-secondary mt-0.5 block">
                  {lang === 'tl' ? 'Kung ibang tao ang nag-abot o nagbayad, ilagay ang pangalan dito.' : 'If someone else paid on their behalf, specify their name here.'}
                </span>
              </div>

              <div className="mt-4 flex items-center justify-end gap-2 pt-3 border-t theme-border-subtle">
                <button
                  type="button"
                  onClick={() => {
                    setIsPaymentModalOpen(false);
                    setPaymentHandledBy('');
                  }}
                  className="px-4 py-2 rounded-xl theme-text-secondary font-bold hover:bg-white/10"
                >
                  {translate(lang, 'btn_cancel')}
                </button>
                <button
                  type="button"
                  onClick={handleReceivePayment}
                  className="theme-bg-primary text-white px-5 py-2 rounded-xl font-bold shadow-2xs active:scale-95 cursor-pointer"
                >
                  {translate(lang, 'btn_save_confirm')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add Credit */}
      {isAddCreditModalOpen && selectedCustomer && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="theme-card rounded-3xl max-w-md w-full p-5 shadow-2xl border">
            <h3 className="font-extrabold theme-text-app text-base mb-1">
              {lang === 'tl' ? `Magdagdag ng Pautang kay ${selectedCustomer.name}` : `Add Credit Record for ${selectedCustomer.name}`}
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold theme-text-app mb-1">{lang === 'tl' ? 'Halaga ng Pautang (₱) *' : 'Credit Amount (₱) *'}</label>
                <input
                  type="number"
                  min="1"
                  value={creditAmount}
                  onChange={(e) => setCreditAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full theme-input border rounded-xl p-2.5 text-lg font-black theme-text-app focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold theme-text-app mb-1">{lang === 'tl' ? 'Note / Anong Kinuha (Optional)' : 'Note / Items Taken (Optional)'}</label>
                <input
                  type="text"
                  value={creditNotes}
                  onChange={(e) => setCreditNotes(e.target.value)}
                  placeholder={lang === 'tl' ? 'Hal. 2 canton, 1 coke' : 'E.g. 2 canton, 1 coke'}
                  className="w-full theme-input border rounded-xl p-2.5 text-xs font-medium theme-text-app focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold theme-text-app mb-1">
                  {lang === 'tl' ? 'Sino ang kumuha? (Optional)' : 'Who picked up the items? (Optional)'}
                </label>
                <input
                  type="text"
                  value={creditHandledBy}
                  onChange={(e) => setCreditHandledBy(e.target.value)}
                  placeholder={lang === 'tl' ? `Iwanang blangko kung si ${selectedCustomer.name} mismo (o ilagay hal. Bunso, Asawa)` : `Leave blank if ${selectedCustomer.name} self (or enter e.g. Child, Spouse)`}
                  className="w-full theme-input border rounded-xl p-2.5 text-xs font-medium theme-text-app focus:outline-none"
                />
                <span className="text-[10px] theme-text-secondary mt-0.5 block">
                  {lang === 'tl' ? 'Kung inutusan o ibang tao ang kumuha para sa kanya, ilagay rito.' : 'If an emissary or family member fetched the items, specify their name.'}
                </span>
              </div>

              <div className="mt-4 flex items-center justify-end gap-2 pt-3 border-t theme-border-subtle">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddCreditModalOpen(false);
                    setCreditHandledBy('');
                  }}
                  className="px-4 py-2 rounded-xl theme-text-secondary font-bold hover:bg-white/10"
                >
                  {translate(lang, 'btn_cancel')}
                </button>
                <button
                  type="button"
                  onClick={handleAddCredit}
                  className="theme-bg-primary text-white px-5 py-2 rounded-xl font-bold shadow-2xs active:scale-95 cursor-pointer"
                >
                  {translate(lang, 'btn_save_confirm')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: SMS / GCash Reminder */}
      {isReminderModalOpen && selectedCustomer && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="theme-card rounded-3xl max-w-md w-full p-5 shadow-2xl border">
            <h3 className="font-extrabold theme-text-app text-base mb-2 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              {lang === 'tl' ? 'Padala Paalala sa Pautang' : 'Send Credit Reminder'}
            </h3>

            <p className="text-xs theme-text-secondary mb-3">
              {lang === 'tl' ? 'Maaari mong kopyahin at i-send sa SMS, Messenger, o GCash text:' : 'You can copy and send via SMS, Messenger, or Chat:'}
            </p>

            <div className="theme-bg-surface-subtle border theme-border-subtle p-3 rounded-2xl text-xs font-sans theme-text-app leading-relaxed mb-4">
              {reminderText}
            </div>

            <div className="flex items-center justify-between gap-2 pt-2 border-t theme-border-subtle">
              <button
                onClick={() => setIsReminderModalOpen(false)}
                className="px-4 py-2 rounded-xl theme-text-secondary font-bold text-xs hover:bg-white/10"
              >
                {lang === 'tl' ? 'Isara' : 'Close'}
              </button>

              <button
                onClick={copyReminder}
                className="theme-bg-primary text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-2xs active:scale-95"
              >
                {copiedSuccess ? (
                  <>
                    <Check className="w-3.5 h-3.5" /> {lang === 'tl' ? 'Na-copy Na!' : 'Copied!'}
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" /> {lang === 'tl' ? 'Kopyahin Mensahe' : 'Copy Message'}
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Debtor History */}
      {isHistoryModalOpen && selectedCustomer && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setIsHistoryModalOpen(false);
            }
          }}
        >
          <div
            className="theme-card rounded-3xl max-w-lg w-full p-5 shadow-2xl border max-h-[85vh] flex flex-col animate-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b theme-border-subtle mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold theme-text-app text-base leading-tight">
                    {lang === 'tl' ? `Listahan ng Utang at Bayad ni ${selectedCustomer.name}` : `Credit & Payment History of ${selectedCustomer.name}`}
                  </h3>
                  <button
                    type="button"
                    onClick={(e) => {
                      setIsHistoryModalOpen(false);
                      handleOpenEditCustomer(selectedCustomer, e);
                    }}
                    className="w-6 h-6 rounded-md bg-white/10 hover:bg-white/20 theme-text-secondary hover:theme-text-app flex items-center justify-center cursor-pointer transition-colors"
                    title={lang === 'tl' ? 'I-edit ang Profile' : 'Edit Customer Profile'}
                  >
                    <Pencil className="w-3 h-3" />
                  </button>
                </div>
                <span className="text-xs font-bold theme-text-secondary">
                  {lang === 'tl' ? 'Kasalukuyang Utang:' : 'Current Balance:'} <strong className={selectedCustomer.currentBalance > 0 ? 'text-amber-400' : 'theme-text-accent'}>{formatPeso(selectedCustomer.currentBalance)}</strong>
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsHistoryModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 theme-text-app flex items-center justify-center cursor-pointer transition-colors"
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
              {transactions
                .filter(
                  (tx) => tx.customerName?.toLowerCase() === selectedCustomer.name.toLowerCase()
                )
                .map((tx) => {
                  const isPautang = tx.type === 'PAUTANG_RECORD';
                  return (
                    <div
                      key={tx.id}
                      onClick={() => setViewingDetailTx(tx)}
                      className="theme-bg-surface-subtle p-3.5 rounded-2xl border theme-border-subtle text-xs space-y-2 hover:border-amber-500/50 hover:bg-white/5 transition-all cursor-pointer group"
                      title={lang === 'tl' ? 'Pindutin para makita ang kumpletong detalye' : 'Tap to view full details'}
                    >
                      <div className="flex items-center justify-between font-bold theme-text-app">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className={`px-2 py-0.5 rounded-lg text-[11px] font-black ${
                              isPautang
                                ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                                : 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            }`}
                          >
                            {isPautang
                              ? (lang === 'tl' ? 'Utang' : 'Credit')
                              : (lang === 'tl' ? 'Bayad' : 'Payment')}
                          </span>

                          {tx.handledBy && (
                            <span className="bg-white/10 theme-text-app text-[10px] font-bold px-2 py-0.5 rounded-md border theme-border-subtle">
                              👤 {isPautang
                                ? (lang === 'tl' ? 'Kinuha ni:' : 'Taken by:')
                                : (lang === 'tl' ? 'Nagbayad:' : 'Paid by:')} {tx.handledBy}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-sm text-[var(--color-primary)]">
                            {formatPeso(tx.totalAmount)}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between theme-text-secondary text-[11px] pt-1 border-t theme-border-subtle">
                        <span className="truncate max-w-[65%]">
                          {formatDisplayNote(tx.rawNote, lang) || (isPautang
                            ? (lang === 'tl' ? 'Tala ng Utang' : 'Credit Record')
                            : (lang === 'tl' ? 'Tala ng Bayad' : 'Payment Record'))}
                        </span>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span>{formatDateTime(tx.timestamp)}</span>
                          <span className="text-[10px] font-bold text-amber-500 opacity-70 group-hover:opacity-100 transition-opacity">
                            {lang === 'tl' ? 'Tingnan →' : 'View →'}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      )}

      {/* Modal: Edit Credit/Payment Entry */}
      {editingTx && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-60 flex items-center justify-center p-4 animate-in fade-in">
          <div
            className="theme-card rounded-3xl max-w-md w-full p-5 shadow-2xl border animate-in zoom-in-95 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b theme-border-subtle">
              <h3 className="font-black theme-text-app text-base flex items-center gap-2">
                <Pencil className="w-4 h-4 theme-text-accent" />
                <span>{lang === 'tl' ? 'I-edit ang Tala' : 'Edit Entry'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setEditingTx(null)}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 theme-text-app flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEditTx} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold theme-text-app mb-1">{lang === 'tl' ? 'Uri ng Transaksyon' : 'Transaction Type'}</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setEditTxType('PAUTANG_RECORD')}
                    className={`py-2 px-3 rounded-xl font-black text-xs border transition-all cursor-pointer ${
                      editTxType === 'PAUTANG_RECORD'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-xs'
                        : 'theme-bg-surface-subtle theme-text-secondary border-transparent'
                    }`}
                  >
                    {lang === 'tl' ? 'Utang (Credit)' : 'Credit'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditTxType('PAUTANG_PAYMENT')}
                    className={`py-2 px-3 rounded-xl font-black text-xs border transition-all cursor-pointer ${
                      editTxType === 'PAUTANG_PAYMENT'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-xs'
                        : 'theme-bg-surface-subtle theme-text-secondary border-transparent'
                    }`}
                  >
                    {lang === 'tl' ? 'Bayad (Payment)' : 'Payment'}
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-bold theme-text-app mb-1">{lang === 'tl' ? 'Halaga (₱) *' : 'Amount (₱) *'}</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={editTxAmount}
                  onChange={(e) => setEditTxAmount(e.target.value)}
                  className="w-full theme-input border rounded-xl p-2.5 text-base font-black theme-text-app focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold theme-text-app mb-1">
                  {lang === 'tl' ? 'Sino ang nagbayad / kumuha? (Optional)' : 'Who paid / picked up? (Optional)'}
                </label>
                <input
                  type="text"
                  value={editTxHandledBy}
                  onChange={(e) => setEditTxHandledBy(e.target.value)}
                  placeholder={lang === 'tl' ? `Iwanang blangko kung si ${editingTx.customerName || selectedCustomer?.name} mismo (o hal. Pedro, Asawa)` : `Leave blank if ${editingTx.customerName || selectedCustomer?.name} self (or enter e.g. Spouse)`}
                  className="w-full theme-input border rounded-xl p-2.5 font-medium theme-text-app focus:outline-none"
                />
                <span className="text-[10px] theme-text-secondary mt-0.5 block">
                  {lang === 'tl' ? 'Kung hindi ang mismong may utang ang nagbayad o kumuha, ilagay ang kanyang pangalan rito.' : 'If someone else handled this transaction, specify their name here.'}
                </span>
              </div>

              <div>
                <label className="block font-bold theme-text-app mb-1">{lang === 'tl' ? 'Tala / Detalye ng Kinuha' : 'Note / Items Detail'}</label>
                <input
                  type="text"
                  value={editTxNote}
                  onChange={(e) => setEditTxNote(e.target.value)}
                  placeholder={lang === 'tl' ? 'Hal. 2 canton, softdrinks' : 'E.g. 2 canton, softdrinks'}
                  className="w-full theme-input border rounded-xl p-2.5 font-medium theme-text-app focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between gap-2 pt-3 border-t theme-border-subtle mt-4">
                <button
                  type="button"
                  onClick={() => handleDeleteTx(editingTx.id)}
                  className="px-3 py-2 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-red-300 font-bold flex items-center gap-1 cursor-pointer transition-all active:scale-95"
                >
                  <Trash2 className="w-3.5 h-3.5" /> {lang === 'tl' ? 'Tanggalin' : 'Delete'}
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingTx(null)}
                    className="px-3 py-2 rounded-xl theme-text-secondary font-bold hover:bg-white/10 cursor-pointer"
                  >
                    {translate(lang, 'btn_cancel')}
                  </button>
                  <button
                    type="submit"
                    className="theme-bg-primary text-white px-4 py-2 rounded-xl font-bold shadow-2xs active:scale-95 cursor-pointer"
                  >
                    {translate(lang, 'btn_save_confirm')}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Modal: Edit Customer Profile */}
      {isEditCustomerOpen && selectedCustomer && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div
            className="theme-card rounded-3xl max-w-sm w-full p-5 shadow-2xl border animate-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b theme-border-subtle mb-4">
              <h3 className="font-extrabold theme-text-app text-base flex items-center gap-2">
                <Pencil className="w-4 h-4 theme-text-accent" />
                <span>{lang === 'tl' ? 'I-edit ang Profile ng Suki' : 'Edit Customer Profile'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsEditCustomerOpen(false)}
                className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 theme-text-app flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEditCustomer} className="space-y-3">
              <div>
                <label className="block text-xs font-bold theme-text-app mb-1">
                  {lang === 'tl' ? 'Pangalan ng Suki *' : 'Customer Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={editCustomerName}
                  onChange={(e) => setEditCustomerName(e.target.value)}
                  placeholder={lang === 'tl' ? 'Pangalan ng Customer' : 'Customer Name'}
                  className="w-full theme-input border rounded-xl p-2.5 text-xs font-bold theme-text-app focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold theme-text-app mb-1">
                  {lang === 'tl' ? 'Cellphone Number (Max 11 digits)' : 'Phone Number (Max 11 digits)'}
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    maxLength={11}
                    value={editCustomerPhone}
                    onChange={(e) => {
                      const digits = e.target.value.replace(/\D/g, '').slice(0, 11);
                      setEditCustomerPhone(digits);
                    }}
                    placeholder={lang === 'tl' ? '09171234567 (11 digits)' : '09171234567 (11 digits)'}
                    className="w-full theme-input border rounded-xl p-2.5 text-xs font-medium theme-text-app focus:outline-none pr-12 font-mono"
                  />
                  <span className="absolute right-2.5 top-2.5 text-[10px] theme-text-secondary font-mono">
                    {editCustomerPhone.length}/11
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold theme-text-app mb-1">
                  {lang === 'tl' ? 'Tala / Notes (Optional)' : 'Notes (Optional)'}
                </label>
                <textarea
                  value={editCustomerNotes}
                  onChange={(e) => setEditCustomerNotes(e.target.value)}
                  placeholder={lang === 'tl' ? 'Hal. Kapitbahay sa tapat, suki ng softdrinks' : 'E.g. Neighbor across street, regular soda buyer'}
                  rows={2}
                  className="w-full theme-input border rounded-xl p-2.5 text-xs font-medium theme-text-app focus:outline-none"
                />
              </div>

              <div className="mt-4 flex items-center justify-end gap-2 pt-3 border-t theme-border-subtle">
                <button
                  type="button"
                  onClick={() => setIsEditCustomerOpen(false)}
                  className="px-4 py-2 rounded-xl theme-text-secondary font-bold hover:bg-white/10 cursor-pointer"
                >
                  {translate(lang, 'btn_cancel')}
                </button>
                <button
                  type="submit"
                  className="theme-bg-primary text-white px-5 py-2 rounded-xl font-bold shadow-2xs active:scale-95 cursor-pointer"
                >
                  {translate(lang, 'btn_save_confirm')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Transaction Details Modal when tapping a history item */}
      {viewingDetailTx && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-xs z-60 flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => setViewingDetailTx(null)}
        >
          <div
            className="theme-card rounded-3xl max-w-sm w-full p-5 shadow-2xl border theme-border-app space-y-4 animate-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b theme-border-subtle pb-3">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-amber-500" />
                <div>
                  <h3 className="font-extrabold theme-text-app text-sm">
                    {lang === 'tl' ? 'Resibo ng Transaksyon' : 'Transaction Receipt'}
                  </h3>
                  <p className="text-[10px] theme-text-secondary font-medium">
                    {formatDateTime(viewingDetailTx.timestamp)}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setViewingDetailTx(null)}
                className="p-1 hover:bg-white/10 rounded-full theme-text-secondary hover:theme-text-app cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Transaction metadata */}
            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center py-1 border-b theme-border-subtle">
                <span className="theme-text-secondary">{lang === 'tl' ? 'Uri:' : 'Type:'}</span>
                <span
                  className={`font-black px-2 py-0.5 rounded-md text-[11px] ${
                    viewingDetailTx.type === 'PAUTANG_RECORD'
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                  }`}
                >
                  {viewingDetailTx.type === 'PAUTANG_RECORD'
                    ? (lang === 'tl' ? 'Pautang (Credit)' : 'Credit Purchase')
                    : (lang === 'tl' ? 'Bayad (Payment)' : 'Payment Received')}
                </span>
              </div>

              {viewingDetailTx.customerName && (
                <div className="flex justify-between items-center py-1 border-b theme-border-subtle">
                  <span className="theme-text-secondary">{lang === 'tl' ? 'Suki / Customer:' : 'Customer:'}</span>
                  <span className="font-bold theme-text-app">{viewingDetailTx.customerName}</span>
                </div>
              )}

              {viewingDetailTx.handledBy && (
                <div className="flex justify-between items-center py-1 border-b theme-border-subtle">
                  <span className="theme-text-secondary">{lang === 'tl' ? 'Kinuha / Binuhat ni:' : 'Taken / Paid by:'}</span>
                  <span className="font-bold theme-text-app">{viewingDetailTx.handledBy}</span>
                </div>
              )}

              {/* Itemized List if present */}
              {viewingDetailTx.items && viewingDetailTx.items.length > 0 && (
                <div className="pt-2 space-y-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider theme-text-secondary block">
                    {lang === 'tl' ? 'Mga Item na Kinuha:' : 'Items Purchased:'}
                  </span>
                  <div className="theme-bg-surface-subtle p-2.5 rounded-xl border theme-border-subtle space-y-1.5">
                    {viewingDetailTx.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between items-center text-xs">
                        <div className="font-bold theme-text-app truncate max-w-[65%]">
                          {it.itemName} <span className="theme-text-secondary text-[10px] font-mono">×{it.quantity}</span>
                        </div>
                        <div className="font-mono font-bold theme-text-accent">
                          {formatPeso(it.totalPrice)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Total Amount */}
              <div className="flex justify-between items-center pt-2 font-black text-sm border-t theme-border-subtle">
                <span className="theme-text-app">{lang === 'tl' ? 'Kabuuan (Total):' : 'Total Amount:'}</span>
                <span className="font-mono text-base theme-text-accent">{formatPeso(viewingDetailTx.totalAmount)}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setViewingDetailTx(null)}
              className="w-full theme-bg-primary text-white font-bold py-2.5 rounded-xl text-xs active:scale-95 cursor-pointer"
            >
              {lang === 'tl' ? 'Isara' : 'Close'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

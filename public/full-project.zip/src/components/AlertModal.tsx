import React from 'react';
import { AlertTriangle, Info, CheckCircle2, X } from 'lucide-react';

interface AlertModalProps {
  isOpen: boolean;
  title?: string;
  message: string;
  type?: 'error' | 'warning' | 'info' | 'success';
  buttonText?: string;
  onClose: () => void;
}

export const AlertModal: React.FC<AlertModalProps> = ({
  isOpen,
  title,
  message,
  type = 'warning',
  buttonText = 'OK',
  onClose,
}) => {
  if (!isOpen) return null;

  const defaultTitle =
    type === 'error'
      ? 'Pansin (Error)'
      : type === 'warning'
      ? 'Paalala (Warning)'
      : type === 'success'
      ? 'Tagumpay (Success)'
      : 'Impormasyon (Info)';

  const displayTitle = title || defaultTitle;

  const getIcon = () => {
    switch (type) {
      case 'error':
        return <AlertTriangle className="w-5 h-5 text-red-400" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-amber-400" />;
      case 'success':
        return <CheckCircle2 className="w-5 h-5 text-emerald-400" />;
      default:
        return <Info className="w-5 h-5 theme-text-accent" />;
    }
  };

  const getIconBg = () => {
    switch (type) {
      case 'error':
        return 'bg-red-500/15 border border-red-500/30';
      case 'warning':
        return 'bg-amber-500/15 border border-amber-500/30';
      case 'success':
        return 'bg-emerald-500/15 border border-emerald-500/30';
      default:
        return 'theme-bg-surface-subtle border theme-border-subtle';
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          console.log('[AlertModal] Backdrop clicked -> onClose');
          onClose();
        }
      }}
    >
      <div
        className="theme-card rounded-3xl max-w-sm w-full p-5 sm:p-6 shadow-2xl border animate-in zoom-in-95 space-y-4"
        onClick={(e) => e.stopPropagation()}
        style={{ touchAction: 'manipulation' }}
      >
        <div className="flex items-start justify-between gap-2 border-b theme-border-subtle pb-3">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 ${getIconBg()}`}>
              {getIcon()}
            </div>
            <div>
              <h3 className="font-black theme-text-app text-base leading-tight">{displayTitle}</h3>
            </div>
          </div>

          <button
            type="button"
            role="button"
            tabIndex={0}
            onClick={() => {
              console.log('[AlertModal] Close icon clicked -> onClose');
              onClose();
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClose();
              }
            }}
            className="w-8 h-8 rounded-xl theme-bg-surface-subtle hover:bg-white/10 theme-text-secondary flex items-center justify-center cursor-pointer active:scale-95 transition-all select-none touch-manipulation"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs sm:text-sm theme-text-app leading-relaxed font-semibold whitespace-pre-line">
          {message}
        </p>

        <div className="pt-2 border-t theme-border-subtle">
          <button
            type="button"
            role="button"
            tabIndex={0}
            onClick={() => {
              console.log('[AlertModal] OK button clicked -> onClose');
              onClose();
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClose();
              }
            }}
            className="w-full theme-bg-primary text-white py-2.5 rounded-xl font-black text-xs shadow-2xs active:scale-95 transition-all cursor-pointer select-none touch-manipulation text-center"
          >
            {buttonText}
          </button>
        </div>
      </div>
    </div>
  );
};

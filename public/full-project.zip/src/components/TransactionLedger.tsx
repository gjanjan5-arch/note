import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowUpRight,
  ArrowDownLeft,
  ShoppingBag,
  RefreshCw,
  Filter,
  Check,
  X,
  Receipt,
} from 'lucide-react';
import type { Transaction, TransactionType } from '../types';
import { formatPeso, formatDateTime, getLocalDateStr, formatDisplayItemName, formatDisplayNote } from '../utils/formatters';
import { translate, type LanguageCode } from '../utils/i18n';

interface TransactionLedgerProps {
  transactions: Transaction[];
  lang: LanguageCode;
  onRefresh: () => void;
}

export const TransactionLedger: React.FC<TransactionLedgerProps> = ({
  transactions,
  lang,
}) => {
  const [selectedTypes, setSelectedTypes] = useState<TransactionType[]>([]);
  const [isSortAZ, setIsSortAZ] = useState(false);
  const [isFilterDropdownOpen, setIsFilterDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [selectedDateFilter, setSelectedDateFilter] = useState<'TODAY' | 'YESTERDAY' | 'ALL'>('TODAY');
  const [viewDetailTx, setViewDetailTx] = useState<Transaction | null>(null);
  const touchStartRef = useRef<{ x: number; y: number; time: number } | null>(null);
  const lastSelectTimeRef = useRef<number>(0);

  useEffect(() => {
    if (viewDetailTx) {
      console.log('[TransactionLedger] Detail view active for transaction:', {
        id: viewDetailTx.id,
        type: viewDetailTx.type,
        customerName: viewDetailTx.customerName,
        totalAmount: viewDetailTx.totalAmount,
        items: viewDetailTx.items,
        timestamp: viewDetailTx.timestamp,
        dateStr: viewDetailTx.dateStr,
      });
    } else {
      console.log('[TransactionLedger] Detail view closed');
    }
  }, [viewDetailTx]);

  const handleItemSelect = (tx: Transaction, eventSource: string) => {
    const now = Date.now();
    // Prevent duplicate rapid triggers within 300ms
    if (now - lastSelectTimeRef.current < 300) return;
    lastSelectTimeRef.current = now;

    console.log(`[TransactionLedger] History item selected via ${eventSource}:`, {
      id: tx.id,
      type: tx.type,
      customerName: tx.customerName,
      totalAmount: tx.totalAmount,
      itemsCount: tx.items?.length || 0,
      timestamp: tx.timestamp,
    });
    setViewDetailTx(tx);
  };

  const handleCardTouchStart = (e: React.TouchEvent) => {
    const t = e.touches[0];
    if (t) {
      touchStartRef.current = { x: t.clientX, y: t.clientY, time: Date.now() };
    }
  };

  const handleCardTouchEnd = (tx: Transaction, e: React.TouchEvent) => {
    if (!touchStartRef.current) return;
    const t = e.changedTouches[0];
    if (t) {
      const dx = Math.abs(t.clientX - touchStartRef.current.x);
      const dy = Math.abs(t.clientY - touchStartRef.current.y);
      const dt = Date.now() - touchStartRef.current.time;
      // If finger moved less than 12px and tap was under 400ms, consider it a valid tap
      if (dx < 12 && dy < 12 && dt < 400) {
        handleItemSelect(tx, 'onTouchEnd');
      }
    }
    touchStartRef.current = null;
  };

  const todayStr = getLocalDateStr();
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = getLocalDateStr(yesterday);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsFilterDropdownOpen(false);
      }
    };
    if (isFilterDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isFilterDropdownOpen]);

  const toggleType = (type: TransactionType) => {
    setSelectedTypes((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );
  };

  // Filter & Sort logic
  const filteredTx = (transactions || [])
    .filter((tx) => {
      if (!tx) return false;

      // 1. Date Filter (using local device dateStr or local formatted timestamp)
      const txDate = tx.dateStr || getLocalDateStr(tx.timestamp);
      if (selectedDateFilter === 'TODAY' && txDate !== todayStr) return false;
      if (selectedDateFilter === 'YESTERDAY' && txDate !== yesterdayStr) return false;

      // 2. Type Filter (Multi-select / empty = all)
      if (selectedTypes.length > 0 && !selectedTypes.includes(tx.type)) return false;

      return true;
    })
    .sort((a, b) => {
      if (isSortAZ) {
        const nameA = (
          a.customerName ||
          (a.items && a.items[0]?.itemName) ||
          a.rawNote ||
          ''
        ).toLowerCase();
        const nameB = (
          b.customerName ||
          (b.items && b.items[0]?.itemName) ||
          b.rawNote ||
          ''
        ).toLowerCase();
        return nameA.localeCompare(nameB);
      }
      // Default: Most recent first
      return (b.timestamp || 0) - (a.timestamp || 0);
    });

  const activeFiltersCount = selectedTypes.length + (isSortAZ ? 1 : 0);

  return (
    <div id="transaction-ledger-container" className="space-y-4">
      {/* Date & Type Filter Controls */}
      <div id="transaction-filter-header" className="theme-card p-3.5 sm:p-4 rounded-3xl shadow-2xs border transition-colors duration-200">
        <div className="flex flex-wrap items-center justify-between gap-2.5">
          {/* Date Range Tabs */}
          <div className="flex items-center gap-1 theme-bg-surface-subtle p-1 rounded-2xl text-xs font-extrabold border theme-border-subtle">
            <button
              type="button"
              onClick={() => setSelectedDateFilter('TODAY')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer select-none touch-manipulation active:scale-95 ${
                selectedDateFilter === 'TODAY'
                  ? 'theme-bg-primary text-white shadow-2xs'
                  : 'theme-text-secondary hover:theme-text-app'
              }`}
            >
              {translate(lang, 'filter_today')}
            </button>
            <button
              type="button"
              onClick={() => setSelectedDateFilter('YESTERDAY')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer select-none touch-manipulation active:scale-95 ${
                selectedDateFilter === 'YESTERDAY'
                  ? 'theme-bg-primary text-white shadow-2xs'
                  : 'theme-text-secondary hover:theme-text-app'
              }`}
            >
              {translate(lang, 'filter_yesterday')}
            </button>
            <button
              type="button"
              onClick={() => setSelectedDateFilter('ALL')}
              className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer select-none touch-manipulation active:scale-95 ${
                selectedDateFilter === 'ALL'
                  ? 'theme-bg-primary text-white shadow-2xs'
                  : 'theme-text-secondary hover:theme-text-app'
              }`}
            >
              {translate(lang, 'filter_all')}
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter by Dropdown Anchor */}
            <div className="relative" ref={dropdownRef}>
              <button
                type="button"
                onClick={() => setIsFilterDropdownOpen((prev) => !prev)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-extrabold border transition-all active:scale-95 shadow-2xs cursor-pointer select-none touch-manipulation ${
                  activeFiltersCount > 0
                    ? 'theme-bg-primary text-white border-white/20'
                    : 'theme-bg-surface-subtle hover:bg-white/10 theme-text-app border-theme-border-subtle'
                }`}
              >
                <Filter className="w-3.5 h-3.5" />
                <span>{translate(lang, 'filter_by') || 'Filter by'}</span>
                {activeFiltersCount > 0 && (
                  <span className="w-4 h-4 rounded-full bg-white text-[var(--color-primary)] flex items-center justify-center text-[10px] font-black shrink-0">
                    {activeFiltersCount}
                  </span>
                )}
              </button>

              {/* Dropdown Menu */}
              {isFilterDropdownOpen && (
                <div className="absolute left-0 sm:left-auto sm:right-0 mt-2 w-60 max-w-[calc(100vw-2rem)] theme-card rounded-2xl p-2 shadow-2xl border theme-border-subtle z-50 animate-in fade-in zoom-in-95 space-y-1">
                  {/* Option 1: A → Z */}
                  <button
                    type="button"
                    onClick={() => setIsSortAZ((prev) => !prev)}
                    className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-bold transition-all text-left cursor-pointer select-none touch-manipulation ${
                      isSortAZ
                        ? 'theme-bg-primary text-white'
                        : 'theme-text-app hover:theme-bg-surface-subtle'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm">🔤</span>
                      <span>A → Z ({lang === 'tl' ? 'Alpabetiko' : 'Alphabetical'})</span>
                    </div>
                    {isSortAZ && <Check className="w-3.5 h-3.5" />}
                  </button>

                  <div className="border-t theme-border-subtle my-1" />

                  {/* Option 2: Sale */}
                  <button
                    type="button"
                    onClick={() => toggleType('SALE')}
                    className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-bold transition-all text-left cursor-pointer select-none touch-manipulation ${
                      selectedTypes.includes('SALE')
                        ? 'theme-bg-primary text-white'
                        : 'theme-text-app hover:theme-bg-surface-subtle'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm">🛒</span>
                      <span>{translate(lang, 'type_sale')}</span>
                    </div>
                    {selectedTypes.includes('SALE') && <Check className="w-3.5 h-3.5" />}
                  </button>

                  {/* Option 3: Credit */}
                  <button
                    type="button"
                    onClick={() => toggleType('PAUTANG_RECORD')}
                    className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-bold transition-all text-left cursor-pointer select-none touch-manipulation ${
                      selectedTypes.includes('PAUTANG_RECORD')
                        ? 'theme-bg-primary text-white'
                        : 'theme-text-app hover:theme-bg-surface-subtle'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm">💳</span>
                      <span>{translate(lang, 'type_pautang')}</span>
                    </div>
                    {selectedTypes.includes('PAUTANG_RECORD') && <Check className="w-3.5 h-3.5" />}
                  </button>

                  {/* Option 4: Payment */}
                  <button
                    type="button"
                    onClick={() => toggleType('PAUTANG_PAYMENT')}
                    className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-bold transition-all text-left cursor-pointer select-none touch-manipulation ${
                      selectedTypes.includes('PAUTANG_PAYMENT')
                        ? 'theme-bg-primary text-white'
                        : 'theme-text-app hover:theme-bg-surface-subtle'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm">💰</span>
                      <span>{translate(lang, 'type_bayad')}</span>
                    </div>
                    {selectedTypes.includes('PAUTANG_PAYMENT') && <Check className="w-3.5 h-3.5" />}
                  </button>

                  {/* Option 5: Restock */}
                  <button
                    type="button"
                    onClick={() => toggleType('RESTOCK')}
                    className={`w-full flex items-center justify-between p-2 rounded-xl text-xs font-bold transition-all text-left cursor-pointer select-none touch-manipulation ${
                      selectedTypes.includes('RESTOCK')
                        ? 'theme-bg-primary text-white'
                        : 'theme-text-app hover:theme-bg-surface-subtle'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm">📦</span>
                      <span>{translate(lang, 'type_restock')}</span>
                    </div>
                    {selectedTypes.includes('RESTOCK') && <Check className="w-3.5 h-3.5" />}
                  </button>

                  {/* Clear all if any active */}
                  {activeFiltersCount > 0 && (
                    <div className="pt-1 border-t theme-border-subtle">
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedTypes([]);
                          setIsSortAZ(false);
                        }}
                        className="w-full text-center py-1.5 text-[11px] font-bold theme-text-secondary hover:theme-text-accent cursor-pointer select-none touch-manipulation"
                      >
                        {lang === 'tl' ? 'I-reset ang filter' : 'Clear all filters'}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Transaction List Feed */}
      <div className="space-y-2.5">
        {filteredTx.length === 0 ? (
          <div id="transaction-empty-state" className="theme-card rounded-3xl p-8 text-center border border-dashed theme-border theme-text-secondary">
            <ShoppingBag className="w-10 h-10 mx-auto mb-2 opacity-50" />
            <p className="text-sm font-bold theme-text-app">{translate(lang, 'no_records_found')}</p>
            <p className="text-xs theme-text-secondary mt-1">
              {translate(lang, 'quick_entry_placeholder')}
            </p>
          </div>
        ) : (
          filteredTx.map((tx, index) => {
            const badgeStyles: Record<
              TransactionType,
              { bg: string; label: string; icon: any }
            > = {
              SALE: {
                bg: 'theme-bg-surface-subtle theme-text-accent border theme-border-subtle',
                label: translate(lang, 'type_sale'),
                icon: ShoppingBag,
              },
              PAUTANG_RECORD: {
                bg: 'bg-amber-500/15 text-amber-300 border border-amber-500/30',
                label: translate(lang, 'type_pautang'),
                icon: ArrowUpRight,
              },
              PAUTANG_PAYMENT: {
                bg: 'bg-blue-500/15 text-blue-300 border border-blue-500/30',
                label: translate(lang, 'type_bayad'),
                icon: ArrowDownLeft,
              },
              RESTOCK: {
                bg: 'bg-purple-500/15 text-purple-300 border border-purple-500/30',
                label: translate(lang, 'type_restock'),
                icon: RefreshCw,
              },
            };

            const style = badgeStyles[tx.type] || badgeStyles.SALE;
            const Icon = style.icon;

            return (
              <div
                key={tx.id}
                id={index === 0 ? 'first-transaction-card' : undefined}
                role="button"
                tabIndex={0}
                aria-label={`View transaction details for ${tx.customerName || tx.type}`}
                onTouchStart={handleCardTouchStart}
                onTouchEnd={(e) => handleCardTouchEnd(tx, e)}
                onClick={(e) => {
                  e.stopPropagation();
                  handleItemSelect(tx, 'onClick');
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    handleItemSelect(tx, 'onKeyDown');
                  }
                }}
                className="theme-card rounded-3xl p-3.5 sm:p-4 shadow-2xs border hover:border-[var(--color-primary)] active:scale-[0.98] transition-all flex items-start justify-between gap-3 cursor-pointer select-none touch-manipulation hardware-accelerated focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]"
              >
                <div className="space-y-1.5 flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className={`inline-flex items-center gap-1 text-[11px] font-black px-2.5 py-0.5 rounded-lg ${style.bg}`}
                    >
                      <Icon className="w-3 h-3" />
                      {style.label}
                    </span>

                    {tx.customerName && (
                      <span className="text-xs font-black theme-text-app theme-bg-surface-subtle px-2 py-0.5 rounded-lg border theme-border-subtle">
                        👤 {tx.customerName}
                      </span>
                    )}

                    {tx.handledBy && (
                      <span className="text-[11px] font-bold text-amber-300 bg-amber-500/15 px-2 py-0.5 rounded-lg border border-amber-500/30">
                        {tx.type === 'PAUTANG_RECORD' ? (lang === 'tl' ? 'Kinuha ni' : 'Taken by') : (lang === 'tl' ? 'Nagbayad' : 'Paid by')}: {tx.handledBy}
                      </span>
                    )}

                    <span className="text-[11px] font-medium theme-text-secondary ml-auto">
                      {formatDateTime(tx.timestamp)}
                    </span>
                  </div>

                  {/* Transaction items list */}
                  {tx.items && tx.items.length > 0 ? (
                    <div className="text-xs font-semibold theme-text-app space-y-0.5 pl-0.5">
                      {tx.items.map((it, i) => (
                        <div key={i} className="flex items-center justify-between gap-2">
                          <span className="truncate">
                            • {it.quantity}x {formatDisplayItemName(it.itemName, lang)}
                          </span>
                          <span className="theme-text-secondary font-mono text-[11px]">
                            {formatPeso(it.totalPrice)}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs font-medium theme-text-secondary italic">"{formatDisplayNote(tx.rawNote, lang)}"</p>
                  )}
                </div>

                <div className="text-right shrink-0 flex flex-col items-end justify-center self-stretch">
                  <span className="text-sm sm:text-base font-black theme-text-app">
                    {formatPeso(tx.totalAmount)}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Transaction Breakdown / Receipt Modal */}
      {viewDetailTx && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              console.log('[TransactionLedger] Modal backdrop clicked, closing detail view');
              setViewDetailTx(null);
            }
          }}
        >
          <div
            className="theme-card rounded-3xl max-w-sm w-full p-5 sm:p-6 shadow-2xl border animate-in zoom-in-95 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b theme-border-subtle">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 theme-text-accent" />
                <h3 className="font-black theme-text-app text-base">
                  {lang === 'tl' ? 'Detalye ng Transaksyon' : 'Transaction Receipt'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  console.log('[TransactionLedger] Close icon clicked, closing modal');
                  setViewDetailTx(null);
                }}
                className="w-8 h-8 rounded-xl theme-bg-surface-subtle hover:bg-white/10 theme-text-secondary flex items-center justify-center cursor-pointer active:scale-95 transition-all"
                aria-label={translate(lang, 'btn_cancel') || 'Close'}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="theme-bg-surface-subtle p-3 rounded-2xl border theme-border-subtle space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="theme-text-secondary">{translate(lang, 'date') || 'Date'}:</span>
                  <span className="font-bold theme-text-app">{formatDateTime(viewDetailTx.timestamp)}</span>
                </div>
                {viewDetailTx.customerName && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="theme-text-secondary">{translate(lang, 'customer_name') || 'Customer'}:</span>
                    <span className="font-black theme-text-accent">{viewDetailTx.customerName}</span>
                  </div>
                )}
                {viewDetailTx.handledBy && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="theme-text-secondary">{viewDetailTx.type === 'PAUTANG_RECORD' ? (lang === 'tl' ? 'Kinuha ni' : 'Taken by') : (lang === 'tl' ? 'Nagbayad' : 'Paid by')}:</span>
                    <span className="font-bold text-amber-300">{viewDetailTx.handledBy}</span>
                  </div>
                )}
                <div className="flex items-center justify-between text-xs">
                  <span className="theme-text-secondary">{lang === 'tl' ? 'Uri' : 'Type'}:</span>
                  <span className="font-bold theme-text-app">
                    {viewDetailTx.type === 'SALE'
                      ? translate(lang, 'type_sale')
                      : viewDetailTx.type === 'PAUTANG_RECORD'
                      ? translate(lang, 'type_pautang')
                      : viewDetailTx.type === 'PAUTANG_PAYMENT'
                      ? translate(lang, 'type_bayad')
                      : translate(lang, 'type_restock')}
                  </span>
                </div>
              </div>

              {/* Items Table */}
              {viewDetailTx.items && viewDetailTx.items.length > 0 ? (
                <div className="theme-bg-surface-subtle p-3 rounded-2xl border theme-border-subtle space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-wider theme-text-secondary block border-b theme-border-subtle pb-1">
                    {lang === 'tl' ? 'Mga Binili / Kasama' : 'Items Included'}
                  </span>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {viewDetailTx.items.map((it, idx) => (
                      <div key={idx} className="flex items-center justify-between gap-2">
                        <span className="font-bold theme-text-app truncate">
                          {it.quantity}x {formatDisplayItemName(it.itemName, lang)}
                        </span>
                        <span className="font-mono font-bold theme-text-app shrink-0">
                          {formatPeso(it.totalPrice)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="theme-bg-surface-subtle p-3 rounded-2xl border theme-border-subtle">
                  <p className="text-xs theme-text-secondary italic">"{formatDisplayNote(viewDetailTx.rawNote, lang)}"</p>
                </div>
              )}

              {/* Amount Summary */}
              <div className="theme-bg-surface-subtle p-3.5 rounded-2xl border theme-border-subtle space-y-1.5 font-bold">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-black theme-text-app">{translate(lang, 'total_price_label') || 'Total Amount'}:</span>
                  <span className="text-base font-black theme-text-accent">{formatPeso(viewDetailTx.totalAmount)}</span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t theme-border-subtle">
              <button
                type="button"
                onClick={() => {
                  console.log('[TransactionLedger] Close action button clicked, closing modal');
                  setViewDetailTx(null);
                }}
                className="w-full theme-bg-primary text-white py-2.5 rounded-xl font-black text-xs shadow-2xs active:scale-95 transition-all cursor-pointer"
              >
                {translate(lang, 'btn_cancel') || 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


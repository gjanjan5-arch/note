import React, { useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { motion, AnimatePresence } from 'motion/react';
import { X, RefreshCw, QrCode, Store, ChevronLeft, ChevronRight, PackageCheck, Layers } from 'lucide-react';
import QRCode from 'react-qr-code';
import LZString from 'lz-string';
import { db } from '../db/db';
import type { InventoryItem } from '../types';
import { getStoreProfile, type StoreProfile } from '../utils/storeSettings';
import { translate, type LanguageCode } from '../utils/i18n';

interface StoreQRModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory?: InventoryItem[];
  storeSettings?: StoreProfile;
  lang: LanguageCode;
}

const MAX_QR_CHAR_LIMIT = 450; // Low-density character threshold for ultra-fast camera scan response

export const StoreQRModal: React.FC<StoreQRModalProps> = ({
  isOpen,
  onClose,
  inventory,
  storeSettings,
  lang,
}) => {
  const dbInventory = useLiveQuery(() => db.inventory.toArray()) || [];
  const activeInventory = inventory || dbInventory;
  const profile: StoreProfile = storeSettings || getStoreProfile();

  const [lastRefreshed, setLastRefreshed] = useState<number>(Date.now());
  const [currentPage, setCurrentPage] = useState<number>(0);

  // Compress store catalog into single or multi-page chunks
  const qrChunks = useMemo(() => {
    // Sanitize item catalog into compact v3 array tuples: [name, price, stock, sku, category, rawVariants]
    const compactItems = activeInventory.map((item) => [
      item.name,
      item.unitPrice,
      item.stock,
      item.sku || '',
      item.category || '',
      item.variants && item.variants.length > 0
        ? item.variants.map((v) => [v.label, v.unitPrice])
        : undefined,
    ]);

    const storeName = profile?.storeName || (lang === 'tl' ? 'Aking Tindahan' : 'My Store');

    const basePayload = {
      v: 3,
      t: 'SC',
      s: storeName,
      o: profile?.ownerName || '',
      c: profile?.contactNumber || '',
      a: profile?.storeAddress || '',
      g: profile?.gcashNumber || '',
      ts: lastRefreshed,
      i: compactItems,
    };

    const jsonString = JSON.stringify(basePayload);
    const compressed = LZString.compressToEncodedURIComponent(jsonString);

    if (compressed.length <= MAX_QR_CHAR_LIMIT) {
      return [compressed];
    }

    // Split items into chunks if compressed data exceeds optimal limit
    const chunkSize = Math.max(
      1,
      Math.floor(compactItems.length / Math.ceil(compressed.length / MAX_QR_CHAR_LIMIT))
    );
    const chunks: string[] = [];
    const totalPages = Math.ceil(compactItems.length / chunkSize);

    for (let i = 0; i < totalPages; i++) {
      const pageItems = compactItems.slice(i * chunkSize, (i + 1) * chunkSize);
      const pagePayload = {
        ...basePayload,
        p: i + 1,
        tp: totalPages,
        i: pageItems,
      };
      const chunkCompressed = LZString.compressToEncodedURIComponent(JSON.stringify(pagePayload));
      chunks.push(chunkCompressed);
    }

    return chunks.length > 0 ? chunks : [compressed];
  }, [activeInventory, profile, lastRefreshed, lang]);

  const totalPages = qrChunks.length;
  const currentChunk = qrChunks[Math.min(currentPage, totalPages - 1)] || '';

  const handleRefresh = () => {
    setLastRefreshed(Date.now());
    setCurrentPage(0);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md select-none overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-sm rounded-3xl theme-bg-card border theme-border shadow-2xl p-6 theme-text-app flex flex-col items-center"
        >
          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full theme-bg-surface-subtle theme-text-secondary hover:theme-text-app transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="flex items-center gap-2.5 mb-2">
            <div className="p-2.5 rounded-2xl theme-bg-primary text-white shadow-xs">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight theme-text-app">
                {profile?.storeName || (lang === 'tl' ? 'Aking Tindahan' : 'My Store')}
              </h2>
              <p className="text-xs font-bold theme-text-accent flex items-center gap-1">
                <QrCode className="w-3.5 h-3.5" />
                <span>{lang === 'tl' ? 'Store Catalog QR' : 'Store Catalog QR'}</span>
              </p>
            </div>
          </div>

          {/* Subtitle / Item Count */}
          <div className="flex items-center gap-2 px-3 py-1 rounded-full theme-bg-surface-subtle border theme-border-subtle text-xs font-bold theme-text-secondary mb-5">
            <PackageCheck className="w-3.5 h-3.5 theme-text-accent" />
            <span>
              {activeInventory.length} {lang === 'tl' ? 'paninda sa QR' : 'items cataloged'}
            </span>
          </div>

          {/* QR Code Canvas Frame with Central Tindahan Notes Logo */}
          <div className="relative p-4 bg-white rounded-3xl shadow-inner flex items-center justify-center border-4 theme-border mb-4 w-full max-w-[260px] aspect-square">
            {currentChunk ? (
              <div className="relative w-full h-full flex items-center justify-center">
                <QRCode
                  value={currentChunk}
                  size={220}
                  level="H"
                  style={{ height: 'auto', maxWidth: '100%', width: '100%' }}
                  viewBox={`0 0 256 256`}
                />
                {/* Central Branded Logo Badge (Safely sized under 10% of QR width to protect level="H" error correction) */}
                <div className="absolute z-20 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-7 h-7 bg-white rounded-lg border border-amber-500 shadow-xs flex items-center justify-center p-0.5 pointer-events-none">
                  <div className="w-full h-full rounded-md bg-amber-500 text-slate-950 font-black flex items-center justify-center shadow-2xs relative overflow-hidden">
                    <Store className="w-3.5 h-3.5 text-slate-950 shrink-0" />
                    <img
                      src="/tindaicon.png"
                      alt="Tindahan Notes"
                      className="absolute inset-0 w-full h-full object-cover rounded-md"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-slate-400 text-xs font-bold">{lang === 'tl' ? 'Walang paninda' : 'No items'}</div>
            )}
          </div>

          {/* Multi-Page Controls if chunked */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between w-full max-w-[260px] mb-4 theme-bg-surface-subtle border theme-border rounded-2xl px-3 py-2">
              <button
                type="button"
                disabled={currentPage === 0}
                onClick={() => setCurrentPage((prev) => Math.max(0, prev - 1))}
                className="p-1.5 rounded-xl theme-bg-surface disabled:opacity-40 theme-text-app transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <div className="text-xs font-black theme-text-accent flex items-center gap-1">
                <Layers className="w-3.5 h-3.5" />
                <span>
                  {lang === 'tl' ? 'Pahina' : 'Page'} {currentPage + 1} / {totalPages}
                </span>
              </div>
              <button
                type="button"
                disabled={currentPage >= totalPages - 1}
                onClick={() => setCurrentPage((prev) => Math.min(totalPages - 1, prev + 1))}
                className="p-1.5 rounded-xl theme-bg-surface disabled:opacity-40 theme-text-app transition-colors cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2 w-full">
            <button
              type="button"
              onClick={handleRefresh}
              className="flex-1 py-2.5 px-3 rounded-2xl theme-bg-surface-subtle hover:theme-bg-surface border theme-border theme-text-app font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer active:scale-95"
            >
              <RefreshCw className="w-3.5 h-3.5 theme-text-accent" />
              <span>{lang === 'tl' ? 'I-refresh QR' : 'Refresh QR'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 px-3 rounded-2xl theme-bg-primary text-white font-black text-xs flex items-center justify-center transition-colors cursor-pointer active:scale-95 shadow-md"
            >
              <span>{lang === 'tl' ? 'Isara' : 'Done'}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

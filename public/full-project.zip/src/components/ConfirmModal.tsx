import React from 'react';
import { AlertCircle, HelpCircle, X, Check } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDestructive?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  isDestructive = false,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          console.log('[ConfirmModal] Backdrop clicked -> onCancel');
          onCancel();
        }
      }}
    >
      <div
        className="theme-card rounded-3xl max-w-sm w-full p-5 sm:p-6 shadow-2xl border animate-in zoom-in-95 space-y-4"
        onClick={(e) => e.stopPropagation()}
        style={{ touchAction: 'manipulation' }}
      >
        <div className="flex items-start justify-between gap-2 border-b theme-border-subtle pb-3">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 ${
                isDestructive ? 'bg-red-500/20 text-red-400' : 'theme-bg-surface-subtle theme-text-accent'
              }`}
            >
              {isDestructive ? <AlertCircle className="w-5 h-5" /> : <HelpCircle className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-black theme-text-app text-base leading-tight">{title}</h3>
            </div>
          </div>

          <button
            type="button"
            role="button"
            tabIndex={0}
            onClick={() => {
              console.log('[ConfirmModal] Close button clicked -> onCancel');
              onCancel();
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onCancel();
              }
            }}
            className="w-8 h-8 rounded-xl theme-bg-surface-subtle hover:bg-white/10 theme-text-secondary flex items-center justify-center cursor-pointer active:scale-95 transition-all select-none touch-manipulation"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs sm:text-sm theme-text-secondary leading-relaxed font-medium">
          {message}
        </p>

        <div className="flex items-center justify-end gap-2 pt-2 border-t theme-border-subtle">
          <button
            type="button"
            role="button"
            tabIndex={0}
            onClick={() => {
              console.log('[ConfirmModal] Cancel button clicked');
              onCancel();
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onCancel();
              }
            }}
            className="px-4 py-2.5 rounded-xl theme-text-secondary font-bold text-xs hover:bg-white/10 cursor-pointer active:scale-95 transition-all select-none touch-manipulation"
          >
            {cancelText}
          </button>
          <button
            type="button"
            role="button"
            tabIndex={0}
            onClick={() => {
              console.log('[ConfirmModal] Confirm button clicked');
              onConfirm();
            }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onConfirm();
              }
            }}
            className={`px-5 py-2.5 rounded-xl font-black text-xs shadow-2xs transition-all active:scale-95 cursor-pointer flex items-center gap-1.5 select-none touch-manipulation ${
              isDestructive
                ? 'bg-red-500 hover:bg-red-600 text-white'
                : 'theme-bg-primary text-white'
            }`}
          >
            <Check className="w-3.5 h-3.5" />
            <span>{confirmText}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

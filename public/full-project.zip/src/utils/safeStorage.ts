/**
 * safeStorage.ts
 * Infallible, crash-resilient storage wrapper.
 * Automatically falls back to an in-memory dictionary if localStorage throws
 * (e.g., iOS Safari Private Browsing, Android WebView quota limits, or disabled storage).
 */

const memoryStore = new Map<string, string>();

export const safeStorage = {
  getItem(key: string): string | null {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const value = window.localStorage.getItem(key);
        if (value !== null) {
          return value;
        }
      }
    } catch (err) {
      console.warn(`[safeStorage] Read failed for key "${key}", falling back to memory:`, err);
    }
    return memoryStore.get(key) ?? null;
  },

  setItem(key: string, value: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(key, value);
        // Also keep memory sync for fallback resilience
        memoryStore.set(key, value);
        return;
      }
    } catch (err) {
      console.warn(`[safeStorage] Write failed for key "${key}", saving in memory:`, err);
    }
    memoryStore.set(key, value);
  },

  removeItem(key: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem(key);
      }
    } catch (err) {
      console.warn(`[safeStorage] Remove failed for key "${key}":`, err);
    }
    memoryStore.delete(key);
  },

  clear(): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.clear();
      }
    } catch (err) {
      console.warn('[safeStorage] Clear failed:', err);
    }
    memoryStore.clear();
  },
};

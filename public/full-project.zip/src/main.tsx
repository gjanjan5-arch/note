import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { applyTheme, getThemeSettings } from './utils/theme';
import { ErrorBoundary } from './components/ErrorBoundary';

// Mobile WebView error logging & diagnostic monitoring
window.onerror = (message, source, lineno, colno, error) => {
  console.error('[TindahanNotes WebView Error]', {
    message,
    source,
    lineno,
    colno,
    error: error?.stack || error,
  });
  return false;
};

window.addEventListener('unhandledrejection', (event) => {
  console.warn('[TindahanNotes Handled Promise Rejection]', event.reason);
  event.preventDefault();
});

// Initialize and apply saved theme immediately
applyTheme(getThemeSettings());

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);


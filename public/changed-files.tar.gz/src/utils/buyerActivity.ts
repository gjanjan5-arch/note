import { safeStorage } from './safeStorage';

export interface BuyerDebtItem {
  id: string;
  date: string;
  description: string;
  amount: number;
  isPaid?: boolean;
}

export interface BuyerPaymentRecord {
  id: string;
  date: string;
  amount: number;
  note?: string;
}

export interface BuyerStoreUtang {
  storeId: string;
  storeName: string;
  ownerName?: string;
  lastUpdated: string;
  debts: BuyerDebtItem[];
  payments: BuyerPaymentRecord[];
}

export interface BuyerDigitalReceipt {
  id: string;
  storeName: string;
  timestamp: number;
  items: Array<{
    name: string;
    qty: number;
    price: number;
    variantLabel?: string;
    isCustomRequest?: boolean;
  }>;
  total: number;
  paymentMethod: 'CASH' | 'UTANG' | 'GCASH' | 'PARTIAL_CASH';
}

const BUYER_UTANGS_STORAGE_KEY = 'tindahan_buyer_utangs';
const BUYER_RECEIPTS_STORAGE_KEY = 'tindahan_buyer_receipts';

const INITIAL_BUYER_UTANGS: BuyerStoreUtang[] = [
  {
    storeId: 'store-aling-nena',
    storeName: "Aling Nena's Sari-Sari Store",
    ownerName: 'Aling Nena',
    lastUpdated: new Date(Date.now() - 86400000).toISOString(),
    debts: [
      {
        id: 'd-1',
        date: new Date(Date.now() - 86400000 * 3).toLocaleDateString('en-PH', { month: 'short', day: 'numeric' }),
        description: '1kg Dinorado Rice, 2 Century Tuna, Mantika',
        amount: 195,
      },
      {
        id: 'd-2',
        date: new Date(Date.now() - 86400000).toLocaleDateString('en-PH', { month: 'short', day: 'numeric' }),
        description: '3 Bear Brand sachet, 1 pack Kopiko Brown',
        amount: 85,
      },
    ],
    payments: [
      {
        id: 'p-1',
        date: new Date(Date.now() - 86400000 * 2).toLocaleDateString('en-PH', { month: 'short', day: 'numeric' }),
        amount: 100,
        note: 'Partial payment / Hulog',
      },
    ],
  },
  {
    storeId: 'store-nanay-tess',
    storeName: 'Nanay Tess Sari-Sari Store',
    ownerName: 'Nanay Tess',
    lastUpdated: new Date(Date.now() - 86400000 * 4).toISOString(),
    debts: [
      {
        id: 'd-3',
        date: new Date(Date.now() - 86400000 * 4).toLocaleDateString('en-PH', { month: 'short', day: 'numeric' }),
        description: 'Surf Cherry Blossom Twin Pack, Downy, Safeguard',
        amount: 120,
      },
    ],
    payments: [],
  },
];

const INITIAL_BUYER_RECEIPTS: BuyerDigitalReceipt[] = [
  {
    id: `REC-${Date.now() - 7200000}`,
    storeName: "Aling Nena's Sari-Sari Store",
    timestamp: Date.now() - 7200000,
    items: [
      { name: 'Purefoods Corned Beef 150g', qty: 2, price: 58 },
      { name: 'Gardenia Classic White Bread', qty: 1, price: 82 },
    ],
    total: 198,
    paymentMethod: 'CASH',
  },
  {
    id: `REC-${Date.now() - 86400000 * 2}`,
    storeName: 'Nanay Tess Sari-Sari Store',
    timestamp: Date.now() - 86400000 * 2,
    items: [
      { name: 'Mineral Water 500ml', qty: 3, price: 15 },
      { name: 'Piattos Cheese 85g', qty: 2, price: 38 },
      { name: 'Coke Mismo 290ml', qty: 2, price: 20 },
    ],
    total: 161,
    paymentMethod: 'GCASH',
  },
];

export function getBuyerUtangs(): BuyerStoreUtang[] {
  try {
    const raw = safeStorage.getItem(BUYER_UTANGS_STORAGE_KEY);
    if (!raw) {
      safeStorage.setItem(BUYER_UTANGS_STORAGE_KEY, JSON.stringify(INITIAL_BUYER_UTANGS));
      return INITIAL_BUYER_UTANGS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_BUYER_UTANGS;
  }
}

export function saveBuyerUtangs(utangs: BuyerStoreUtang[]): void {
  try {
    safeStorage.setItem(BUYER_UTANGS_STORAGE_KEY, JSON.stringify(utangs));
  } catch (err) {
    console.error('Failed to save buyer utangs:', err);
  }
}

export function getBuyerReceipts(): BuyerDigitalReceipt[] {
  try {
    const raw = safeStorage.getItem(BUYER_RECEIPTS_STORAGE_KEY);
    if (!raw) {
      safeStorage.setItem(BUYER_RECEIPTS_STORAGE_KEY, JSON.stringify(INITIAL_BUYER_RECEIPTS));
      return INITIAL_BUYER_RECEIPTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_BUYER_RECEIPTS;
  }
}

export function saveBuyerReceipt(receipt: BuyerDigitalReceipt): void {
  try {
    const existing = getBuyerReceipts();
    const updated = [receipt, ...existing.filter((r) => r.id !== receipt.id)];
    safeStorage.setItem(BUYER_RECEIPTS_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save buyer receipt:', err);
  }
}

export function calculateStoreNetUtang(store: BuyerStoreUtang): number {
  const totalDebts = store.debts.reduce((sum, d) => sum + (d.amount || 0), 0);
  const totalPayments = store.payments.reduce((sum, p) => sum + (p.amount || 0), 0);
  return Math.max(0, totalDebts - totalPayments);
}

export function calculateTotalBuyerUtang(stores: BuyerStoreUtang[]): number {
  return stores.reduce((acc, store) => acc + calculateStoreNetUtang(store), 0);
}

import { useState, useEffect, useMemo, useRef } from 'react';
import type { InventoryItem, Customer, Transaction, CatalogPayload } from '../types';
import type {
  GlobalSearchResultItem,
  SearchCategory,
  GlobalSearchCounts,
  ProductSearchResult,
  UtangSearchResult,
  ReceiptSearchResult,
  CustomerSearchResult,
  SavedStoreSearchResult,
} from '../types/search';
import { formatPeso, formatDateTime } from '../utils/formatters';
import { translate, type LanguageCode } from '../utils/i18n';

interface UseGlobalSearchOptions {
  query: string;
  category: SearchCategory;
  inventory: InventoryItem[];
  customers: Customer[];
  transactions: Transaction[];
  savedStores?: CatalogPayload[]; // Added saved stores
  lang: LanguageCode;
  debounceMs?: number;
  maxResultsPerCategory?: number;
}

export function useGlobalSearch({
  query,
  category,
  inventory,
  customers,
  transactions,
  savedStores = [],
  lang,
  debounceMs = 200,
  maxResultsPerCategory = 25,
}: UseGlobalSearchOptions) {
  const [debouncedQuery, setDebouncedQuery] = useState(query);
  const timerRef = useRef<number | null>(null);

  // 200ms debounce to save CPU/battery and avoid redundant search allocations
  useEffect(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    timerRef.current = window.setTimeout(() => {
      setDebouncedQuery(query);
    }, debounceMs);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [query, debounceMs]);

  const results = useMemo(() => {
    const q = debouncedQuery.trim().toLowerCase();
    const isSearching = q.length > 0;

    const matchedProducts: ProductSearchResult[] = [];
    const matchedUtang: UtangSearchResult[] = [];
    const matchedReceipts: ReceiptSearchResult[] = [];
    const matchedCustomers: CustomerSearchResult[] = [];
    const matchedSavedStores: SavedStoreSearchResult[] = [];

    // 1. PRODUCTS (Inventory)
    if (category === 'ALL' || category === 'PRODUCTS') {
      let pCount = 0;
      for (let i = 0; i < inventory.length; i++) {
        if (pCount >= maxResultsPerCategory) break;
        const item = inventory[i];
        if (!item) continue;

        if (!isSearching) {
          // Show recent / top items when query is empty
          matchedProducts.push({
            id: `prod-${item.id || i}`,
            type: 'PRODUCT',
            title: item.name,
            subtitle: `${item.category || translate(lang, 'general') || 'General'} • ${formatPeso(item.unitPrice || 0)}`,
            badgeText: `${item.stock ?? 0} ${item.variants && item.variants.length > 0 ? ((item.stock ?? 0) === 1 ? 'pack' : 'packs') : (item.unit || translate(lang, 'unit_pcs') || 'pcs')}`,
            badgeVariant: (item.stock ?? 0) <= (item.minStockAlert || 5) ? 'warning' : 'neutral',
            meta: item.sku ? `SKU: ${item.sku}` : undefined,
            item,
          });
          pCount++;
          continue;
        }

        const nameMatch = item.name && item.name.toLowerCase().includes(q);
        const catMatch = item.category && item.category.toLowerCase().includes(q);
        const skuMatch = item.sku && item.sku.toLowerCase().includes(q);
        const priceMatch = (item.unitPrice || 0).toString().includes(q);

        // Also check variant barcodes/labels if any
        let variantMatch = false;
        if (item.variants && item.variants.length > 0) {
          for (let v = 0; v < item.variants.length; v++) {
            const variant = item.variants[v];
            if (
              (variant.label && variant.label.toLowerCase().includes(q)) ||
              (variant.barcode && variant.barcode.toLowerCase().includes(q))
            ) {
              variantMatch = true;
              break;
            }
          }
        }

        if (nameMatch || catMatch || skuMatch || priceMatch || variantMatch) {
          matchedProducts.push({
            id: `prod-${item.id || i}`,
            type: 'PRODUCT',
            title: item.name,
            subtitle: `${item.category || translate(lang, 'general') || 'General'} • ${formatPeso(item.unitPrice || 0)}`,
            badgeText: `${item.stock ?? 0} ${item.variants && item.variants.length > 0 ? ((item.stock ?? 0) === 1 ? 'pack' : 'packs') : (item.unit || translate(lang, 'unit_pcs') || 'pcs')}`,
            badgeVariant: (item.stock ?? 0) <= (item.minStockAlert || 5) ? 'warning' : 'neutral',
            meta: item.sku ? `SKU: ${item.sku}` : undefined,
            item,
          });
          pCount++;
        }
      }
    }

    // 2. UTANG / DEBT LEDGERS (Customers with active balance or searching in debts)
    if (category === 'ALL' || category === 'UTANG') {
      let uCount = 0;
      for (let i = 0; i < customers.length; i++) {
        if (uCount >= maxResultsPerCategory) break;
        const cust = customers[i];
        if (!cust) continue;

        const hasBalance = (cust.currentBalance || 0) > 0;
        
        if (!isSearching) {
          if (hasBalance) {
            matchedUtang.push({
              id: `utang-${cust.id || i}`,
              type: 'UTANG',
              title: cust.name,
              subtitle: cust.phone || translate(lang, 'no_phone') || 'No contact',
              badgeText: formatPeso(cust.currentBalance),
              badgeVariant: 'warning',
              meta: cust.lastTransactionAt ? formatDateTime(cust.lastTransactionAt) : undefined,
              customer: cust,
            });
            uCount++;
          }
          continue;
        }

        const nameMatch = cust.name && cust.name.toLowerCase().includes(q);
        const phoneMatch = cust.phone && cust.phone.toLowerCase().includes(q);
        const notesMatch = cust.notes && cust.notes.toLowerCase().includes(q);
        const balanceMatch = (cust.currentBalance || 0).toString().includes(q);

        if (nameMatch || phoneMatch || notesMatch || balanceMatch) {
          matchedUtang.push({
            id: `utang-${cust.id || i}`,
            type: 'UTANG',
            title: cust.name,
            subtitle: cust.phone || translate(lang, 'no_phone') || 'No contact',
            badgeText: formatPeso(cust.currentBalance || 0),
            badgeVariant: hasBalance ? 'warning' : 'success',
            meta: cust.lastTransactionAt ? formatDateTime(cust.lastTransactionAt) : undefined,
            customer: cust,
          });
          uCount++;
        }
      }
    }

    // 3. TRANSACTIONS & RECEIPTS
    if (category === 'ALL' || category === 'RECEIPTS') {
      let rCount = 0;
      for (let i = 0; i < transactions.length; i++) {
        if (rCount >= maxResultsPerCategory) break;
        const tx = transactions[i];
        if (!tx) continue;

        if (!isSearching) {
          // Show recent transactions
          const itemSummary =
            tx.items && tx.items.length > 0
              ? tx.items.map((it) => `${it.itemName} (${it.quantity})`).join(', ')
              : tx.rawNote || translate(lang, 'transaction') || 'Transaction';
          matchedReceipts.push({
            id: `tx-${tx.id || i}`,
            type: 'RECEIPT',
            title: tx.customerName || (tx.type === 'SALE' ? (translate(lang, 'cash_sale') || 'Cash Sale') : tx.type),
            subtitle: itemSummary,
            badgeText: formatPeso(tx.totalAmount || 0),
            badgeVariant: tx.type === 'PAUTANG_RECORD' ? 'warning' : 'primary',
            meta: tx.timestamp ? formatDateTime(tx.timestamp) : tx.dateStr,
            transaction: tx,
          });
          rCount++;
          continue;
        }

        const idMatch = tx.id ? tx.id.toString().includes(q) : false;
        const custMatch = tx.customerName && tx.customerName.toLowerCase().includes(q);
        const typeMatch = tx.type && tx.type.toLowerCase().includes(q);
        const noteMatch = tx.rawNote && tx.rawNote.toLowerCase().includes(q);
        const handledMatch = tx.handledBy && tx.handledBy.toLowerCase().includes(q);
        const amountMatch = (tx.totalAmount || 0).toString().includes(q);
        const dateMatch = tx.dateStr && tx.dateStr.includes(q);

        let itemMatch = false;
        if (tx.items && tx.items.length > 0) {
          for (let it = 0; it < tx.items.length; it++) {
            if (tx.items[it].itemName && tx.items[it].itemName.toLowerCase().includes(q)) {
              itemMatch = true;
              break;
            }
          }
        }

        if (idMatch || custMatch || typeMatch || noteMatch || handledMatch || amountMatch || dateMatch || itemMatch) {
          const itemSummary =
            tx.items && tx.items.length > 0
              ? tx.items.map((it) => `${it.itemName} (${it.quantity})`).join(', ')
              : tx.rawNote || translate(lang, 'transaction') || 'Transaction';
          matchedReceipts.push({
            id: `tx-${tx.id || i}`,
            type: 'RECEIPT',
            title: tx.customerName || (tx.type === 'SALE' ? (translate(lang, 'cash_sale') || 'Cash Sale') : tx.type),
            subtitle: itemSummary,
            badgeText: formatPeso(tx.totalAmount || 0),
            badgeVariant: tx.type === 'PAUTANG_RECORD' ? 'warning' : 'primary',
            meta: tx.timestamp ? formatDateTime(tx.timestamp) : tx.dateStr,
            transaction: tx,
          });
          rCount++;
        }
      }
    }

    // 4. CUSTOMERS
    if (category === 'ALL' || category === 'CUSTOMERS') {
      let cCount = 0;
      for (let i = 0; i < customers.length; i++) {
        if (cCount >= maxResultsPerCategory) break;
        const cust = customers[i];
        if (!cust) continue;

        if (!isSearching) {
          matchedCustomers.push({
            id: `cust-${cust.id || i}`,
            type: 'CUSTOMER',
            title: cust.name,
            subtitle: cust.phone || translate(lang, 'no_phone') || 'No contact',
            badgeText: cust.currentBalance > 0 ? `${formatPeso(cust.currentBalance)} utang` : (translate(lang, 'no_balance') || 'Walang utang'),
            badgeVariant: cust.currentBalance > 0 ? 'warning' : 'neutral',
            customer: cust,
          });
          cCount++;
          continue;
        }

        const nameMatch = cust.name && cust.name.toLowerCase().includes(q);
        const phoneMatch = cust.phone && cust.phone.toLowerCase().includes(q);
        const nickMatch = cust.nickname && cust.nickname.toLowerCase().includes(q);
        const noteMatch = cust.notes && cust.notes.toLowerCase().includes(q);

        if (nameMatch || phoneMatch || nickMatch || noteMatch) {
          matchedCustomers.push({
            id: `cust-${cust.id || i}`,
            type: 'CUSTOMER',
            title: cust.name,
            subtitle: cust.phone || translate(lang, 'no_phone') || 'No contact',
            badgeText: cust.currentBalance > 0 ? `${formatPeso(cust.currentBalance)} utang` : (translate(lang, 'no_balance') || 'Walang utang'),
            badgeVariant: cust.currentBalance > 0 ? 'warning' : 'neutral',
            customer: cust,
          });
          cCount++;
        }
      }
    }

    // 5. SAVED STORES
    if (category === 'ALL' || category === 'SAVED_STORES') {
      let sCount = 0;
      for (let i = 0; i < savedStores.length; i++) {
        if (sCount >= maxResultsPerCategory) break;
        const store = savedStores[i];
        if (!store) continue;

        if (!isSearching) {
          matchedSavedStores.push({
            id: `store-${store.storeName}-${i}`,
            type: 'SAVED_STORE',
            title: store.storeName,
            subtitle: store.ownerName || 'Suki Store',
            badgeText: `${store.items?.length || 0} items`,
            badgeVariant: 'primary',
            meta: store.contactNumber || store.storeAddress || undefined,
            store: store,
          });
          sCount++;
          continue;
        }

        const nameMatch = store.storeName && store.storeName.toLowerCase().includes(q);
        const ownerMatch = store.ownerName && store.ownerName.toLowerCase().includes(q);
        const contactMatch = store.contactNumber && store.contactNumber.toLowerCase().includes(q);
        const addressMatch = store.storeAddress && store.storeAddress.toLowerCase().includes(q);

        if (nameMatch || ownerMatch || contactMatch || addressMatch) {
          matchedSavedStores.push({
            id: `store-${store.storeName}-${i}`,
            type: 'SAVED_STORE',
            title: store.storeName,
            subtitle: store.ownerName || 'Suki Store',
            badgeText: `${store.items?.length || 0} items`,
            badgeVariant: 'primary',
            meta: store.contactNumber || store.storeAddress || undefined,
            store: store,
          });
          sCount++;
        }
      }
    }

    const counts: GlobalSearchCounts = {
      all: matchedProducts.length + matchedUtang.length + matchedReceipts.length + matchedCustomers.length + matchedSavedStores.length,
      products: matchedProducts.length,
      utang: matchedUtang.length,
      receipts: matchedReceipts.length,
      customers: matchedCustomers.length,
      savedStores: matchedSavedStores.length,
    };

    let flatResults: GlobalSearchResultItem[] = [];
    if (category === 'ALL') {
      flatResults = [
        ...matchedProducts,
        ...matchedUtang,
        ...matchedReceipts,
        ...matchedCustomers,
        ...matchedSavedStores,
      ];
    } else if (category === 'PRODUCTS') {
      flatResults = matchedProducts;
    } else if (category === 'UTANG') {
      flatResults = matchedUtang;
    } else if (category === 'RECEIPTS') {
      flatResults = matchedReceipts;
    } else if (category === 'CUSTOMERS') {
      flatResults = matchedCustomers;
    } else if (category === 'SAVED_STORES') {
      flatResults = matchedSavedStores;
    }

    return {
      products: matchedProducts,
      utang: matchedUtang,
      receipts: matchedReceipts,
      customers: matchedCustomers,
      savedStores: matchedSavedStores,
      flatResults,
      counts,
      isSearching,
    };
  }, [debouncedQuery, category, inventory, customers, transactions, savedStores, lang, maxResultsPerCategory]);

  return results;
}

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Search,
  X,
  Package,
  CreditCard,
  Receipt,
  User,
  ArrowRight,
  Sparkles,
  Layers,
  Phone,
  Clock,
  ChevronRight,
  Plus,
  ShoppingCart,
} from 'lucide-react';
import type { InventoryItem, Customer, Transaction, CatalogPayload } from '../types';
import type { GlobalSearchResultItem, SearchCategory } from '../types/search';
import { useGlobalSearch } from '../hooks/useGlobalSearch';
import { translate, type LanguageCode } from '../utils/i18n';
import { formatPeso } from '../utils/formatters';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory: InventoryItem[];
  customers: Customer[];
  transactions: Transaction[];
  savedStores?: CatalogPayload[];
  lang: LanguageCode;
  onSelectProduct?: (item: InventoryItem) => void;
  onSelectCustomer?: (customer: Customer) => void;
  onSelectUtang?: (customer: Customer) => void;
  onSelectReceipt?: (transaction: Transaction) => void;
  onSelectSavedStore?: (store: CatalogPayload) => void;
  onOpenAddProduct?: () => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  inventory,
  customers,
  transactions,
  savedStores = [],
  lang,
  onSelectProduct,
  onSelectCustomer,
  onSelectUtang,
  onSelectReceipt,
  onSelectSavedStore,
  onOpenAddProduct,
}) => {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<SearchCategory>('ALL');
  const inputRef = useRef<HTMLInputElement>(null);

  const {
    products,
    utang,
    receipts,
    customers: matchedCustomers,
    savedStores: matchedSavedStores,
    counts,
    isSearching,
  } = useGlobalSearch({
    query,
    category,
    inventory,
    customers,
    transactions,
    savedStores,
    lang,
    debounceMs: 200,
  });

  // Focus search input on open
  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setCategory('ALL');
      const timer = setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  // Handle keyboard navigation within modal
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const renderCategoryPill = (
    cat: SearchCategory,
    label: string,
    count: number,
    Icon: React.ElementType
  ) => {
    const isActive = category === cat;
    return (
      <button
        type="button"
        key={cat}
        onClick={() => setCategory(cat)}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-opacity duration-150 flex items-center gap-1.5 shrink-0 select-none cursor-pointer border ${
          isActive
            ? 'theme-bg-primary text-white border-white/20 shadow-xs'
            : 'theme-bg-surface-subtle theme-text-secondary hover:theme-text-app border-transparent hover:border-white/10'
        }`}
      >
        <Icon className="w-3.5 h-3.5 shrink-0" />
        <span>{label}</span>
        <span
          className={`text-[10px] px-1.5 py-0.5 rounded-full ${
            isActive
              ? 'bg-white/20 text-white'
              : 'theme-bg-surface theme-text-secondary'
          }`}
        >
          {count}
        </span>
      </button>
    );
  };

  const isTl = lang === 'tl';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="global-search-title"
      className="fixed inset-0 z-50 flex items-start justify-center p-3 sm:p-4 pt-12 sm:pt-16 bg-slate-950/60 backdrop-blur-xs transition-opacity duration-150 animate-in fade-in-0 duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl theme-bg-card theme-text-app rounded-3xl shadow-2xl border theme-border overflow-hidden flex flex-col max-h-[85vh] transition-opacity duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Header Bar */}
        <div className="p-3 sm:p-4 border-b theme-border flex items-center gap-2 sm:gap-3 bg-transparent">
          <div className="p-2 rounded-xl theme-bg-surface-subtle theme-text-secondary shrink-0">
            <Search className="w-5 h-5 stroke-[2.2]" />
          </div>

          <input
            ref={inputRef}
            id="global-search-input"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={
              isTl
                ? 'Maghanap ng paninda, pautang, resibo, o kustomer...'
                : 'Search products, debts, receipts, or customers...'
            }
            className="w-full bg-transparent border-none text-sm sm:text-base font-semibold theme-text-app placeholder:theme-text-secondary focus:outline-none focus:ring-0"
            autoComplete="off"
            spellCheck="false"
          />

          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                inputRef.current?.focus();
              }}
              className="p-1.5 rounded-xl hover:theme-bg-surface-subtle theme-text-secondary transition-opacity cursor-pointer shrink-0"
              title="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            aria-label="Close search"
            className="p-2 rounded-xl theme-bg-surface-subtle hover:theme-bg-surface theme-text-secondary hover:theme-text-app transition-opacity cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Filter Category Filter Tabs */}
        <div className="px-3 sm:px-4 py-2 border-b theme-border flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {renderCategoryPill(
            'ALL',
            isTl ? 'Lahat' : 'All',
            counts.all,
            Layers
          )}
          {renderCategoryPill(
            'PRODUCTS',
            isTl ? 'Mga Paninda' : 'Products',
            counts.products,
            Package
          )}
          {renderCategoryPill(
            'UTANG',
            isTl ? 'Talaan ng Utang' : 'Utang Ledgers',
            counts.utang,
            CreditCard
          )}
          {renderCategoryPill(
            'RECEIPTS',
            isTl ? 'Mga Resibo' : 'Receipts',
            counts.receipts,
            Receipt
          )}
          {renderCategoryPill(
            'CUSTOMERS',
            isTl ? 'Mga Kustomer' : 'Customers',
            counts.customers,
            User
          )}
          {renderCategoryPill(
            'SAVED_STORES',
            isTl ? 'Suki Stores' : 'Saved Stores',
            counts.savedStores,
            ShoppingCart
          )}
        </div>

        {/* Search Results Area */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4 divide-y theme-divide">
          {counts.all === 0 && isSearching && (
            <div className="py-12 text-center flex flex-col items-center justify-center">
              <div className="w-12 h-12 rounded-2xl theme-bg-surface-subtle flex items-center justify-center theme-text-secondary mb-3">
                <Search className="w-6 h-6 opacity-60" />
              </div>
              <p className="text-sm font-bold theme-text-app">
                {isTl ? 'Walang nahanap na resulta' : 'No matching results found'}
              </p>
              <p className="text-xs theme-text-secondary mt-1 max-w-xs">
                {isTl
                  ? `Walang tumutugma sa "${query}". Subukang maghanap gamit ang ibang pangalan o barcode.`
                  : `Nothing matched "${query}". Try searching with a different name or barcode.`}
              </p>
            </div>
          )}

          {/* 1. Products & Inventory Section */}
          {(category === 'ALL' || category === 'PRODUCTS') && products.length > 0 && (
            <div className="pt-2 first:pt-0">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider theme-text-secondary">
                  <Package className="w-3.5 h-3.5" />
                  <span>{isTl ? 'Mga Paninda' : 'Products & Inventory'}</span>
                  <span className="text-[11px] font-bold opacity-75">({products.length})</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {products.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      onSelectProduct?.(p.item);
                      onClose();
                    }}
                    className="w-full text-left p-2.5 rounded-2xl theme-bg-surface-subtle hover:theme-bg-surface border theme-border flex items-center justify-between gap-2.5 transition-opacity duration-150 cursor-pointer select-none group"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="text-xs sm:text-sm font-bold theme-text-app truncate group-hover:theme-text-primary transition-colors">
                        {p.title}
                      </div>
                      <div className="text-[11px] theme-text-secondary truncate mt-0.5">
                        {p.subtitle}
                      </div>
                      {p.meta && (
                        <div className="text-[10px] theme-text-secondary opacity-80 mt-0.5 truncate font-mono">
                          {p.meta}
                        </div>
                      )}
                    </div>

                    <div className="flex flex-col items-end shrink-0">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-lg ${
                          p.badgeVariant === 'warning'
                            ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/20'
                            : 'theme-bg-surface theme-text-app border theme-border'
                        }`}
                      >
                        {p.badgeText}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 2. Utang / Debt Ledgers Section */}
          {(category === 'ALL' || category === 'UTANG') && utang.length > 0 && (
            <div className="pt-3 first:pt-0">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider theme-text-secondary">
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>{isTl ? 'Talaan ng Utang' : 'Utang Ledgers'}</span>
                  <span className="text-[11px] font-bold opacity-75">({utang.length})</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {utang.map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => {
                      onSelectUtang?.(u.customer);
                      onClose();
                    }}
                    className="w-full text-left p-2.5 rounded-2xl theme-bg-surface-subtle hover:theme-bg-surface border theme-border flex items-center justify-between gap-2.5 transition-opacity duration-150 cursor-pointer select-none group"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="text-xs sm:text-sm font-bold theme-text-app truncate group-hover:theme-text-primary transition-colors">
                        {u.title}
                      </div>
                      <div className="text-[11px] theme-text-secondary truncate mt-0.5 flex items-center gap-1">
                        {u.subtitle !== 'No contact' && <Phone className="w-3 h-3 shrink-0 opacity-70" />}
                        <span>{u.subtitle}</span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end shrink-0">
                      <span className="text-xs font-black text-rose-600 dark:text-rose-400">
                        {u.badgeText}
                      </span>
                      {u.meta && (
                        <span className="text-[9px] theme-text-secondary opacity-75 mt-0.5">
                          {u.meta}
                        </span>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 3. Transactions & Receipts Section */}
          {(category === 'ALL' || category === 'RECEIPTS') && receipts.length > 0 && (
            <div className="pt-3 first:pt-0">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider theme-text-secondary">
                  <Receipt className="w-3.5 h-3.5" />
                  <span>{isTl ? 'Mga Resibo at Benta' : 'Receipts & Transactions'}</span>
                  <span className="text-[11px] font-bold opacity-75">({receipts.length})</span>
                </div>
              </div>

              <div className="space-y-1.5">
                {receipts.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => {
                      onSelectReceipt?.(r.transaction);
                      onClose();
                    }}
                    className="w-full text-left p-2.5 rounded-2xl theme-bg-surface-subtle hover:theme-bg-surface border theme-border flex items-center justify-between gap-3 transition-opacity duration-150 cursor-pointer select-none group"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs sm:text-sm font-bold theme-text-app truncate group-hover:theme-text-primary transition-colors">
                          {r.title}
                        </span>
                        {r.meta && (
                          <span className="text-[10px] theme-text-secondary shrink-0 font-medium">
                            • {r.meta}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] theme-text-secondary truncate mt-0.5">
                        {r.subtitle}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="text-xs sm:text-sm font-black theme-text-app">
                        {r.badgeText}
                      </span>
                      <ChevronRight className="w-4 h-4 theme-text-secondary opacity-50 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 4. Customers Section */}
          {(category === 'ALL' || category === 'CUSTOMERS') && matchedCustomers.length > 0 && (
            <div className="pt-3 first:pt-0">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider theme-text-secondary">
                  <User className="w-3.5 h-3.5" />
                  <span>{isTl ? 'Mga Kustomer' : 'Customers'}</span>
                  <span className="text-[11px] font-bold opacity-75">({matchedCustomers.length})</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {matchedCustomers.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => {
                      onSelectCustomer?.(c.customer);
                      onClose();
                    }}
                    className="w-full text-left p-2.5 rounded-2xl theme-bg-surface-subtle hover:theme-bg-surface border theme-border flex items-center justify-between gap-2.5 transition-opacity duration-150 cursor-pointer select-none group"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="text-xs sm:text-sm font-bold theme-text-app truncate group-hover:theme-text-primary transition-colors">
                        {c.title}
                      </div>
                      <div className="text-[11px] theme-text-secondary truncate mt-0.5 flex items-center gap-1">
                        {c.subtitle !== 'No contact' && <Phone className="w-3 h-3 shrink-0 opacity-70" />}
                        <span>{c.subtitle}</span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end shrink-0">
                      <span className="text-[10px] font-bold theme-text-secondary">
                        {c.badgeText}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 5. Saved Stores Section */}
          {(category === 'ALL' || category === 'SAVED_STORES') && matchedSavedStores.length > 0 && (
            <div className="pt-3 first:pt-0">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider theme-text-secondary">
                  <ShoppingCart className="w-3.5 h-3.5" />
                  <span>{isTl ? 'Suki Stores' : 'Saved Stores'}</span>
                  <span className="text-[11px] font-bold opacity-75">({matchedSavedStores.length})</span>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {matchedSavedStores.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => onSelectSavedStore && onSelectSavedStore(s.store)}
                    className="flex items-center gap-3 p-3 rounded-2xl border theme-border theme-bg-card hover:theme-bg-surface-subtle transition-all text-left w-full group"
                  >
                    <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500 shrink-0">
                      <ShoppingCart className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs sm:text-sm font-bold theme-text-app truncate group-hover:theme-text-primary transition-colors">
                        {s.title}
                      </div>
                      <div className="text-[11px] theme-text-secondary truncate mt-0.5 flex items-center gap-1">
                        <span>{s.subtitle}</span>
                        {s.meta && <span className="opacity-70 truncate">• {s.meta}</span>}
                      </div>
                    </div>
                    <div className="flex flex-col items-end shrink-0">
                      <span className="text-[10px] font-bold theme-text-secondary">
                        {s.badgeText}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Footer Quick Shortcut Tip */}
        <div className="px-3 sm:px-4 py-2.5 border-t theme-border theme-bg-surface-subtle flex items-center justify-between text-[11px] theme-text-secondary">
          <div className="flex items-center gap-2">
            <span className="font-bold">Shortcut:</span>
            <kbd className="px-1.5 py-0.5 rounded-md theme-bg-card border theme-border font-mono text-[10px] font-semibold">
              Ctrl+K
            </kbd>
            <span>/</span>
            <kbd className="px-1.5 py-0.5 rounded-md theme-bg-card border theme-border font-mono text-[10px] font-semibold">
              ⌘K
            </kbd>
          </div>

          <div className="text-[11px] font-medium">
            {counts.all} {isTl ? 'kabuuang resulta' : 'total results'}
          </div>
        </div>
      </div>
    </div>
  );
};

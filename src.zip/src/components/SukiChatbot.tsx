import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, RefreshCw, Cpu, Zap, BatteryCharging, ChevronDown, Check, Sparkles, Leaf } from 'lucide-react';
import type { ChatMessage } from '../types';
import { translate, type LanguageCode } from '../utils/i18n';
import { usePerformance, type PerformanceMode } from '../context/PerformanceContext';

interface SukiChatbotProps {
  isOnline: boolean;
  lang: LanguageCode;
}

const PRESET_QUESTIONS_TL = [
  'Paano maiwasan ang malaking pautang nang hindi nakakasira sa suki?',
  'Magkano ang tamang patong / tubo sa Pancit Canton at Softdrinks?',
  'Anong paninda ang mabilis mabenta ngayong tag-init?',
  'Paano ma-compute nang tama ang puhunan at daily profit?',
];

const PRESET_QUESTIONS_EN = [
  'How to prevent excessive store credit without alienating regular customers?',
  'What is the standard profit margin for instant noodles and beverages?',
  'Which products sell fastest during summer season?',
  'How do I calculate cost price and daily profit accurately?',
];

export const SukiChatbot: React.FC<SukiChatbotProps> = ({ isOnline, lang }) => {
  const initialGreeting = lang === 'tl'
    ? 'Magandang araw Boss! Ako si Suki, ang iyong AI Business Advisor para sa Tinda. Ano ang maitutulong ko sa iyong sari-sari store ngayon? Pwede mo akong tanungin tungkol sa pautang, patong sa presyo, o paninda tips!'
    : 'Hello Boss! I am Suki, your AI Store Advisor. How can I assist your sari-sari store business today? Feel free to ask about credit terms, pricing markups, or inventory management!';

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'model',
      content: initialGreeting,
      timestamp: Date.now(),
    },
  ]);

  const presetQuestions = lang === 'tl' ? PRESET_QUESTIONS_TL : PRESET_QUESTIONS_EN;

  const { mode: perfMode, resolvedMode, isEco, setMode: setPerfMode } = usePerformance();
  const [input, setInput] = useState('');
  const [selectedModel, setSelectedModel] = useState<string>(() => (isEco ? 'gemini-3.1-flash-lite' : 'gemini-3.7-flash'));
  const [isModelDropdownOpen, setIsModelDropdownOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const modelDropdownRef = useRef<HTMLDivElement>(null);

  // Auto-adapt model when switching to Eco mode unless already using a fast model
  useEffect(() => {
    if (isEco && selectedModel === 'gemini-3.1-pro-preview') {
      setSelectedModel('gemini-3.1-flash-lite');
    }
  }, [isEco]);

  // Click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modelDropdownRef.current && !modelDropdownRef.current.contains(event.target as Node)) {
        setIsModelDropdownOpen(false);
      }
    };
    if (isModelDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isModelDropdownOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (textToSend?: string) => {
    const messageText = textToSend || input;
    if (!messageText.trim() || isLoading) return;

    if (!isOnline) {
      const offlineMsg: ChatMessage = {
        id: Date.now().toString(),
        role: 'model',
        content: `⚠️ ${translate(lang, 'ai_requires_internet')}`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [
        ...prev,
        { id: (Date.now() - 1).toString(), role: 'user', content: messageText, timestamp: Date.now() },
        offlineMsg,
      ]);
      setInput('');
      return;
    }

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: messageText,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsLoading(true);

    try {
      const historyPayload = messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          history: historyPayload,
          message: messageText,
          model: selectedModel,
        }),
      });

      if (res.ok) {
        const data = await res.json().catch(() => null);
        const fallbackText = lang === 'tl'
          ? 'Pasensya na boss, subukang magtanong muli.'
          : 'Sorry, please try asking your question again.';
        const modelMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'model',
          content: data?.text || fallbackText,
          timestamp: Date.now(),
          modelUsed: data?.modelUsed || selectedModel,
        };
        setMessages((prev) => [...prev, modelMsg]);
      } else {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to fetch AI response');
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      const isHighDemand = err?.message?.includes('high demand') || err?.message?.includes('503');
      const errorContent = isHighDemand
        ? (lang === 'tl'
            ? 'Medyo mataas ang demand ngayon sa AI server. Paki-pindot muli ang tanong para subukan agad.'
            : 'The AI server is experiencing high demand right now. Please tap the question again to retry.')
        : (lang === 'tl'
            ? 'Nagka-error sa pagsagot ni Suki. Paki-check ang iyong internet connection at subukang muli.'
            : 'Error getting response. Please check your internet connection and try again.');

      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: errorContent,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    }

    setIsLoading(false);
  };

  return (
    <div id="suki-ai-container" className="theme-card rounded-3xl shadow-2xs border h-[580px] sm:h-[650px] flex flex-col overflow-hidden transition-colors duration-200">
      {/* Top Header */}
      <div 
        id="suki-ai-header" 
        className="theme-bg-header text-white p-3 sm:p-4 flex flex-wrap sm:flex-nowrap items-center justify-between gap-2.5 border-b theme-border-subtle"
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="relative shrink-0">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl theme-bg-primary text-white flex items-center justify-center font-bold shadow-2xs border border-white/20">
              <Bot className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            {/* Live Status indicator dot */}
            <span 
              className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-slate-900 ${
                isOnline 
                  ? (isEco ? 'bg-green-400' : 'bg-emerald-400 animate-pulse') 
                  : 'bg-amber-400'
              }`} 
              title={isOnline ? (isEco ? 'Online (Eco Saver)' : 'Online (Active)') : 'Offline'}
            />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3 className="font-black text-xs sm:text-sm text-white tracking-tight leading-tight truncate">
                Suki AI Store Advisor
              </h3>
              <span className={`text-[9px] sm:text-[10px] px-1.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                isEco 
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                  : 'bg-teal-500/20 text-teal-200 border border-teal-500/30'
              }`}>
                {isOnline ? (lang === 'tl' ? 'Handa' : 'Ready') : (lang === 'tl' ? 'Offline' : 'Offline')}
              </span>
            </div>
            <p className="text-[10px] sm:text-xs theme-text-accent font-medium leading-tight truncate mt-0.5">
              {lang === 'tl' ? 'Madiskarteng Kaagapay sa Presyo at Kita' : 'Pricing, Margin & Inventory Advisor'}
            </p>
          </div>
        </div>

        {/* Action Controls: Performance Badge + Sleek Model Selector */}
        <div className="flex items-center gap-1.5 shrink-0 ml-auto sm:ml-0" ref={modelDropdownRef}>
          {/* Adaptable Performance Mode Toggle Pill */}
          <button
            type="button"
            onClick={() => {
              const nextMode: PerformanceMode = perfMode === 'AUTO' ? 'ECO' : perfMode === 'ECO' ? 'FULL' : 'AUTO';
              setPerfMode(nextMode);
            }}
            className={`flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-xl border transition-all cursor-pointer select-none active:scale-95 ${
              isEco
                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/30'
                : 'bg-amber-500/20 border-amber-500/40 text-amber-300 hover:bg-amber-500/30'
            }`}
            title={
              lang === 'tl'
                ? `Performance: ${perfMode} (${resolvedMode}). I-click para lumipat ng mode.`
                : `Performance: ${perfMode} (${resolvedMode}). Click to toggle mode.`
            }
          >
            {isEco ? (
              <>
                <Leaf className="w-3 h-3 text-emerald-400 shrink-0" />
                <span>Eco</span>
              </>
            ) : (
              <>
                <Zap className="w-3 h-3 text-amber-400 shrink-0" />
                <span>Full</span>
              </>
            )}
          </button>

          {/* Sleek Model Selector Popover */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsModelDropdownOpen((prev) => !prev)}
              className="flex items-center gap-1 text-[10px] sm:text-[11px] font-bold bg-white/10 hover:bg-white/15 text-white border border-white/20 rounded-xl px-2.5 py-1 transition-all cursor-pointer select-none active:scale-95 shadow-2xs"
            >
              <Cpu className="w-3 h-3 theme-text-accent shrink-0" />
              <span>
                {selectedModel === 'gemini-3.1-flash-lite'
                  ? 'Flash-Lite'
                  : selectedModel === 'gemini-3.1-pro-preview'
                  ? 'Pro 3.1'
                  : 'Flash 3.7'}
              </span>
              <ChevronDown className={`w-3 h-3 transition-transform duration-150 ${isModelDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {/* Native select element for fallback & accessibility */}
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="sr-only"
              aria-label="AI Model"
            >
              <option value="gemini-3.7-flash">Gemini 3.7 Flash (Advisor)</option>
              <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash-Lite (Fast)</option>
              <option value="gemini-3.1-pro-preview">Gemini 3.1 Pro (Deep Analysis)</option>
            </select>

            {/* Custom Dropdown Menu */}
            {isModelDropdownOpen && (
              <div className="absolute right-0 mt-1.5 w-48 sm:w-52 rounded-2xl theme-card border theme-border shadow-2xl p-1.5 z-50 animate-in fade-in zoom-in-95 duration-100 text-left">
                <div className="px-2 py-1 text-[9px] font-black uppercase tracking-wider theme-text-secondary border-b theme-border-subtle mb-1">
                  {lang === 'tl' ? 'Pumili ng AI Model' : 'Select AI Model'}
                </div>

                {/* Option 1: Flash 3.7 */}
                <button
                  type="button"
                  onClick={() => {
                    setSelectedModel('gemini-3.7-flash');
                    setIsModelDropdownOpen(false);
                  }}
                  className={`w-full text-left px-2 py-1.5 rounded-xl transition-all flex items-center justify-between text-[11px] font-semibold cursor-pointer ${
                    selectedModel === 'gemini-3.7-flash'
                      ? 'theme-bg-primary text-white font-bold shadow-2xs'
                      : 'theme-text-app hover:theme-bg-surface-subtle'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-amber-300" />
                      <span>Gemini 3.7 Flash</span>
                    </div>
                    <p className="text-[9px] opacity-80 leading-tight">
                      {lang === 'tl' ? 'Balansyado para sa Tindahan' : 'Balanced store advisor'}
                    </p>
                  </div>
                  {selectedModel === 'gemini-3.7-flash' && <Check className="w-3.5 h-3.5 shrink-0" />}
                </button>

                {/* Option 2: Flash-Lite 3.1 */}
                <button
                  type="button"
                  onClick={() => {
                    setSelectedModel('gemini-3.1-flash-lite');
                    setIsModelDropdownOpen(false);
                  }}
                  className={`w-full text-left px-2 py-1.5 rounded-xl transition-all flex items-center justify-between text-[11px] font-semibold cursor-pointer mt-0.5 ${
                    selectedModel === 'gemini-3.1-flash-lite'
                      ? 'theme-bg-primary text-white font-bold shadow-2xs'
                      : 'theme-text-app hover:theme-bg-surface-subtle'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <Leaf className="w-3 h-3 text-emerald-400" />
                      <span>Gemini 3.1 Lite</span>
                      <span className="text-[8px] px-1 rounded bg-emerald-500/20 text-emerald-300 font-mono">ECO</span>
                    </div>
                    <p className="text-[9px] opacity-80 leading-tight">
                      {lang === 'tl' ? 'Mabilis, tipid data at RAM' : 'Ultra-fast, saves battery'}
                    </p>
                  </div>
                  {selectedModel === 'gemini-3.1-flash-lite' && <Check className="w-3.5 h-3.5 shrink-0" />}
                </button>

                {/* Option 3: Pro 3.1 */}
                <button
                  type="button"
                  onClick={() => {
                    setSelectedModel('gemini-3.1-pro-preview');
                    setIsModelDropdownOpen(false);
                  }}
                  className={`w-full text-left px-2 py-1.5 rounded-xl transition-all flex items-center justify-between text-[11px] font-semibold cursor-pointer mt-0.5 ${
                    selectedModel === 'gemini-3.1-pro-preview'
                      ? 'theme-bg-primary text-white font-bold shadow-2xs'
                      : 'theme-text-app hover:theme-bg-surface-subtle'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <Zap className="w-3 h-3 text-blue-400" />
                      <span>Gemini 3.1 Pro</span>
                    </div>
                    <p className="text-[9px] opacity-80 leading-tight">
                      {lang === 'tl' ? 'Malalimang analysis sa utang' : 'Deep strategic analysis'}
                    </p>
                  </div>
                  {selectedModel === 'gemini-3.1-pro-preview' && <Check className="w-3.5 h-3.5 shrink-0" />}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Chat Messages Thread */}
      <div className="flex-1 overflow-y-auto no-scrollbar p-3.5 sm:p-4 space-y-3.5 theme-bg-app">
        {messages.map((m) => {
          const isUser = m.role === 'user';
          return (
            <div key={m.id} className={`flex items-start gap-2.5 ${isUser ? 'flex-row-reverse' : ''}`}>
              <div
                className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                  isUser ? 'theme-bg-primary text-white' : 'theme-bg-surface-subtle theme-text-accent border theme-border-subtle'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[82%] rounded-3xl p-3.5 text-xs sm:text-sm leading-relaxed shadow-2xs whitespace-pre-wrap ${
                  isUser
                    ? 'theme-bg-primary text-white font-medium rounded-tr-none'
                    : 'theme-card theme-text-app border rounded-tl-none'
                }`}
              >
                {m.content}
                {m.modelUsed && (
                  <span className="block text-[9px] theme-text-secondary mt-1 font-mono">
                    Model: {m.modelUsed}
                  </span>
                )}
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center gap-2 text-xs font-bold theme-text-accent p-2.5 theme-bg-surface-subtle rounded-2xl w-fit border theme-border-subtle">
            <RefreshCw className="w-3.5 h-3.5 animate-spin theme-text-primary" />
            <span>{lang === 'tl' ? 'Nagiisip si Suki...' : 'Suki is thinking...'}</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Preset Questions Bar */}
      <div className="p-2 theme-bg-surface-subtle border-t theme-border-subtle flex gap-1.5 overflow-x-auto text-[11px] font-medium no-scrollbar">
        <span className="theme-text-secondary font-bold shrink-0 self-center px-1">{lang === 'tl' ? 'Tanungin:' : 'Ask:'}</span>
        {presetQuestions.map((q, i) => (
          <button
            key={i}
            onClick={() => handleSendMessage(q)}
            className="theme-card hover:theme-bg-primary hover:text-white theme-text-app border theme-border-subtle px-3 py-1 rounded-full whitespace-nowrap transition-colors shrink-0 font-medium active:scale-95"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className="p-3 theme-card border-t theme-border-subtle">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={lang === 'tl' ? 'Itanong kay Suki... (e.g. Magkano ibebenta ang Rebisco?)' : 'Ask Suki... (e.g. Recommended price for biscuits?)'}
            className="flex-1 theme-input border rounded-2xl py-2.5 px-3.5 text-xs sm:text-sm theme-text-app focus:outline-none font-medium"
          />

          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="theme-bg-primary text-white font-extrabold px-4 py-2.5 rounded-2xl text-xs sm:text-sm flex items-center gap-1.5 disabled:opacity-50 transition-all active:scale-95 shrink-0 shadow-2xs"
          >
            <span>{translate(lang, 'btn_record')}</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};

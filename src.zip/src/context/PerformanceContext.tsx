import React, { createContext, useContext, useEffect, useState, useMemo, useCallback } from 'react';
import { safeStorage } from '../utils/safeStorage';

export type PerformanceMode = 'AUTO' | 'ECO' | 'FULL';
export type DeviceTier = 'low' | 'mid' | 'high';

const PERFORMANCE_STORAGE_KEY = 'tinda_performance_mode';

export interface PerformanceContextType {
  mode: PerformanceMode;
  resolvedMode: 'ECO' | 'FULL';
  isEco: boolean;
  isAuto: boolean;
  deviceTier: DeviceTier;
  searchDebounceMs: number;
  allowHeavyAnimations: boolean;
  scannerFrameIntervalMs: number;
  setMode: (mode: PerformanceMode) => void;
}

// Detect hardware tier (based on RAM and CPU concurrency, matching ScannerModal pattern)
const detectDeviceTier = (): DeviceTier => {
  try {
    if (typeof window === 'undefined') return 'mid';
    const ram = (navigator as any).deviceMemory;
    const cores = navigator.hardwareConcurrency;

    // If deviceMemory API is supported (Chrome/Android WebView):
    // < 3GB RAM is low tier (budget 1-2GB phones)
    if (typeof ram === 'number') {
      if (ram < 3) return 'low';
      if (ram >= 4) return 'high';
      return 'mid';
    }

    // Fallback heuristic: 4 cores or fewer is budget/low tier on modern Android
    if (typeof cores === 'number' && cores <= 4) {
      return 'low';
    }

    return 'mid';
  } catch (err) {
    console.warn('[PerformanceContext] Device tier detection fallback:', err);
    return 'mid';
  }
};

const PerformanceContext = createContext<PerformanceContextType>({
  mode: 'AUTO',
  resolvedMode: 'FULL',
  isEco: false,
  isAuto: true,
  deviceTier: 'mid',
  searchDebounceMs: 150,
  allowHeavyAnimations: true,
  scannerFrameIntervalMs: 400,
  setMode: () => {},
});

export const PerformanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [deviceTier] = useState<DeviceTier>(() => detectDeviceTier());

  // Load saved preference from safeStorage, defaulting to AUTO
  const [mode, setModeState] = useState<PerformanceMode>(() => {
    try {
      const saved = safeStorage.getItem(PERFORMANCE_STORAGE_KEY);
      if (saved === 'AUTO' || saved === 'ECO' || saved === 'FULL') {
        return saved;
      }
    } catch (e) {
      console.warn('[PerformanceContext] Failed to load performance mode:', e);
    }
    return 'AUTO';
  });

  // Calculate resolved effective mode
  const resolvedMode: 'ECO' | 'FULL' = useMemo(() => {
    if (mode === 'ECO') return 'ECO';
    if (mode === 'FULL') return 'FULL';
    // AUTO mode: resolve to ECO for low-tier devices; FULL for mid/high devices
    return deviceTier === 'low' ? 'ECO' : 'FULL';
  }, [mode, deviceTier]);

  // Synchronize with DOM dataset for instant CSS responsiveness
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.dataset.perfMode = resolvedMode.toLowerCase();
    }
  }, [resolvedMode]);

  // Explicit user choice handler: persists to safeStorage, never silently overwritten
  const setMode = useCallback((newMode: PerformanceMode) => {
    setModeState(newMode);
    try {
      safeStorage.setItem(PERFORMANCE_STORAGE_KEY, newMode);
    } catch (e) {
      console.warn('[PerformanceContext] Failed to persist performance mode:', e);
    }
  }, []);

  const value = useMemo<PerformanceContextType>(
    () => ({
      mode,
      resolvedMode,
      isEco: resolvedMode === 'ECO',
      isAuto: mode === 'AUTO',
      deviceTier,
      searchDebounceMs: resolvedMode === 'ECO' ? 400 : 150,
      allowHeavyAnimations: resolvedMode !== 'ECO',
      scannerFrameIntervalMs: resolvedMode === 'ECO' ? 800 : 400,
      setMode,
    }),
    [mode, resolvedMode, deviceTier, setMode]
  );

  return <PerformanceContext.Provider value={value}>{children}</PerformanceContext.Provider>;
};

export const usePerformance = (): PerformanceContextType => {
  const context = useContext(PerformanceContext);
  if (!context) {
    throw new Error('usePerformance must be used within a PerformanceProvider');
  }
  return context;
};
